import CoreHaptics
import Charts
import PDFKit

// MARK: - Keychain Helper (secure local storage for credentials)
enum KeychainHelper {
    private static let service = "LABAApp"
    private static let userKey = "LABAApp.usernameBase"
    private static let passKey = "LABAApp.password"
    private static let refreshKey = "LABAApp.refreshToken"

    static func saveCredentials(usernameBase: String, password: String) {
        deleteCredentials()
        let userData = Data(usernameBase.utf8)
        let passData = Data(password.utf8)

        let userQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: userKey,
            kSecValueData as String: userData
        ]
        let passQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: passKey,
            kSecValueData as String: passData
        ]
        SecItemAdd(userQuery as CFDictionary, nil)
        SecItemAdd(passQuery as CFDictionary, nil)
    }

    static func loadCredentials() -> (usernameBase: String, password: String)? {
        let userQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: userKey,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        let passQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: passKey,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var uRes: AnyObject?
        var pRes: AnyObject?
        let uStatus = SecItemCopyMatching(userQuery as CFDictionary, &uRes)
        let pStatus = SecItemCopyMatching(passQuery as CFDictionary, &pRes)
        if uStatus == errSecSuccess, pStatus == errSecSuccess,
           let uData = uRes as? Data, let pData = pRes as? Data,
           let u = String(data: uData, encoding: .utf8),
           let p = String(data: pData, encoding: .utf8) {
            return (u, p)
        }
        return nil
    }

    static func deleteCredentials() {
        let userQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: userKey
        ]
        let passQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: passKey
        ]
        SecItemDelete(userQuery as CFDictionary)
        SecItemDelete(passQuery as CFDictionary)
    }

    static func saveRefreshToken(_ token: String?) {
        if let t = token, !t.isEmpty {
            let data = Data(t.utf8)
            let query: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: service,
                kSecAttrAccount as String: refreshKey,
                kSecValueData as String: data
            ]
            SecItemDelete(query as CFDictionary)
            SecItemAdd(query as CFDictionary, nil)
        } else {
            deleteRefreshToken()
        }
    }

    static func loadRefreshToken() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: refreshKey,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var res: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &res)
        if status == errSecSuccess, let data = res as? Data {
            return String(data: data, encoding: .utf8)
        }
        return nil
    }

    static func deleteRefreshToken() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: refreshKey
        ]
        SecItemDelete(query as CFDictionary)
    }
}
// MARK: - ConfettiView (Easter Egg)
struct LABAEggView: View {
    var onClose: () -> Void
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        ZStack {
            (scheme == .dark ? Color.black : Color.white)
                .ignoresSafeArea()

            // Confetti layer personalizzato
            ConfettiLayer(confettiColor: scheme == .dark ? .white : UIColor(Color.labaAccent))
                .allowsHitTesting(false)

            VStack(spacing: 20) {
                Spacer(minLength: 40)
                Text("🎉 VIVALABA! 🎉")
                    .font(.system(size: 38, weight: .bold))
                    .foregroundStyle(scheme == .dark ? .white : .black)

                Text("""
                Complimenti, sei entrato in una realtà meravigliosa,
                quella della nostra accademia.

                Sei un grande esploratore,
                sei un meraviglioso utente.
                """)
                .multilineTextAlignment(.center)
                .font(.title3)
                .foregroundStyle(scheme == .dark ? .white.opacity(0.95) : .black.opacity(0.95))
                .padding(.horizontal, 24)

                Spacer()

                Button(action: onClose) {
                    Text("Chiudi")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(scheme == .dark ? Color.white : Color.labaAccent)
                        )
                        .foregroundColor(scheme == .dark ? .black : .white)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            }
        }
    }
}

struct ConfettiLayer: UIViewRepresentable {
    var confettiColor: UIColor

    func makeUIView(context: Context) -> UIView {
        let v = UIView()
        let emitter = CAEmitterLayer()
        emitter.emitterShape = .line
        emitter.emitterPosition = CGPoint(x: UIScreen.main.bounds.midX, y: -10)
        emitter.emitterSize = CGSize(width: UIScreen.main.bounds.width, height: 2)

        var cells: [CAEmitterCell] = []
        let symbols = ["circle.fill", "square.fill", "triangle.fill", "seal.fill"]
        for sym in symbols {
            let c = CAEmitterCell()
            c.contents = UIImage(systemName: sym)?
                .withTintColor(confettiColor, renderingMode: .alwaysOriginal).cgImage
            c.birthRate = 6
            c.lifetime = 10
            c.velocity = 160
            c.velocityRange = 60
            c.scale = 0.06
            c.scaleRange = 0.03
            c.emissionLongitude = .pi
            c.emissionRange = .pi / 4
            c.spin = 2
            c.spinRange = 2
            cells.append(c)
        }
        emitter.emitterCells = cells
        v.layer.addSublayer(emitter)

        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            emitter.birthRate = 0
        }
        return v
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
//
//  ContentView.swift
//  LABAv2
//
//  Full app with real API integration + PKCE/SSO fallback when password grant is not allowed.
//

import SwiftUI
import Foundation
import Combine
import PhotosUI
import UIKit
import UserNotifications
import FirebaseCore
import FirebaseMessaging

#if canImport(WidgetKit)
import WidgetKit
#endif

// MARK: - Color and Styling Constants

extension Color {
    static let labaPrimary = Color(red: 3/255, green: 49/255, blue: 87/255) // #033157 HEX
    static let cardBG = Color(.secondarySystemBackground)
    static let pillBGYear = Color(.systemBlue)
    static let pillBGGrade = Color(.systemGreen)
    static let pillBGCFA = Color(.systemOrange)
    static let pillBGStatus = Color(.systemOrange)
    static let pillBGYear1 = Color(.systemBlue)
    static let pillBGYear2 = Color(.systemTeal)
    static let pillBGYear3 = Color(.systemIndigo)
    static let pillBGLaureato = Color(.systemOrange)
}

// Pre-warm commonly used SF Symbols so the tab bar icons don't lag on first render
@inline(__always)
func warmUpSymbols() {
    #if canImport(UIKit)
    let names = [
        "house", "graduationcap", "bell", "person.crop.circle",
        // add any other symbols you use often in headers or toolbars
        "calendar", "ellipsis.circle", "info.circle", "lock.fill", "person.fill"
    ]
    let config = UIImage.SymbolConfiguration(pointSize: 17, weight: .regular)
    for n in names {
        _ = UIImage(systemName: n, withConfiguration: config)
    }
    #endif
}

// MARK: - Helper Functions

func ddMMyyyy(_ date: Date?) -> String {
    guard let date else { return "-" }
    let f = DateFormatter()
    f.locale = Locale(identifier: "it_IT")
    f.dateFormat = "dd/MM/yyyy"
    return f.string(from: date)
}

func parseAPIDate(_ s: String?) -> Date? {
    guard let s = s, !s.isEmpty else { return nil }
    let f1 = DateFormatter(); f1.locale = Locale(identifier: "en_US_POSIX"); f1.timeZone = .init(secondsFromGMT: 0); f1.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
    let f2 = DateFormatter(); f2.locale = Locale(identifier: "en_US_POSIX"); f2.timeZone = .init(secondsFromGMT: 0); f2.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    return f1.date(from: s) ?? f2.date(from: s)
}

func italianOrdinalYear(_ y: Int) -> String {
    switch y { case 1: return "1° anno"; case 2: return "2° anno"; case 3: return "3° anno"; default: return "\(y)° anno" }
}

func preferredScheme(from pref: String) -> ColorScheme? {
    switch pref {
    case "light": return .light
    case "dark": return .dark
    default: return nil
    }
}

func normalizeNameForEmail(_ s: String) -> String {
    let lowered = s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    let replaced = lowered.replacingOccurrences(of: " ", with: ".")
    return replaced
}

func fullName(from base: String) -> String {
    let parts = base.split(separator: ".").map { String($0) }
    guard !parts.isEmpty else { return base.capitalized }
    let cap = parts.map { $0.replacingOccurrences(of: "-", with: " ").capitalized }
    return cap.joined(separator: " ")
}

func prettifyTitle(_ s: String) -> String {
    let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { return trimmed }

    // If it arrives ALL CAPS, bring it down before capitalizing
    let base = (trimmed == trimmed.uppercased()) ? trimmed.lowercased() : trimmed

    // Title-case first, then fix prepositions/conjunctions
    let titled = base.capitalized(with: Locale(identifier: "it_IT"))

    let lowerWords: Set<String> = [
        "di","a","da","in","con","su","per","tra","fra","e","o",
        "del","dello","della","dei","degli","delle","dell'",
        "al","allo","alla","ai","agli","alle","all'",
        "nel","nello","nella","nei","negli","nelle","nell'",
        "sul","sullo","sulla","sui","sugli","sulle","sull'"
    ]

    var out: [String] = []
    let tokens = titled.split(separator: " ")
    for (i, raw) in tokens.enumerated() {
        var tok = String(raw)
        let lower = tok.lowercased()
        if i > 0, lowerWords.contains(lower) {
            tok = lower
        }
        out.append(tok)
    }
    return out.joined(separator: " ")
}

// Accent color dell'app
struct AccentPalette {
    static func color(named: String) -> Color {
        switch named {
        case "system":   return Color.accentColor      // usata a runtime
        case "brand":    return Color.labaPrimary
        case "IED":      return Color(red: 187/255, green: 39/255, blue: 26/255) // runtime IED + RGBa
        case "peach":    return Color(red: 0.99, green: 0.58, blue: 0.47)
        case "lavender": return Color(red: 0.57, green: 0.53, blue: 0.96)
        case "mint":     return Color(red: 0.36, green: 0.78, blue: 0.66)
        case "sand":     return Color(red: 0.86, green: 0.75, blue: 0.58)
        case "sky":      return Color(red: 0.35, green: 0.68, blue: 0.93)
        default:         return Color.accentColor
        }
    }

    // anteprima statica per la UI (il dot della lista)
    static func previewColor(named: String) -> Color {
        switch named {
        case "system":
            return Color(uiColor: .systemBlue) // blu iOS fisso
        default:
            return color(named: named)
        }
    }
}

func labaTint(_ scheme: ColorScheme) -> Color {
    // Dark mode: B/N come richiesto
    if scheme == .dark { return .white }
    // Light mode: usa accento scelto (default sistema)
    let choice = UserDefaults.standard.string(forKey: "laba.accent") ?? "system"
    if choice == "system" { return .accentColor }
    return AccentPalette.color(named: choice)
}
func yearTint(_ year: Int?) -> Color? {
    guard let year = year else { return nil }
    switch year {
    case 1: return Color.pillBGYear1
    case 2: return Color.pillBGYear2
    case 3: return Color.pillBGYear3
    default: return Color.pillBGYear
    }
}

func teacherEmails(from docente: String) -> [String] {
    let parts = docente.split(separator: "/").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
    return parts.compactMap { full in
        let comps = full.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        guard comps.count >= 2 else { return nil }
        let first = comps[0]
        let last = comps.dropFirst().joined() // unisce cognomi composti: Dalla Valle -> DallaValle; Di Lella -> DiLella
        var base = "\(first).\(last)"
        base = base.folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
            .replacingOccurrences(of: "'", with: "")
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "-", with: "")
        return base + "@labafirenze.com"
    }
}

func courseDisplayInfo(from piano: String?) -> (name: String, aa: String)? {
    guard let p = piano, !p.isEmpty else { return nil }
    let upper = p.uppercased()
    let parts = upper.components(separatedBy: "A.A.")
    let courseRaw = parts.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? upper
    let yearsRaw = parts.count > 1 ? parts[1] : ""

    // Preferisci match più specifici prima dei generici
    let patterns: [(key: String, value: String)] = [
        ("GRAPHIC DESIGN & MULTIMEDIA", "Graphic Design"),
        ("PITTURA", "Pittura"),
        ("FASHION DESIGN", "Fashion Design"),
        ("REGIA E VIDEOMAKING", "Regia e Videomaking"),
        ("INTERIOR DESIGN", "Interior Design"),
        ("CINEMA E AUDIOVISIVI", "Cinema e Audiovisivi"),
        ("FOTOGRAFIA", "Fotografia"),
        ("DESIGN", "Design") // generico in fondo
    ]

    var name = courseRaw
    for (k, v) in patterns { if courseRaw.contains(k) { name = v; break } }

    let digits = yearsRaw.components(separatedBy: CharacterSet.decimalDigits.inverted).filter { !$0.isEmpty }
    var aa = ""
    if digits.count >= 2, let s = digits.first, let e = digits.dropFirst().first {
        let s2 = String(s.suffix(2))
        let e2 = String(e.suffix(2))
        aa = "A.A. \(s2)/\(e2)"
    }
    return (name, aa)
}

// HTML → plain text helper
func plainText(from html: String?) -> String {
    guard let html, let data = html.data(using: .utf8) else { return html ?? "" }
    if let att = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil) {
        return att.string
    }
    return html
}

// MARK: - Seminari Helpers

struct SeminarDetails {
    var docente: String?
    var dateLines: [String] = []
    var aula: String?
    var allievi: String?
    var cfa: String?
    var assenze: String?
    var completed: Bool = false
    var groups: [(label: String, time: String)] = []
}

/// Rimuove tutto ciò che è tra parentesi tonde (anche annidate)
func stripParentheses(_ s: String) -> String {
    var out = ""
    var depth = 0
    for ch in s {
        if ch == "(" { depth += 1; continue }
        if ch == ")" { if depth > 0 { depth -= 1 }; continue }
        if depth == 0 { out.append(ch) }
    }
    return out.trimmingCharacters(in: .whitespacesAndNewlines)
}

/// Restituisce SOLO il testo tra virgolette ( “ … ” oppure " ... " ).
/// Rimuove anche prefissi come SEMINARIO/WORKSHOP e i suffissi tra parentesi.
func seminarTitle(from s: String) -> String {
    let noParens = stripParentheses(s)
    if let o = noParens.firstIndex(of: "“"),
       let c = noParens[noParens.index(after: o)...].firstIndex(of: "”") {
        return String(noParens[noParens.index(after: o)..<c]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    if let o = noParens.firstIndex(of: "\""),
       let c = noParens[noParens.index(after: o)...].firstIndex(of: "\"") {
        return String(noParens[noParens.index(after: o)..<c]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    let prefixes = ["SEMINARIO", "WORKSHOP"]
    var t = noParens.trimmingCharacters(in: .whitespaces)
    for p in prefixes where t.uppercased().hasPrefix(p) {
        t = t.dropFirst(p.count).trimmingCharacters(in: .whitespacesAndNewlines)
        break
    }
    return t
}

func parseSeminarDetails(html: String?, esito: String?) -> SeminarDetails {
    var d = SeminarDetails()
    let text = plainText(from: html).replacingOccurrences(of: "\u{00a0}", with: " ")
    let lines = text
        .components(separatedBy: .newlines)
        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        .filter { !$0.isEmpty }

    func extract(after key: String) -> String? {
        if let line = lines.first(where: { $0.lowercased().hasPrefix(key.lowercased()) }) {
            return line.dropFirst(key.count).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return nil
    }

    if let rawDoc = extract(after: "Docente:") ?? extract(after: "Docenti:") {
        d.docente = cleanTeacherList(rawDoc)
    }

    // Date (solo righe con mesi). Evita orario/gruppi qui.
    if let idx = lines.firstIndex(where: { $0.lowercased().hasPrefix("date:") || $0.lowercased().hasPrefix("orario") }) {
        var collected: [String] = []
        for i in idx..<min(lines.count, idx+12) {
            let raw = lines[i]
            let l = raw
                .replacingOccurrences(of: "Date:", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "Orario:", with: "", options: .caseInsensitive)
                .trimmingCharacters(in: .whitespaces)
            let lower = l.lowercased()
            if lower.hasPrefix("allievi") || lower.hasPrefix("aula") || lower.contains("cfa") { break }

            if lower.contains("gruppo") {
                // Estrai gruppi/orari (safe regex)
                if let timeRx = try? NSRegularExpression(
                    pattern: #"\b\d{1,2}[:.]\d{2}\b(\s?[–\u{2013}\u{2014}-]\s?\d{1,2}[:.]\d{2}\b)?"#,
                    options: []
                ) {
                    let ns = l as NSString
                    let time = timeRx.firstMatch(in: l, range: NSRange(location: 0, length: ns.length)).map { ns.substring(with: $0.range) } ?? ""
                    if let gr = l.range(of: #"(?i)gruppo\s*([A-Za-z0-9]+)"#, options: .regularExpression) {
                        let label = l[gr].replacingOccurrences(of: "gruppo", with: "", options: .caseInsensitive).trimmingCharacters(in: .whitespaces)
                        d.groups.append((label: label.uppercased(), time: time))
                    }
                }
                continue
            }

            if containsMonthName(l) { collected.append(l) }
        }
        d.dateLines = formatSeminarDateLines(collected)
    }

    d.aula = extract(after: "Aula:") ?? extract(after: "Aula :")
    d.allievi = extract(after: "Allievi:") ?? extract(after: "Allievi :")

    // Estrai SOLO i crediti (CFA) senza riportare frasi sulle assenze
    if let cfaLine = lines.first(where: { $0.range(of: "CFA", options: .caseInsensitive) != nil }) {
        // prova a catturare un numero di crediti (1 o 2 cifre)
        if let rx = try? NSRegularExpression(pattern: "(?i)(?:N°\\s*)?(\\n?\\r?\\s*)?(\\d{1,2})\\s*CFA|CFA\\s*(\\d{1,2})", options: [] ) {
            let ns = cfaLine as NSString
            let r = NSRange(location: 0, length: ns.length)
            if let m = rx.firstMatch(in: cfaLine, options: [], range: r) {
                // gruppo 2 o 3 contiene il numero
                let g2 = m.range(at: 2)
                let g3 = m.range(at: 3)
                var number: String? = nil
                if g2.location != NSNotFound { number = ns.substring(with: g2) }
                else if g3.location != NSNotFound { number = ns.substring(with: g3) }
                if let number { d.cfa = number }
            }
        }
        if d.cfa == nil {
            // fallback morbido: ripulisci la frase dai prefissi noti
            d.cfa = cfaLine
                .replacingOccurrences(of: "Il Seminario consente l’acquisizione di", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "Il Seminario prevede l’acquisizione di", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "crediti formativi", with: "", options: .caseInsensitive)
                .replacingOccurrences(of: "N°", with: "", options: .caseInsensitive)
                .trimmingCharacters(in: .whitespaces)
        }
    }

    if let line = lines.first(where: { $0.range(of: "assenz", options: .caseInsensitive) != nil }) {
        d.assenze = extractAssenzaSentence(line)
    }

    if let e = esito?.lowercased(), e.contains("complet") || e.contains("approv") || e.contains("valid") {
        d.completed = true
    }
    return d
}

/// Converte la stringa di “Allievi” in coppie (anno, corso) per mostrare pillole.
func allieviGroups(from s: String?) -> [(anno: Int?, corso: String?)] {
    guard let s = s, !s.isEmpty else { return [] }
    let parts = s.components(separatedBy: CharacterSet(charactersIn: "+,;"))
        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        .filter { !$0.isEmpty }
    var out: [(Int?, String?)] = []
    for p in parts {
        var year: Int? = nil
        if let r = p.range(of: #"(\d)°"#, options: .regularExpression) {
            let yStr = p[r].replacingOccurrences(of: "°", with: "")
            year = Int(yStr)
        }
        let hints: [(String,String)] = [
            ("GD","Graphic Design & Multimedia"),
            ("Graphic Design","Graphic Design & Multimedia"),
            ("Design","Design"),
            ("Fotografia","Fotografia"),
            ("Fashion","Fashion Design"),
            ("Pittura","Pittura"),
            ("Regia","Regia e Videomaking"),
            ("Cinema","Cinema e Audiovisivi"),
            ("Interior","Interior Design")
        ]
        var course: String? = nil
        for (k,v) in hints where p.range(of: k, options: .caseInsensitive) != nil { course = v; break }
        out.append((year, course))
    }
    return out
}

// MARK: - Seminari formatting helpers

private let itMonths: [String] = ["gennaio","febbraio","marzo","aprile","maggio","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre"]

func containsMonthName(_ s: String) -> Bool {
    let l = s.lowercased()
    return itMonths.contains { l.contains($0) }
}

func capMonth(_ m: String) -> String {
    guard let f = m.first else { return m }
    return String(f).uppercased() + m.dropFirst().lowercased()
}

/// Concatena e riformatta le linee data in blocchi per mese:
/// es. "Sabato 15 Febbraio", "22 Marzo", "5 e 12 Aprile"
func formatSeminarDateLines(_ lines: [String]) -> [String] {
    var s = lines.joined(separator: " ")
    s = s.replacingOccurrences(of: "  ", with: " ")
    // rimuovi indicazioni orarie generiche
    s = s.replacingOccurrences(of: " ore ", with: " ", options: .caseInsensitive)
    if let timeRegex = try? NSRegularExpression(
        pattern: #"\b\d{1,2}[:.]\d{2}\b(\s?[–\u{2013}\u{2014}-]\s?\d{1,2}[:.]\d{2}\b)?"#,
        options: []
    ) {
        s = timeRegex.stringByReplacingMatches(in: s, options: [], range: NSRange(location: 0, length: s.utf16.count), withTemplate: "")
    }
    s = s.replacingOccurrences(of: "  ", with: " ")

    let monthsPattern = itMonths.joined(separator: "|")
    guard let regex = try? NSRegularExpression(
        pattern: "(?i)([\\p{L}\\s]*?\\d{1,2}(?:\\s*e\\s*\\d{1,2})?)\\s+(" + monthsPattern + ")",
        options: []
    ) else {
        return lines
    }
    let ns = s as NSString
    let matches = regex.matches(in: s, range: NSRange(location: 0, length: ns.length))
    var out: [String] = []
    for m in matches {
        guard m.numberOfRanges >= 3 else { continue }
        var left = ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespaces)
        left = left.replacingOccurrences(of: "-", with: " ").replacingOccurrences(of: "–", with: " ")
        let month = ns.substring(with: m.range(at: 2)).lowercased()
        if left.isEmpty { continue }
        out.append("\(left.capitalized) \(capMonth(month))")
    }
    return out.isEmpty ? lines : out
}

/// Pulisce prefissi come Prof./Prof.ssa/Avv./Dott. dai nomi docenti.
/// Supporta liste separate da "/".
func cleanTeacherList(_ raw: String) -> String {
    let parts = raw.split(separator: "/").map { $0.trimmingCharacters(in: .whitespaces) }
    let rx = try? NSRegularExpression(pattern: #"(?i)^(prof\.?\s*(ssa|ss|sso)?|avv\.?|dott\.?|dr\.?|ing\.?|arch\.?|maestro|maestra)\s+"#, options: [])
    func cleanOne(_ s: String) -> String {
        let ns = s as NSString
        let r = NSRange(location: 0, length: ns.length)
        let cleaned: String
        if let rx {
            cleaned = rx.stringByReplacingMatches(in: s, options: [], range: r, withTemplate: "")
        } else {
            cleaned = s
        }
        return prettifyTitle(cleaned.trimmingCharacters(in: .whitespaces))
    }
    return parts.map(cleanOne).joined(separator: " / ")
}

/// Estrae solo la frase che parla di assenze, senza pezzi sui crediti.
func extractAssenzaSentence(_ s: String) -> String {
    if let r = s.range(of: #"(?i)[^.]*assenz[^.]*"#, options: .regularExpression) {
        return String(s[r]).trimmingCharacters(in: .whitespaces)
    }
    return s
}

// MARK: - Remote Models

struct EnrollmentsResponse: Decodable {
    let success: Bool
    let payload: EnrollmentsPayload?
    let errorSummary: String?
}

struct EnrollmentsPayload: Decodable {
    let stato: String?
    let dataStato: String?
    let annoAttuale: Int?
    let pianoStudi: String?
    let situazioneEsami: [RemoteExam]
}

struct StudentResponse: Decodable {
    let success: Bool
    let payload: StudentPayload?
    let errorSummary: String?
}

struct StudentPayload: Decodable {
    let nome: String?
    let cognome: String?
    let numMatricola: String?
    let emailPersonale: String?
    let emailLABA: String?
    let telefono: String?
    let cellulare: String?
    let codiceFiscale: String?
    let sesso: String?
    let pagamenti: String?
    let oid: String?          // 👈 aggiunto
}

struct RemoteExam: Decodable {
    let oidCorso: String
    let ordine: Int?
    let corso: String
    let docente: String?
    let anno: Int?
    let cfa: String?
    let propedeutico: String?
    let sostenutoIl: String?
    let voto: String?
    let ssd: String?
    let dataRichiesta: String?
    let esitoRichiesta: String?
    let richiedibile: String?
}

// Seminars remote models
struct SeminariResponse: Decodable {
    let success: Bool
    let payload: [SeminarioPayload]?
    let errorSummary: String?
}
struct SeminarioPayload: Decodable {
    let seminarioOid: String
    let descrizione: String
    let descrizioneEstesa: String?
    let documentOid: String?
    let dataRichiesta: String?
    let esitoRichiesta: String?
    let richiedibile: String?
}

// Notifications remote models
struct NotificationsResponse: Decodable {
    let success: Bool
    let payload: [NotificationPayload]?
    let errorSummary: String?
}

struct NotificationsAnyWrapper: Decodable {
    let data: [NotificationPayload]?
    let payload: [NotificationPayload]?
}

struct NotificationPayload: Decodable {
    let id: Int
    let dataOraCreazione: String?
    let tipo: String?
    let oggetto: String?
    let messaggio: String
    let parametro: String?
    let allievoOId: String?
    let dataOraLetturaNotifica: String?
    let playerId: String?
}

// App model for notifications
struct NotificationItem: Identifiable, Hashable {
    let id: Int
    var title: String?
    var message: String
    var createdAt: Date?
    var readAt: Date?

    var isRead: Bool { readAt != nil }
}

fileprivate func itDateTime(_ d: Date?) -> String {
    guard let d else { return "—" }
    let f = DateFormatter()
    f.locale = Locale(identifier: "it_IT")
    f.dateFormat = "dd/MM/yyyy HH:mm"
    return f.string(from: d)
}

// MARK: - App Models

struct Esame: Identifiable {
    let id: String
    let corso: String
    let docente: String?
    let anno: Int?
    let cfa: String?
    let propedeutico: String?
    let sostenutoIl: Date?
    let voto: String?
    let richiedibile: Bool
}

struct Seminario: Identifiable {
    let id: String
    let titolo: String
    let descrizioneEstesa: String?
    let richiedibile: Bool
    let esito: String?
}

// MARK: - API Client (IdentityServer + PKCE)

final class APIClient {
    static let shared = APIClient()

    // NOTE: You might need a dedicated **mobile** client_id from IdentityServer.
    // The SPA client often doesn't allow password grant. If you *do* have a secret, set it here.
    var clientId: String = "98C96373243D" // from earlier token claims
    var clientSecret: String? = "B1355BBB-EA35-4724-AFAA-8ABAAFEDCFB6"       // from HAR (confidential client)

    let issuerBase = URL(string: "https://logosuni.laba.biz/identityserver")!
    // Scopes separated per flow: the HAR showed only LogosUni.Laba.Api for password grant
    let scopeROPC = "LogosUni.Laba.Api"

    private var tokenURL: URL { issuerBase.appendingPathComponent("connect/token") }
    private let enrollmentsURL = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Enrollments")!
    private let studentURL = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Students")!
    private let seminarsURL = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Seminars")!
    private let notificationsURLv1 = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notifications")!
    private let notificationsURLv2 = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/GetNotifications")!
    private let notificationMarkReadURL = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/MarkAsRead")!

    private func buildNotificationURLs(studentOid: String?) -> [URL] {
        var urls: [URL] = []
        // v2 base
        urls.append(URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/GetNotifications")!)
        // v2 with paging
        if var c = URLComponents(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/GetNotifications") {
            c.queryItems = [URLQueryItem(name: "start", value: "0"),
                            URLQueryItem(name: "count", value: "100")]
            if let u = c.url { urls.append(u) }
        }
        // v2 with possible student filter (name variant 1)
        if let oid = studentOid, var c = URLComponents(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/GetNotifications") {
            c.queryItems = [URLQueryItem(name: "allievoOid", value: oid),
                            URLQueryItem(name: "start", value: "0"),
                            URLQueryItem(name: "count", value: "100")]
            if let u = c.url { urls.append(u) }
        }
        // v2 with possible student filter (name variant 2 - as in payload key)
        if let oid = studentOid, var c = URLComponents(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notification/GetNotifications") {
            c.queryItems = [URLQueryItem(name: "allievoOId", value: oid)]
            if let u = c.url { urls.append(u) }
        }
        // legacy plural
        urls.append(URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Notifications")!)
        return urls
    }

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60
        return URLSession(configuration: config)
    }()

    struct TokenResponse: Decodable { let access_token: String; let refresh_token: String?; let expires_in: Int }

    // ROPC (legacy). Will fail with invalid_client if the client doesn't allow it.
    func loginROPC(email: String, password: String) async throws -> TokenResponse {
        var req = URLRequest(url: tokenURL)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        var pairs = [
            ("client_id", clientId),
            ("grant_type", "password"),
            ("username", email),
            ("password", password),
            ("scope", scopeROPC)
        ]
        if let secret = clientSecret { pairs.append(("client_secret", secret)) }
        let body = pairs.map { "\($0.0)=\($0.1.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }.joined(separator: "&")
        req.httpBody = body.data(using: .utf8)

        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let txt = String(data: data, encoding: .utf8) ?? "<no body>"
            throw NSError(domain: "API", code: (resp as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "Login failed: \(txt)"])
        }
        return try JSONDecoder().decode(TokenResponse.self, from: data)
    }

    // MARK: API
    func enrollments(token: String) async throws -> EnrollmentsPayload {
        var req = URLRequest(url: enrollmentsURL)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let txt = String(data: data, encoding: .utf8) ?? "<no body>"
            throw NSError(domain: "API", code: (resp as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "Enrollments failed: \(txt)"])
        }
        let dec = JSONDecoder()
        let root = try dec.decode(EnrollmentsResponse.self, from: data)
        guard root.success, let payload = root.payload else {
            throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: root.errorSummary ?? "Unknown error"])
        }
        return payload
    }

    func student(token: String) async throws -> StudentPayload {
        var req = URLRequest(url: studentURL)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let txt = String(data: data, encoding: .utf8) ?? "<no body>"
            throw NSError(domain: "API", code: (resp as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "Student failed: \(txt)"])
        }
        let dec = JSONDecoder()
        let root = try dec.decode(StudentResponse.self, from: data)
        guard root.success, let payload = root.payload else {
            throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: root.errorSummary ?? "Unknown error"])
        }
        return payload
    }

    func seminars(token: String) async throws -> [SeminarioPayload] {
        var req = URLRequest(url: seminarsURL)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let txt = String(data: data, encoding: .utf8) ?? "<no body>"
            throw NSError(domain: "API", code: (resp as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "Seminars failed: \(txt)"])
        }
        let dec = JSONDecoder()
        let root = try dec.decode(SeminariResponse.self, from: data)
        guard root.success, let payload = root.payload else {
            throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: root.errorSummary ?? "Unknown error"]) }
        return payload
    }



    func notifications(token: String, studentOid: String?) async throws -> [NotificationPayload] {
        // Prefer POST first (405 on GET observed in prod), then try GET fallbacks
        if let posted = try? await postNotifications(token: token, studentOid: studentOid) {
            return posted
        }

        let endpoints = buildNotificationURLs(studentOid: studentOid)
        var lastError: Error? = nil
        for url in endpoints {
            var req = URLRequest(url: url)
            req.httpMethod = "GET"
            req.setValue("application/json", forHTTPHeaderField: "Accept")
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            do {
                let (data, resp) = try await session.data(for: req)
                guard let http = resp as? HTTPURLResponse else {
                    throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: "Notifications: invalid response"])
                }
                print("Notifications GET: \(url.absoluteString) → status \(http.statusCode)")
                if http.statusCode == 405 { // Method not allowed → prefer POST
                    lastError = NSError(domain: "API", code: 405, userInfo: [NSLocalizedDescriptionKey: "Notifications GET not allowed at \(url.path)"])
                    continue
                }
                guard (200..<300).contains(http.statusCode) else {
                    if http.statusCode == 404 || http.statusCode == 401 || http.statusCode == 403 {
                        lastError = NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Notifications failed \(http.statusCode) at \(url.path)"])
                        continue
                    }
                    let txt = String(data: data, encoding: .utf8) ?? "<no body>"
                    throw NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Notifications failed: \(txt)"])
                }

                if let arr = decodeNotifications(data) { return arr }
                lastError = NSError(domain: "API", code: -2, userInfo: [NSLocalizedDescriptionKey: "Notifications: unexpected shape at \(url.path)"])
            } catch {
                print("Notifications GET error at \(url.absoluteString): \(error)")
                lastError = error
            }
        }

        // Final POST attempt if not yet tried successfully
        if let posted = try? await postNotifications(token: token, studentOid: studentOid) {
            return posted
        }
        throw lastError ?? NSError(domain: "API", code: -3, userInfo: [NSLocalizedDescriptionKey: "Notifications: all endpoints failed"])
    }

    private func decodeNotifications(_ data: Data) -> [NotificationPayload]? {
        let dec = JSONDecoder()
        if let wrapped = try? dec.decode(NotificationsResponse.self, from: data),
           (wrapped.success || wrapped.payload != nil), let payload = wrapped.payload { return payload }
        if let alt = try? dec.decode(NotificationsAnyWrapper.self, from: data),
           let arr = alt.data ?? alt.payload { return arr }
        if let arr = try? dec.decode([NotificationPayload].self, from: data) { return arr }
        return nil
    }

    private func postNotifications(token: String, studentOid: String?) async throws -> [NotificationPayload] {
        // Attempt 1: POST with JSON body
        do {
            var req = URLRequest(url: notificationsURLv2)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Accept")
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            var body: [String: Any] = ["start": 0, "count": 100]
            if let oid = studentOid, !oid.isEmpty { body["allievoOId"] = oid }
            req.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])

            let (data, resp) = try await session.data(for: req)
            guard let http = resp as? HTTPURLResponse else {
                throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: "Notifications POST: invalid response"])
            }
            print("Notifications POST: \(notificationsURLv2.absoluteString) → status \(http.statusCode)")
            guard (200..<300).contains(http.statusCode) else {
                if http.statusCode == 204 { return [] }
                let txt = String(data: data, encoding: .utf8) ?? "<no body>"
                throw NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Notifications POST failed: \(txt)"])
            }
            if let arr = decodeNotifications(data) { return arr }
        } catch {
            print("Notifications POST error (JSON body): \(error)")
        }

        // Attempt 2: POST with query items instead of body (some backends read only query)
        if var comps = URLComponents(url: notificationsURLv2, resolvingAgainstBaseURL: false) {
            var items = [URLQueryItem(name: "start", value: "0"), URLQueryItem(name: "count", value: "100")]
            if let oid = studentOid, !oid.isEmpty { items.append(URLQueryItem(name: "allievoOId", value: oid)) }
            comps.queryItems = items
            if let urlQ = comps.url {
                do {
                    var req = URLRequest(url: urlQ)
                    req.httpMethod = "POST"
                    req.setValue("application/json", forHTTPHeaderField: "Accept")
                    req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                    let (data, resp) = try await session.data(for: req)
                    guard let http = resp as? HTTPURLResponse else {
                        throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: "Notifications POST(query): invalid response"])
                    }
                    print("Notifications POST(query): \(urlQ.absoluteString) → status \(http.statusCode)")
                    guard (200..<300).contains(http.statusCode) else {
                        if http.statusCode == 204 { return [] }
                        let txt = String(data: data, encoding: .utf8) ?? "<no body>"
                        throw NSError(domain: "API", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Notifications POST(query) failed: \(txt)"])
                    }
                    if let arr = decodeNotifications(data) { return arr }
                } catch {
                    print("Notifications POST(query) error: \(error)")
                }
            }
        }
        throw NSError(domain: "API", code: -4, userInfo: [NSLocalizedDescriptionKey: "Notifications POST attempts failed"])
    }

    /// Best-effort: try to mark a notification as read in backend if supported. Fails silently.
    func markNotificationRead(token: String, id: Int) async {
        // Preferred: POST JSON { id: ... }
        do {
            var r = URLRequest(url: notificationMarkReadURL)
            r.httpMethod = "POST"
            r.setValue("application/json", forHTTPHeaderField: "Accept")
            r.setValue("application/json", forHTTPHeaderField: "Content-Type")
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let body: [String: Any] = ["id": id]
            r.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
            _ = try await session.data(for: r)
            return
        } catch {
            print("MarkAsRead JSON body failed: \(error)")
        }
        // Fallback legacy: POST with query
        if let url1 = URL(string: notificationsURLv1.absoluteString + "/Read?id=\(id)") {
            var r = URLRequest(url: url1)
            r.httpMethod = "POST"
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            _ = try? await session.data(for: r)
        }
    }
}


// MARK: - Session ViewModel

// App Group usato per condividere dati col widget.

let LABA_APP_GROUP = "group.com.labafirenze.shared"  // MUST match the App Group ID in Signing & Capabilities (App + Widget)

fileprivate let pushAPNsTokenKey = "debug.apnsToken"
fileprivate let pushFCMTokenKey  = "debug.fcmToken"

#if canImport(UIKit)
fileprivate enum Device {
    static var isMini: Bool {
        // iPhone 12/13 mini have native long side = 2340px. Treat <= 2340 as "mini".
        let h = max(UIScreen.main.nativeBounds.width, UIScreen.main.nativeBounds.height)
        return h <= 2340
    }
}
#endif

fileprivate let labaDomain = "@labafirenze.com"

struct WidgetSummary: Codable {
    let displayName: String
    let passed: Int
    let totalCFA: Int
    let average: String
}

final class SessionVM: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var displayName: String? = nil
    @Published var status: String? = nil
    @Published var currentYear: Int? = nil
    @Published var esami: [Esame] = []
    @Published var loading: Bool = false
    @Published var error: String? = nil
    @Published var pianoStudi: String? = nil
    @Published var nome: String? = nil
    @Published var cognome: String? = nil
    @Published var matricola: String? = nil
    @Published var sesso: String? = nil
    @Published var emailLABA: String? = nil
    @Published var emailPersonale: String? = nil
    @Published var telefono: String? = nil
    @Published var cellulare: String? = nil
    @Published var pagamenti: String? = nil
    @Published var studentOid: String? = nil
    @Published var seminari: [Seminario] = []
    @Published var notifications: [NotificationItem] = []
    @Published var isBooting: Bool = true
    // Blocca qualsiasi restore/silent-login dopo un logout esplicito
    @Published var restoreDisabled: Bool = false

    // Local read state cache so the badge works even if the backend doesn't persist read state for mobile yet
    @AppStorage("laba.readNotificationIDs") private var readIDsData: Data = Data()
    private var localReadIDs: Set<Int> {
        get { (try? JSONDecoder().decode(Set<Int>.self, from: readIDsData)) ?? [] }
        set { readIDsData = (try? JSONEncoder().encode(newValue)) ?? Data() }
    }

    var unreadNotificationsCount: Int {
        notifications.filter { !$0.isRead && !localReadIDs.contains($0.id) }.count
    }

    // Badges
    var bookableExamsCount: Int { esami.filter { $0.richiedibile }.count }
    var bookableSeminarsCount: Int { seminari.filter { $0.richiedibile }.count }

    @AppStorage("laba.accessToken") var accessToken: String = ""
    @AppStorage("laba.usernameBase") private var usernameBase: String = ""
    
    /// Sync login state to the Widget (App Group) and refresh timelines.
    private func setWidgetLoginState(_ loggedIn: Bool) {
        if let ud = UserDefaults(suiteName: LABA_APP_GROUP) {
            ud.set(loggedIn, forKey: "user.isLoggedIn")
            ud.synchronize()
        }
        #if canImport(WidgetKit)
        WidgetCenter.shared.reloadTimelines(ofKind: "LABAWidget")
        WidgetCenter.shared.reloadTimelines(ofKind: "LABAExamsWidgetSmall")
        WidgetCenter.shared.reloadTimelines(ofKind: "LABACFAWidgetSmall")
        WidgetCenter.shared.reloadTimelines(ofKind: "LABAMediaWidgetSmall")
        #endif
    }

    private func updateWidgetSummary() {
        let passed = esami.filter { !($0.voto ?? "").isEmpty }.count
        let totalCFA = esami.compactMap { Int($0.cfa ?? "") }.reduce(0, +)

        // media matematica (esclude Tesi/Attività a scelta e “idoneo”)
        let valid = esami.filter { e in
            let nameUp = e.corso.uppercased()
            let isOther = nameUp.contains("ATTIVITA' A SCELTA") || nameUp.contains("TESI FINALE")
            let isIdoneita = (e.voto ?? "").lowercased().contains("idone")
            return !isOther && !isIdoneita
        }
        var weightedSum = 0, weightTot = 0
        for e in valid {
            let votoClean = e.voto?.replacingOccurrences(of: " e lode", with: "") ?? ""
            let votoVal = Int(votoClean.components(separatedBy: "/").first ?? "")
            let weight = Int(e.cfa ?? "")
            if let v = votoVal, let w = weight, w > 0 { weightedSum += v * w; weightTot += w }
        }
        let avgStr: String = (weightTot > 0) ? String(format: "%.1f", Double(weightedSum) / Double(weightTot)) : "-"

        let name = (self.displayName ?? "").isEmpty ? "LABA Firenze" : self.displayName!
        let summary = WidgetSummary(displayName: name, passed: passed, totalCFA: totalCFA, average: avgStr)

        if let data = try? JSONEncoder().encode(summary),
           let ud = UserDefaults(suiteName: LABA_APP_GROUP) {
            ud.set(data, forKey: "widget.summary")
            ud.synchronize()
            #if canImport(WidgetKit)
            WidgetCenter.shared.reloadTimelines(ofKind: "LABAWidget")
            #endif
        }
    }

    func signIn(username base: String, password: String) async {
        // Prepare email & base components
        let raw = base.trimmingCharacters(in: .whitespacesAndNewlines)
        let email: String
        let baseOnly: String
        let lower = raw.lowercased()
        if let at = lower.firstIndex(of: "@") {
            // User provided full email
            email = lower
            baseOnly = String(lower[..<at])
        } else {
            // User provided base → normalize and append domain
            baseOnly = normalizeNameForEmail(raw)
            email = baseOnly + labaDomain
        }

        await MainActor.run { self.loading = true; self.error = nil }
        do {
            let token = try await APIClient.shared.loginROPC(email: email, password: password)
            await MainActor.run {
                self.accessToken = token.access_token
                self.isLoggedIn = true
                self.usernameBase = baseOnly
                let comps = baseOnly.split(separator: ".").map(String.init)
                if let first = comps.first { self.displayName = first.capitalized } else { self.displayName = baseOnly.capitalized }
                self.restoreDisabled = false
            }
            self.setWidgetLoginState(true)
            await loadAll()
        } catch {
            await MainActor.run {
                self.error = "Utente o Password errata: Riprova!"
                self.loading = false
                self.isLoggedIn = false
            }
        }
    }

    /// Silent variant: same as signIn but without setting user-facing error messages on failure.
    func signInSilently(username base: String, password: String) async {
        let raw = base.trimmingCharacters(in: .whitespacesAndNewlines)
        let email: String
        let baseOnly: String
        let lower = raw.lowercased()
        if let at = lower.firstIndex(of: "@") {
            email = lower
            baseOnly = String(lower[..<at])
        } else {
            baseOnly = normalizeNameForEmail(raw)
            email = baseOnly + labaDomain
        }

        do {
            let token = try await APIClient.shared.loginROPC(email: email, password: password)
            await MainActor.run {
                self.accessToken = token.access_token
                self.isLoggedIn = true
                self.usernameBase = baseOnly
                let comps = baseOnly.split(separator: ".").map(String.init)
                if let first = comps.first { self.displayName = first.capitalized } else { self.displayName = baseOnly.capitalized }
                self.restoreDisabled = false
            }
            self.setWidgetLoginState(true)
            await loadAll()
        } catch {
            // Fail silently: do not set vm.error
            await MainActor.run {
                self.isLoggedIn = false
            }
        }
    }

    func useManualToken(_ token: String) async {
        await MainActor.run {
            self.error = nil
            self.accessToken = token
            self.isLoggedIn = true
            self.loading = true
        }
        self.setWidgetLoginState(true)
        await loadAll()
    }

    @MainActor
    func restoreSession() async {
        self.isBooting = true
        if restoreDisabled {
            defer { self.isBooting = false }
            print("[Auth] restore disabled (explicit logout)")
            return
        }
        defer { self.isBooting = false }
        print("[Auth] creds:\(KeychainHelper.loadCredentials() != nil) tokenEmpty:\(accessToken.isEmpty)")
        if accessToken.isEmpty {
            // Try silent login only if user opted-in (credentials stored)
            if let creds = KeychainHelper.loadCredentials() {
                await self.signInSilently(username: creds.usernameBase, password: creds.password)
                // If silent login succeeded, the rest of the method's logic will be handled by signInSilently → loadAll()
            }
            if accessToken.isEmpty { return }
        }
        // Ripristina stato loggato
        self.isLoggedIn = true
        self.setWidgetLoginState(true)
        // Ricostruisci il displayName dal usernameBase (es. "nome.cognome" → "Nome")
        if self.displayName == nil || self.displayName?.isEmpty == true {
            let base = self.usernameBase
            let comps = base.split(separator: ".").map(String.init)
            if let first = comps.first { self.displayName = first.capitalized } else { self.displayName = base.capitalized }
        }
        // Carica subito i dati
        await self.loadAll()
    }

    /// Esegue l'operazione passando il token corrente; se riceve 401 prova un restore forte e ritenta una sola volta
    func withAuthRetry<T>(_ attempt: @escaping (String) async throws -> T) async throws -> T {
        let token1 = self.accessToken
        do {
            return try await attempt(token1)
        } catch let err as NSError {
            // Ritenta solo in caso di 401 dal backend
            if err.domain == "API" && err.code == 401 {
                await self.restoreSessionStrong()
                let token2 = self.accessToken
                // se il token è cambiato (o comunque presente), prova una sola volta
                if !token2.isEmpty && token2 != token1 {
                    return try await attempt(token2)
                }
            }
            throw err
        }
    }

    func logout() {
        // Disattiva qualsiasi tentativo di restore finché non c'è un nuovo login manuale
        restoreDisabled = true
        // Pulisci credenziali salvate (Keychain + Defaults di supporto)
        KeychainHelper.deleteCredentials()
        UserDefaults.standard.removeObject(forKey: "laba.username")
        UserDefaults.standard.removeObject(forKey: "laba.password")
        UserDefaults.standard.removeObject(forKey: "laba.savedCredentials")
        // Svuota token e stato utente
        accessToken = ""
        isLoggedIn = false
        loading = false
        error = nil
        displayName = nil
        status = nil
        currentYear = nil
        pianoStudi = nil
        nome = nil
        cognome = nil
        matricola = nil
        sesso = nil
        emailLABA = nil
        emailPersonale = nil
        telefono = nil
        cellulare = nil
        pagamenti = nil
        studentOid = nil
        esami = []
        seminari = []
        notifications = []
        isBooting = false
        // Widget/app group sync
        if let ud = UserDefaults(suiteName: LABA_APP_GROUP) {
            ud.removeObject(forKey: "widget.summary")
            ud.set(false, forKey: "user.isLoggedIn")
            ud.synchronize()
        }
        #if canImport(WidgetKit)
        WidgetCenter.shared.reloadTimelines(ofKind: "LABAWidget")
        #endif
        print("[Auth] User logout → token cleared, restore disabled")
    }

    func graduatedWord() -> String { (sesso ?? "").lowercased().hasPrefix("f") ? "Laureata" : "Laureato" }

    @MainActor
    func loadAll() async {
        guard !accessToken.isEmpty else { return }
        self.loading = true; self.error = nil
        defer { self.loading = false }
        do {
            let payload = try await withAuthRetry { token in try await APIClient.shared.enrollments(token: token) }
            let student = try await withAuthRetry { token in try await APIClient.shared.student(token: token) }
            self.studentOid = student.oid
            self.nome = student.nome
            self.cognome = student.cognome
            self.matricola = student.numMatricola
            self.sesso = student.sesso
            self.emailLABA = student.emailLABA
            self.emailPersonale = student.emailPersonale
            self.telefono = student.telefono
            self.cellulare = student.cellulare
            self.pagamenti = student.pagamenti
            if let n = student.nome, !n.isEmpty { self.displayName = n.capitalized }
            self.status = payload.stato
            self.currentYear = payload.annoAttuale
            self.pianoStudi = payload.pianoStudi
            self.esami = payload.situazioneEsami.map { r in
                Esame(
                    id: r.oidCorso,
                    corso: r.corso,
                    docente: r.docente,
                    anno: r.anno,
                    cfa: r.cfa,
                    propedeutico: r.propedeutico,
                    sostenutoIl: parseAPIDate(r.sostenutoIl),
                    voto: r.voto,
                    richiedibile: (r.richiedibile ?? "N").uppercased() == "S"
                )
            }
            self.updateWidgetSummary()
            if let semPayloads = try? await withAuthRetry({ token in try await APIClient.shared.seminars(token: token) }) {
                self.seminari = semPayloads.map { s in
                    Seminario(
                        id: s.seminarioOid,
                        titolo: s.descrizione,
                        descrizioneEstesa: s.descrizioneEstesa,
                        richiedibile: (s.richiedibile ?? "N").uppercased() == "S",
                        esito: s.esitoRichiesta
                    )
                }
            }
        } catch {
            self.error = error.localizedDescription
        }
    }

    @MainActor
    func loadNotifications() async {
        guard !accessToken.isEmpty else { return }
        do {
            let notifPayloads = try await withAuthRetry { token in
                try await APIClient.shared.notifications(
                    token: token,
                    studentOid: self.studentOid
                )
            }
            var items: [NotificationItem] = notifPayloads.map { n in
                NotificationItem(
                    id: n.id,
                    title: n.oggetto,
                    message: n.messaggio,
                    createdAt: parseAPIDate(n.dataOraCreazione),
                    readAt: parseAPIDate(n.dataOraLetturaNotifica)
                )
            }
            // override locale “lette”
            items = items.map { it in
                var m = it
                if m.readAt == nil && localReadIDs.contains(m.id) { m.readAt = Date.distantPast }
                return m
            }
            items.sort { (a, b) in (a.createdAt ?? .distantPast) > (b.createdAt ?? .distantPast) }
            self.notifications = items
            print("Loaded notifications count = \(items.count)")
        } catch {
            print("Notifications load error: \(error)")
        }
    }

    // MARK: - Lightweight loaders (invocabili singolarmente)
    @MainActor
    func loadEsami() async {
        guard !accessToken.isEmpty else { return }
        do {
            let payload = try await withAuthRetry { token in try await APIClient.shared.enrollments(token: token) }
            self.status = payload.stato
            self.currentYear = payload.annoAttuale
            self.pianoStudi = payload.pianoStudi
            self.esami = payload.situazioneEsami.map { r in
                Esame(
                    id: r.oidCorso,
                    corso: r.corso,
                    docente: r.docente,
                    anno: r.anno,
                    cfa: r.cfa,
                    propedeutico: r.propedeutico,
                    sostenutoIl: parseAPIDate(r.sostenutoIl),
                    voto: r.voto,
                    richiedibile: (r.richiedibile ?? "N").uppercased() == "S"
                )
            }
            self.updateWidgetSummary()
        } catch {
            self.error = error.localizedDescription
        }
    }

    @MainActor
    func loadSeminari() async {
        guard !accessToken.isEmpty else { return }
        do {
            let semPayloads = try await withAuthRetry { token in try await APIClient.shared.seminars(token: token) }
            self.seminari = semPayloads.map { s in
                Seminario(
                    id: s.seminarioOid,
                    titolo: s.descrizione,
                    descrizioneEstesa: s.descrizioneEstesa,
                    richiedibile: (s.richiedibile ?? "N").uppercased() == "S",
                    esito: s.esitoRichiesta
                )
            }
        } catch {
            print("Seminars load error: \(error)")
        }
    }

    /// Alias temporaneo: se/quando avremo un endpoint corsi dedicato lo sostituiremo.
    @MainActor
    func loadCorsi() async {
        await loadEsami()
    }

    func setNotification(_ id: Int, read: Bool) {
        var set = localReadIDs
        if read { set.insert(id) } else { set.remove(id) }
        localReadIDs = set
        if let idx = notifications.firstIndex(where: { $0.id == id }) {
            var item = notifications[idx]
            item.readAt = read ? (item.readAt ?? Date()) : nil
            notifications[idx] = item
        }
        Task { await APIClient.shared.markNotificationRead(token: accessToken, id: id) }
    }

    func markAllNotificationsRead() {
        notifications.enumerated().forEach { idx, it in
            notifications[idx].readAt = notifications[idx].readAt ?? Date()
        }
        localReadIDs = Set(notifications.map { $0.id })
    }
}

// MARK: - Common UI

struct Pill: View {
    enum Kind { case year, grade, cfa, status, alert }
    let text: String
    let kind: Kind
    var tintOverride: Color? = nil
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let base = tintOverride ?? baseColor(for: kind)
        let fillOpacity = scheme == .dark ? 0.22 : 0.16
        let strokeOpacity = scheme == .dark ? 0.55 : 0.30
        Text(text)
            .font(.caption)
            .padding(.vertical, 4)
            .padding(.horizontal, 10)
            .background(
                Capsule()
                    .fill(base.opacity(fillOpacity))
                    .overlay(
                        Capsule().stroke(base.opacity(strokeOpacity), lineWidth: 1)
                    )
            )
    }

    private func baseColor(for kind: Kind) -> Color {
        switch kind {
        case .year: return Color(.systemBlue)
        case .grade: return Color(.systemGreen)
        case .cfa: return Color(.systemOrange)
        case .status: return Color(.systemOrange)
        case .alert: return Color(.systemRed)
        }
    }
}


// MARK: - Animated Background for Login
struct AnimatedPatternBackground: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1.0/15.0)) { timeline in
            let time = timeline.date.timeIntervalSinceReferenceDate
            GeometryReader { geo in
                let base = Color(uiColor: .systemBackground)
                base
                    .overlay(pattern(in: geo.size, time: CGFloat(time)).opacity(0.20))
                    .ignoresSafeArea()
            }
        }
    }

    private func pattern(in size: CGSize, time: CGFloat) -> some View {
        Canvas { ctx, sz in
            let color: Color = (scheme == .dark) ? .white : Color.labaAccent.opacity(0.5)
            let step: CGFloat = 32
            let r: CGFloat = 2.5
            drawPattern(in: &ctx, size: sz, color: color, step: step, r: r, time: time)
        }
    }

    private func drawPattern(in ctx: inout GraphicsContext, size sz: CGSize, color: Color, step: CGFloat, r: CGFloat, time: CGFloat) {
        for y in stride(from: -step, through: sz.height + step, by: step) {
            for x in stride(from: -step, through: sz.width + step, by: step) {
                // Movimento pseudo-casuale e unico per ogni punto:
                let t = time * 0.6
                let seed = (x * 13 + y * 7)
                let dx = sin((x + y) / 140 + t * (1.2 + 0.17 * sin(seed))) * 10 * (0.8 + 0.3 * cos(seed))
                let dy = cos((x - y) / 120 + t * (1.3 + 0.23 * cos(seed + 99))) * 10 * (0.8 + 0.3 * sin(seed + 42))
                let rect = CGRect(x: x + dx, y: y + dy, width: r * 2, height: r * 2)
                ctx.fill(Path(ellipseIn: rect), with: .color(color))
            }
        }
    }
}

// MARK: - Login (SSO + fallback)
struct LoginView: View {
    @EnvironmentObject var vm: SessionVM
    @AppStorage("laba.usernameBase") private var storedUsername: String = ""
    @AppStorage("laba.didPromptNotifications") private var didPromptNotifications: Bool = false

    @State private var userBase = ""
    @State private var password = ""
    @State private var showingInfo = false
    @State private var isLoading = false
    @State private var showManualToken = false
    @State private var manualToken = ""
    @Environment(\.colorScheme) private var colorScheme
    @State private var passwordVisible = false
    @FocusState private var focusedField: Field?
    @State private var startAnimations = false
    private enum Field { case user, password }
    // Easter Egg states
    @State private var showEasterEgg = false
    @State private var isLongPressing = false
    @State private var shakeOffset: CGFloat = 0
    @State private var hapticWork: DispatchWorkItem?
    @State private var shakeWork: DispatchWorkItem?
    // Timers for staged long-press (5s -> effects, 10s -> reveal)
    @State private var fiveWork: DispatchWorkItem?
    @State private var tenWork: DispatchWorkItem?
    @State private var showDebug = false
    // Remember me

    var body: some View {
        NavigationStack {
            ZStack {
                if startAnimations {
                    AnimatedPatternBackground()
                        .transition(.opacity)
                }
                VStack(spacing: 20) {
                    // Logo with Easter Egg long press
                    Group {
                        Image("logoLABA")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200 , height: 200)
                            .foregroundStyle(Color.labaAccent)
                            .font(.system(size: 88))
                            .padding(.top, 36)
                            .offset(x: shakeOffset)
                            .contentShape(Rectangle())
                            .allowsHitTesting(true)
                            .onLongPressGesture(minimumDuration: 10, perform: {
                                // 10s reached: stop effects and reveal
                                stopHaptics()
                                stopShake()
                                withAnimation(.easeInOut(duration: 0.25)) { showEasterEgg = true }
                                isLongPressing = false
                            }, onPressingChanged: { pressing in
                                if pressing {
                                    // finger down -> arm the staged timers
                                    isLongPressing = true
                                    // cancel leftover timers just in case
                                    fiveWork?.cancel(); tenWork?.cancel()

                                    let five = DispatchWorkItem {
                                        if isLongPressing {
                                            startEscalatingHaptics()
                                            startEscalatingShake()
                                        }
                                    }
                                    fiveWork = five
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: five)

                                    let ten = DispatchWorkItem {
                                        if isLongPressing {
                                            stopHaptics()
                                            stopShake()
                                            withAnimation(.easeInOut(duration: 0.25)) { showEasterEgg = true }
                                            isLongPressing = false
                                        }
                                    }
                                    tenWork = ten
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 8, execute: ten)

                                } else {
                                    // finger lifted or gesture cancelled
                                    isLongPressing = false
                                    fiveWork?.cancel(); fiveWork = nil
                                    tenWork?.cancel(); tenWork = nil
                                    stopHaptics()
                                    stopShake()
                                }
                            })
                    }
                    
                    // Inputs
                    VStack(spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "person.fill").foregroundStyle(.secondary)
                            TextField("nome.cognome", text: $userBase)
                                .textContentType(.username)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .focused($focusedField, equals: .user)
                                .submitLabel(.next)
                                .onSubmit { focusedField = .password }
                            if !Device.isMini {
                                Text("@labafirenze.com").foregroundStyle(.secondary)
                            }
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 60).fill(Color.cardBG))
                        .padding(.horizontal)

                        HStack(spacing: 12) {
                            Image(systemName: "lock.fill").foregroundStyle(.secondary)
                            if passwordVisible {
                                TextField("Password", text: $password)
                                    .textContentType(.password)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .focused($focusedField, equals: .password)
                                    .submitLabel(.go)
                                    .onSubmit { Task { await doLogin() } }
                            } else {
                                SecureField("Password", text: $password)
                                    .textContentType(.password)
                                    .textInputAutocapitalization(.never)
                                    .focused($focusedField, equals: .password)
                                    .submitLabel(.go)
                                    .onSubmit { Task { await doLogin() } }
                            }
                            Spacer()
                            Button(action: {
                                passwordVisible.toggle()
                                DispatchQueue.main.async { focusedField = .password }
                            }) { Image(systemName: passwordVisible ? "eye.slash.fill" : "eye.fill")
                                .foregroundStyle(.secondary)
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 60).fill(Color.cardBG))
                        .padding(.horizontal)
                    }



                    if let err = vm.error, !err.isEmpty {
                        Text(err).font(.footnote).foregroundStyle(.red)
                    }

                    Button(action: { Task { await doLogin() } }) {
                        if vm.loading || isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Text("Entra")
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity, minHeight: 30) // più largo e alto
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color.labaAccent)
                    .font(.headline)
                    .padding(.horizontal, 12) // margine laterale
                    .buttonBorderShape(.roundedRectangle(radius: 50))
                    .disabled(userBase.isEmpty || password.isEmpty || vm.loading || isLoading)

                    Spacer(minLength: 16)

                    Text("© 2025 LABA Firenze - with 💙 by Simone Azzinelli")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.bottom, 10)
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingInfo = true } label: { Image(systemName: "info.circle") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showDebug = true } label: {
                        Image(systemName: "ladybug")
                    }
                    .accessibilityLabel("Apri Debug")
                }
            }
            .sheet(isPresented: $showingInfo) {
                AccessHelpSheet()
                    .presentationDetents([.large, .medium])
                    .presentationDragIndicator(.visible)
            }
            .sheet(isPresented: $showDebug) {
                DebugView()
                    .environmentObject(vm)
            }
            .onAppear {
                // First-run after install: ensure no stale Keychain from previous uninstall
                let firstRun = !UserDefaults.standard.bool(forKey: "laba.installMarker")
                if firstRun {
                    KeychainHelper.deleteCredentials()
                    UserDefaults.standard.set(true, forKey: "laba.installMarker")
                    print("[Auth] First run after install → cleared Keychain")
                }
                if !storedUsername.isEmpty { userBase = storedUsername }
                // Warm up common SF Symbols once so tab bar icons render instantly later
                warmUpSymbols()
                // Defer animated background slightly to avoid fighting with first-frame UI work
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.easeInOut(duration: 0.25)) { startAnimations = true }
                }
                // Allinea lo stato grafico del toggle alla realtà: attivo solo se ho davvero credenziali salvate
            }
            .overlay(alignment: .center) {
                if vm.isBooting {
                    AppLoadingView()
                        .transition(.opacity)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                }
            }
            .task {
                if !vm.isLoggedIn {
                    await vm.restoreSession()
                }
            }
            .fullScreenCover(isPresented: $showEasterEgg) {
                LABAEggView(onClose: { showEasterEgg = false })
                    .transition(.opacity)
            }
        }
    }

    private func doLogin() async {
        isLoading = true
        defer { isLoading = false }
        await vm.signIn(username: userBase, password: password)
        // Al primo login riuscito, chiedi i permessi push (solo una volta)
        if vm.isLoggedIn {
            let lowered = userBase.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let baseOnly: String
            if let at = lowered.firstIndex(of: "@") {
                baseOnly = String(lowered[..<at])
            } else {
                baseOnly = normalizeNameForEmail(lowered)
            }
            KeychainHelper.saveCredentials(usernameBase: baseOnly, password: password)
            UserDefaults.standard.set(baseOnly, forKey: "laba.username")
            UserDefaults.standard.set(password, forKey: "laba.password")
            UserDefaults.standard.set(true, forKey: "laba.savedCredentials")
            requestPushPermissionIfNeeded()
        }
    }
    private func requestPushPermissionIfNeeded() {
        guard !didPromptNotifications else { return }
        didPromptNotifications = true
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, _ in
            if granted {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            } else {
                print("[FCM] notifications permission not granted — skipping APNs registration")
            }
        }
    }

    // MARK: - Escalation Haptics (5s..10s)
    private func startEscalatingHaptics() {
        stopHaptics()
        var work: DispatchWorkItem! // predeclare so the closure can reference it
        work = DispatchWorkItem {
            let start = Date()
            func step() {
                guard isLongPressing, work != nil, !work.isCancelled else { return }
                let elapsed = Date().timeIntervalSince(start)
                guard elapsed < 5.0 else { return } // runs only during 5..10s window

                // progress 0..1
                let t = max(0, min(1, elapsed / 5.0))
                // interval ramps from slow(0.6s) to fast(0.06s)
                let interval = 0.6 - (0.54 * t)
                // haptic style increases over time
                let style: UIImpactFeedbackGenerator.FeedbackStyle = t > 0.7 ? .heavy : (t > 0.35 ? .medium : .light)
                let gen = UIImpactFeedbackGenerator(style: style)
                gen.impactOccurred()

                DispatchQueue.main.asyncAfter(deadline: .now() + interval) { step() }
            }
            step()
        }
        hapticWork = work
        DispatchQueue.main.async(execute: work)
    }

    private func stopHaptics() {
        hapticWork?.cancel()
        hapticWork = nil
    }

    // MARK: - Escalation Shake (ampiezza/frequenza crescenti 5s..10s)
    private func startEscalatingShake() {
        stopShake()
        var work: DispatchWorkItem! // predeclare so the closure can reference it
        work = DispatchWorkItem {
            let start = Date()
            func step() {
                guard isLongPressing, work != nil, !work.isCancelled else { shakeOffset = 0; return }
                let elapsed = Date().timeIntervalSince(start)
                guard elapsed < 5.0 else { shakeOffset = 0; return }

                // progress 0..1
                let t = max(0, min(1, elapsed / 5.0))
                // amplitude from 0pt to 14pt
                let amplitude: CGFloat = 14 * t
                // frequency grows: period from 0.18s down to 0.06s
                let period = 0.18 - (0.12 * t)

                withAnimation(.easeInOut(duration: period/2)) { shakeOffset = amplitude }
                DispatchQueue.main.asyncAfter(deadline: .now() + period/2) {
                    withAnimation(.easeInOut(duration: period/2)) { shakeOffset = -amplitude }
                    DispatchQueue.main.asyncAfter(deadline: .now() + period/2) { step() }
                }
            }
            step()
        }
        shakeWork = work
        DispatchQueue.main.async(execute: work)
    }

    private func stopShake() {
        shakeWork?.cancel()
        shakeWork = nil
        shakeOffset = 0
    }
}

struct AccessHelpSheet: View {
    @Environment(\.openURL) private var openURL

    var body: some View {
        VStack(spacing: 8) {
            // Grabber neutro (rispetta Light/Dark)
            Capsule()
                .fill(Color.secondary.opacity(0.35))
                .frame(width: 36, height: 5)
                .padding(.top, 6)

            Text("Assistenza")
                .font(.title2).bold()
                .padding(.top, 2)
            Spacer().frame(height: 6)

            List {
                // Guida rapida
                Section("Guida rapida") {
                    VStack(alignment: .leading, spacing: 12) {
                        Label("Accedi utilizzando nome.cognome", systemImage: "at")
                        Label("Controlla maiuscole/minuscole", systemImage: "textformat")
                        Label("Evita spazi iniziali/finali nei campi", systemImage: "rectangle.and.pencil.and.ellipsis")
                        Label("Hai appena cambiato password? Attendi un po'", systemImage: "clock")
                    }
                    .font(.subheadline)
                }

                // Recupero credenziali — stile riga standard (no pulsante blu)
                Section("Recupero credenziali") {
                    Button {
                        let subject = "Assistenza accesso"
                        let body = "Nome e cognome:%0A Matricola:%0A Dispositivo: iPhone/iPad%0A Versione iOS:%0A%0A Descrizione problema:%0A"
                        let urlString = "mailto:info@laba.biz?subject=\(subject.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? subject)&body=\(body)"
                        if let url = URL(string: urlString) { openURL(url) }
                    } label: {
                        HStack {
                            Label("Richiedi reset password", systemImage: "key.fill")
                            Spacer(minLength: 8)
                        }
                    }
                    .buttonStyle(.plain)
                }

                // Link utili — Sito e numeri (NO privacy policy)
                Section("Link utili") {
                    Link(destination: URL(string: "https://www.laba.biz")!) {
                        Label("Sito LABA", systemImage: "globe")
                    }
                    Button {
                        if let url = URL(string: "tel://0556530786") { openURL(url) }
                    } label: {
                        HStack {
                            Label("Chiama Segreteria Didattica", systemImage: "phone.fill")
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .contentShape(Rectangle())
                    }
                    .tint(.blue)
                    .buttonStyle(.plain)

                    Button {
                        if let url = URL(string: "tel://3343824934") { openURL(url) }
                    } label: {
                        HStack {
                            Label("Reparto IT", systemImage: "phone.fill")
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .contentShape(Rectangle())
                    }
                    .tint(.blue)
                    .buttonStyle(.plain)
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
        }
        .padding(.bottom, 0)
        .background(Color(uiColor: .systemGroupedBackground))
    }
}


struct NotificationRow: View {
    let title: String
    let subtitle: String
    let pillLabel: String?
    let date: Date?
    let isRead: Bool
    let onToggleRead: () -> Void

    private static let relIT: RelativeDateTimeFormatter = {
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "it_IT")
        f.unitsStyle = .full
        return f
    }()
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            if !isRead {
                Circle()
                    .frame(width: 8, height: 8)
                    .foregroundStyle(Color.labaAccent)
                    .padding(.top, 6)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.body.weight(.semibold))
                    .lineLimit(2)
                if !subtitle.isEmpty || pillLabel != nil {
                    HStack(spacing: 6) {
                        if let pill = pillLabel {
                            Pill(text: pill, kind: .status, tintOverride: Color.labaAccent)
                        }
                        if !subtitle.isEmpty {
                            Text(subtitle)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }
                    }
                }
            }

            Spacer(minLength: 8)

            if let d = date {
                Text(Self.relIT.localizedString(for: d, relativeTo: Date()))
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.trailing)
            }
        }
        .contentShape(Rectangle())
        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
            Button(action: onToggleRead) {
                Label(isRead ? "Segna da leggere" : "Segna come letta",
                      systemImage: isRead ? "envelope.badge" : "checkmark")
            }
            .tint(isRead ? .orange : .green)
        }
    }
}

struct NotificheView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var showOnlyUnread = false

    private var list: [NotificationItem] {
        showOnlyUnread ? vm.notifications.filter { !$0.isRead } : vm.notifications
    }

    private func preview(from message: String) -> String {
        let s = message.replacingOccurrences(of: "\n", with: " ")
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        List {
            if list.isEmpty {
                Section {
                    if #available(iOS 17.0, *) {
                        ContentUnavailableView(
                            "Nessuna comunicazione",
                            systemImage: "bell.slash",
                            description: Text("Le comunicazioni dall'accademia appariranno qui."))
                    } else {
                        VStack(spacing: 8) {
                            Image(systemName: "bell.slash").font(.largeTitle).foregroundStyle(.secondary)
                            Text("Nessuna comunicazione").font(.headline)
                            Text("Le comunicazioni dall'accademia appariranno qui.").font(.footnote).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 24)
                    }
                }
            } else {
                Section {
                    ForEach(list) { n in
                        let materia = prettifyTitle(parsedCourse(from: n.message))
                        let subject = subjectFor(n.message)
                        let pill = labelPillFor(n.message)
                        NotificationRow(
                            title: materia,
                            subtitle: subject,
                            pillLabel: pill,
                            date: n.createdAt,
                            isRead: n.isRead
                        ) {
                            vm.setNotification(n.id, read: !n.isRead)
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Avvisi")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if !vm.notifications.isEmpty {
                    Menu {
                        Toggle(isOn: $showOnlyUnread) { Label("Solo non lette", systemImage: "envelope.badge") }
                        Button(role: .none) { vm.markAllNotificationsRead() } label: { Label("Segna tutte come lette", systemImage: "checkmark.circle") }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
        .refreshable {
            await vm.loadNotifications()
        }
        .task { await vm.loadNotifications() }
    }
    
    private func parsedCourse(from message: String) -> String {
        let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)

        // "Dispensa di <Materia> ..." oppure "Programma di <Materia> ..."
        if let re = try? NSRegularExpression(
            pattern: "(?i)(?:inserita\\s+)?(?:dispensa|programma)\\s+di\\s+(.+?)(?=\\s*[-–—]|\\s+inserit|\\s+caricat|$)"
        ),
           let match = re.firstMatch(in: trimmed, range: NSRange(trimmed.startIndex..., in: trimmed)),
           match.numberOfRanges >= 2,
           let r = Range(match.range(at: 1), in: trimmed) {
            return prettifyTitle(String(trimmed[r]))
        }

        // Se dopo un trattino c'è "Dispensa …" o "Programma …", taglia prima del trattino
        var guess = trimmed
        let lowers = guess.lowercased()
        for sep in [" - ", " – ", " — "] {
            if let range = lowers.range(of: sep) {
                let after = lowers[range.upperBound...].trimmingCharacters(in: .whitespaces)
                if after.hasPrefix("dispensa") || after.hasPrefix("programma") {
                    guess = String(guess[..<range.lowerBound])
                    break
                }
            }
        }

        // Pulisci prefissi/suffissi
        var gLower = guess.lowercased()
        if gLower.hasPrefix("inserita ") { guess = String(guess.dropFirst("inserita ".count)); gLower = guess.lowercased() }
        if gLower.hasPrefix("dispensa di ") { guess = String(guess.dropFirst("dispensa di ".count)); gLower = guess.lowercased() }
        if gLower.hasPrefix("programma di ") { guess = String(guess.dropFirst("programma di ".count)); gLower = guess.lowercased() }
        if gLower.hasSuffix(" inserita") { guess = String(guess.dropLast(" inserita".count)); gLower = guess.lowercased() }
        if gLower.hasSuffix(" caricato") { guess = String(guess.dropLast(" caricato".count)) }

        return prettifyTitle(guess)
    }

    private func subjectFor(_ message: String) -> String {
        let s = message.trimmingCharacters(in: .whitespacesAndNewlines)
        // Programma: "Programma n. 3" / "Programma num 3" / "Programma numero 3" (numero opzionale)
        if let rx = try? NSRegularExpression(pattern: #"(?i)programma\s*(?:n\.|num\.?|numero)?\s*(\d+)?"#),
           let m = rx.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) {
            if let r = Range(m.range(at: 1), in: s) {
                let num = String(s[r])
                if !num.isEmpty { return " \(num) inserito" }
            }
            return "Programma inserito"
        }
        // Dispensa: "Dispensa n. 3" / "Dispensa num 3" / "Dispensa numero 3" (numero opzionale)
        if let rx = try? NSRegularExpression(pattern: #"(?i)dispensa\s*(?:n\.|num\.?|numero)?\s*(\d+)?"#),
           let m = rx.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) {
            if let r = Range(m.range(at: 1), in: s) {
                let num = String(s[r])
                if !num.isEmpty { return "Dispensa \(num) inserita" }
            }
            return " inserita"
        }
        if s.lowercased().contains("programma") { return "inserito" }
        if s.lowercased().contains("dispensa") { return "inserita" }
        return "Avviso"
    }

    private func labelPillFor(_ message: String) -> String? {
        let l = message.lowercased()
        if l.contains("dispensa") { return "Dispensa" }
        if l.contains("programma") { return "Programma" }
        return nil
    }
}

private func subjectFor(_ message: String) -> String {
    let s = message.trimmingCharacters(in: .whitespacesAndNewlines)
    // Programma: "Programma n. 3" / "Programma num 3" / "Programma numero 3" (numero opzionale)
    if let rx = try? NSRegularExpression(pattern: #"(?i)programma\s*(?:n\.|num\.?|numero)?\s*(\d+)?"#),
       let m  = rx.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) {
        if let r = Range(m.range(at: 1), in: s) {
            let num = String(s[r])
            if !num.isEmpty { return " \(num) inserito" }
        }
        return " inserito"
    }
    // Dispensa: "Dispensa n. 3" / "Dispensa num 3" / "Dispensa numero 3" (numero opzionale)
    if let rx = try? NSRegularExpression(pattern: #"(?i)dispensa\s*(?:n\.|num\.?|numero)?\s*(\d+)?"#),
       let m  = rx.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) {
        if let r = Range(m.range(at: 1), in: s) {
            let num = String(s[r])
            if !num.isEmpty { return "Dispensa \(num) inserita" }
        }
        return " inserita"
    }
    if s.lowercased().contains("programma") { return "Programma inserito" }
    if s.lowercased().contains("dispensa") { return "Dispensa inserita" }
    return "Avviso"
}

// MARK: - Esami

struct ExamsView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var selectedYear: Int = 0 // 0 = tutti (chips)
    @State private var statusFilter: StatusFilter = .all
    @State private var queryRaw: String = ""
    @State private var query: String = ""
    @State private var debounceItem: DispatchWorkItem? = nil
    @Environment(\.colorScheme) private var colorScheme

    private enum StatusFilter: CaseIterable { case all, passed, pending }

    private let years: [Int] = [1, 2, 3]
    private var filteredByYear: [Esame] { vm.esami.filter { $0.anno == selectedYear } }
    private var filteredByStatus: [Esame] {
        switch statusFilter {
        case .all:
            return filteredByYear
        case .passed:
            return filteredByYear.filter { e in
                let votoTrim = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                return !votoTrim.isEmpty || isIdoneitaVote(e.voto) || e.sostenutoIl != nil
            }
        case .pending:
            return filteredByYear.filter { e in
                let votoTrim = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                return votoTrim.isEmpty && !isIdoneitaVote(e.voto) && e.sostenutoIl == nil
            }
        }
    }
    private var filtered: [Esame] {
        // Base già filtrata (per anno/stato) — usa l’array che stai mostrando nel body
        let base = filteredByStatus

        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if q.isEmpty { return base }

        let qLower = q.lowercased()
        let numericQuery: Int? = {
            let digits = q.filter { $0.isNumber }
            return digits.isEmpty ? nil : Int(digits)
        }()

        return base.filter { e in
            // Titolo corso o docente
            if prettifyTitle(e.corso).localizedCaseInsensitiveContains(q) { return true }
            if (e.docente ?? "").localizedCaseInsensitiveContains(q) { return true }

            // Ricerca per voto numerico (es. "28" -> 28/30)
            if let want = numericQuery, let got = voteNumber(from: e.voto), want == got { return true }

            // Ricerca per idoneità
            if qLower.contains("idone"), isIdoneitaVote(e.voto) { return true }

            return false
        }
    }

    private var statusTitle: String {
        switch statusFilter {
        case .all: return "Tutti"
        case .passed: return "Sostenuti"
        case .pending: return "Non sostenuti"
        }
    }

    private func isOther(_ e: Esame) -> Bool {
        let t = e.corso.lowercased()
        return t.contains("attivit") || t.contains("tesi")
    }

    // Estrae il numero di voto (es. "28/30" -> 28); nil se non presente
    private func voteNumber(from voto: String?) -> Int? {
        guard let v = voto?.trimmingCharacters(in: .whitespacesAndNewlines), !v.isEmpty else { return nil }
        let comps = v.components(separatedBy: "/")
        if let first = comps.first?.trimmingCharacters(in: .whitespaces),
           let n = Int(first) { return n }
        return nil
    }

    // True se il voto è un'esito di idoneità
    private func isIdoneitaVote(_ voto: String?) -> Bool {
        guard let v = voto?.lowercased() else { return false }
        return v.contains("idoneo") || v.contains("idonea") || v.contains("idoneità")
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Anno", selection: $selectedYear) {
                        ForEach(years, id: \.self) { y in
                            Text(italianOrdinalYear(y)).tag(y)
                        }
                    }
                    .pickerStyle(.segmented)
                    .tint(Color.labaAccent)
                }
                .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                .listRowSeparator(.hidden)
                .listRowBackground(Color.clear)

                Section {
                    ForEach(filtered.filter { !isOther($0) }) { e in
                        NavigationLink { ExamDetailView(esame: e).environmentObject(vm) } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(prettifyTitle(e.corso)).font(.body).bold()
                                if let docente = e.docente, !docente.isEmpty { Text(docente).font(.subheadline).foregroundStyle(.secondary) }
                                HStack(spacing: 8) {
                                    if let a = e.anno { Pill(text: italianOrdinalYear(a), kind: .year, tintOverride: yearTint(a)) }
                                    // Stato di questo esame
                                    if let v = e.voto, !v.isEmpty {
                                        Pill(text: v, kind: .grade)
                                    } else {
                                        Pill(text: "Da sostenere", kind: .alert)
                                    }
                                }
                                .padding(.top, 4)
                            }
                        }
                    }
                }

                let workshops = filtered.filter { $0.corso.uppercased().contains("ATTIVITA' A SCELTA") }
                if !workshops.isEmpty {
                    Section {
                        ForEach(workshops) { e in
                            NavigationLink { ExamDetailView(esame: e).environmentObject(vm) } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prettifyTitle(e.corso)).font(.body).bold()
                                    if let docente = e.docente, !docente.isEmpty { Text(docente).font(.subheadline).foregroundStyle(.secondary) }
                                }
                            }
                        }
                    } header: {
                        Text("Workshop / Seminari / Tirocinio")
                    }
                }

                let thesis = filtered.filter { $0.corso.uppercased().contains("TESI FINALE") }
                if !thesis.isEmpty {
                    Section {
                        ForEach(thesis) { e in
                            NavigationLink { ExamDetailView(esame: e).environmentObject(vm) } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prettifyTitle(e.corso)).font(.body).bold()
                                    if let docente = e.docente, !docente.isEmpty { Text(docente).font(.subheadline).foregroundStyle(.secondary) }
                                }
                            }
                        }
                    } header: {
                        Text("Tesi Finale")
                    }
                }
            }
            .listStyle(.insetGrouped)
            .listSectionSpacing(.compact)
            .scrollContentBackground(.hidden)
            .navigationTitle("Esami")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $queryRaw, placement: .navigationBarDrawer(displayMode: .always), prompt: "Cerca esami")
            .searchPresentationToolbarBehavior(.avoidHidingContent)
            .onChange(of: queryRaw) { _, newValue in
                debounceItem?.cancel()
                let w = DispatchWorkItem {
                    self.query = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
                }
                debounceItem = w
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: w)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Picker("Stato", selection: $statusFilter) {
                            Text("Tutti").tag(StatusFilter.all)
                            Text("Sostenuti").tag(StatusFilter.passed)
                            Text("Non sostenuti").tag(StatusFilter.pending)
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "line.3.horizontal.decrease.circle")
                            Text(statusTitle)
                        }
                        .tint(Color.labaAccent)
                    }
                }
            }
            .onAppear {
                if selectedYear == 0 { selectedYear = vm.currentYear ?? 1 }
            }
            .animation(nil, value: statusFilter)
            .animation(nil, value: selectedYear)
            .animation(nil, value: query)
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}


struct ExamDetailView: View {
    let esame: Esame
    @EnvironmentObject var vm: SessionVM
    @State private var showBookingAlert = false

    var body: some View {
        List {
            Section {
                HStack { Text("Materia"); Spacer(); Text(prettifyTitle(esame.corso)).multilineTextAlignment(.trailing) }
                if let d = esame.docente { HStack { Text("Docente"); Spacer(); Text(d).multilineTextAlignment(.trailing) } }
                if let a = esame.anno { HStack { Text("Anno" ); Spacer(); Text(italianOrdinalYear(a)) } }
                if let cfa = esame.cfa { HStack { Text("CFA"); Spacer(); Text(cfa) } }
                if let d = esame.sostenutoIl { HStack { Text("Data"); Spacer(); Text(ddMMyyyy(d)) } }
                if let v = esame.voto, !v.isEmpty { HStack { Text("Voto"); Spacer(); Text(v) } }
            } header: {
                Text("Dettagli")
            }
            
            if let prev = vm.esami.first(where: { ($0.propedeutico ?? "").uppercased().contains(esame.corso.uppercased()) }) {
                Section {
                    HStack {
                        let passed = !(prev.voto ?? "").isEmpty
                        Image(systemName: passed ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                            .foregroundStyle(passed ? .green : .orange)
                        VStack(alignment: .leading) {
                            Text(prettifyTitle(prev.corso)).bold()
                            if let v = prev.voto, !v.isEmpty {
                                Text("Voto: \(v)").font(.footnote).foregroundStyle(.secondary)
                            }
                            if (prev.voto ?? "").isEmpty {
                                Pill(text: "Da sostenere", kind: .alert)
                            }
                        }
                    }
                } header: {
                    Text("Precedente richiesto")
                } footer: {
                    Text("È necessario aver superato questo esame per poter prenotare \(prettifyTitle(esame.corso)).")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }


            if let p = esame.propedeutico, !p.isEmpty {
                let clean = p.replacingOccurrences(of: "Corso propedeutico per ", with: "")
                Section {
                    HStack {
                        Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                        Text(prettifyTitle(clean)).bold()
                    }
                    .accessibilityLabel("Propedeuticità: \(prettifyTitle(clean))")
                } header: {
                    Text("Propedeuticità")
                } footer: {
                    Text("Superando \(prettifyTitle(esame.corso)) potrai prenotare i corsi indicati di seguito.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            
            Section {
                if esame.richiedibile {
                    Button { showBookingAlert = true } label: { Label("Prenota ora", systemImage: "calendar.badge.plus") }
                } else {
                    Text("Prenotazione non disponibile").foregroundStyle(.secondary)
                }
            } header: {
                Text("Prenotazione")
            }
        }
        .navigationTitle("Dettagli esame")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Prenotazione", isPresented: $showBookingAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Collegheremo qui l'endpoint di prenotazione appena disponibile.")
        }
    }
}

// MARK: - Corsi

struct CorsiView: View {
    @EnvironmentObject var vm: SessionVM
    @Environment(\.openURL) private var openURL
    @State private var selectedYear: Int = 0 // 0 = tutti
    @State private var mailPulse: Bool = false
    @State private var query: String = ""
    @Environment(\.colorScheme) private var colorScheme

    private var years: [Int] { let ys = Set(vm.esami.compactMap { $0.anno }); return [0] + ys.sorted() }
    private var filteredByYear: [Esame] { selectedYear == 0 ? vm.esami : vm.esami.filter { $0.anno == selectedYear } }
    // Estrae il numero di voto (es. "28/30" -> 28); restituisce nil se non presente
    private func voteNumber(from voto: String?) -> Int? {
        guard let v = voto?.trimmingCharacters(in: .whitespacesAndNewlines), !v.isEmpty else { return nil }
        // Formato tipico: "28/30" oppure "30 / 30" ecc.
        let comps = v.components(separatedBy: "/")
        if let first = comps.first?.trimmingCharacters(in: .whitespaces), let n = Int(first) { return n }
        return nil
    }

    // True se il voto rappresenta un'idoneità
    private func isIdoneitaVote(_ voto: String?) -> Bool {
        guard let v = voto?.lowercased() else { return false }
        return v.contains("idoneo") || v.contains("idonea") || v.contains("idoneità")
    }

    private var filtered: [Esame] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if q.isEmpty { return filteredByYear }
        let qLower = q.lowercased()
        let numericQuery: Int? = {
            let digits = q.filter({ $0.isNumber })
            return digits.isEmpty ? nil : Int(digits)
        }()

        return filteredByYear.filter { c in
            // 1) titolo corso o docente
            if prettifyTitle(c.corso).localizedCaseInsensitiveContains(q) { return true }
            if (c.docente ?? "").localizedCaseInsensitiveContains(q) { return true }
            // 2) ricerca per voto numerico (es. "28" → trova 28/30)
            if let want = numericQuery, let got = voteNumber(from: c.voto), want == got { return true }
            // 3) ricerca per idoneità (query contiene "idoneo/a/ità")
            if qLower.contains("idone"), isIdoneitaVote(c.voto) { return true }
            return false
        }
    }

    private func isOther(_ e: Esame) -> Bool {
        let t = e.corso.lowercased()
        return t.contains("attivit") || t.contains("tesi")
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(filtered.filter { !isOther($0) }) { c in
                        NavigationLink {
                            CourseDetailView(corso: c).environmentObject(vm)
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(prettifyTitle(c.corso)).font(.body).bold().lineLimit(2)
                                if let d = c.docente, !d.isEmpty { Text(d).font(.subheadline).foregroundStyle(.secondary) }
                                HStack(spacing: 8) {
                                    if let a = c.anno { Pill(text: italianOrdinalYear(a), kind: .year, tintOverride: yearTint(a)) }
                                    if let cfa = c.cfa, !cfa.isEmpty { Pill(text: "CFA \(cfa)", kind: .cfa) }
                                }
                                .padding(.top, 4)
                            }
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                            if let docente = c.docente, let first = teacherEmails(from: docente).first,
                               let url = URL(string: "mailto:\(first)") {
                                Button { openURL(url) } label: { Label("Invia mail", systemImage: "envelope.fill") }
                                    .tint(Color.labaAccent)
                            }
                        }
                    }
                }

                let workshops = filtered.filter { $0.corso.uppercased().contains("ATTIVITA' A SCELTA") }
                if !workshops.isEmpty {
                    Section {
                        ForEach(workshops) { c in
                            NavigationLink {
                                CourseDetailView(corso: c).environmentObject(vm)
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prettifyTitle(c.corso)).font(.body).bold().lineLimit(2)
                                    if let d = c.docente, !d.isEmpty { Text(d).font(.subheadline).foregroundStyle(.secondary) }
                                    HStack(spacing: 8) {
                                        if let a = c.anno { Pill(text: italianOrdinalYear(a), kind: .year, tintOverride: yearTint(a)) }
                                        if let cfa = c.cfa, !cfa.isEmpty { Pill(text: "CFA \(cfa)", kind: .cfa) }
                                    }
                                    .padding(.top, 4)
                                }
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                if let docente = c.docente, let first = teacherEmails(from: docente).first,
                                   let url = URL(string: "mailto:\(first)") {
                                    Button { openURL(url) } label: { Label("Invia mail", systemImage: "envelope.fill") }
                                        .tint(Color.labaAccent)
                                }
                            }
                        }
                    } header: {
                        Text("Workshop / Seminari / Tirocinio")
                    }
                }

                let thesis = filtered.filter { $0.corso.uppercased().contains("TESI FINALE") }
                if !thesis.isEmpty {
                    Section {
                        ForEach(thesis) { c in
                            NavigationLink {
                                CourseDetailView(corso: c).environmentObject(vm)
                            } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prettifyTitle(c.corso)).font(.body).bold().lineLimit(2)
                                    if let d = c.docente, !d.isEmpty { Text(d).font(.subheadline).foregroundStyle(.secondary) }
                                    HStack(spacing: 8) {
                                        if let a = c.anno { Pill(text: italianOrdinalYear(a), kind: .year, tintOverride: yearTint(a)) }
                                        if let cfa = c.cfa, !cfa.isEmpty { Pill(text: "CFA \(cfa)", kind: .cfa) }
                                    }
                                    .padding(.top, 4)
                                }
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                if let docente = c.docente, let first = teacherEmails(from: docente).first,
                                   let url = URL(string: "mailto:\(first)") {
                                    Button { openURL(url) } label: { Label("Invia mail", systemImage: "envelope.fill") }
                                        .tint(Color.labaAccent)
                                }
                            }
                        }
                    } header: {
                        Text("Tesi Finale")
                    }
                }
            }
            .listStyle(.insetGrouped)
            .listSectionSpacing(.compact)
            .scrollContentBackground(.hidden)
            .navigationTitle("Corsi")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Cerca corsi")
            .searchPresentationToolbarBehavior(.avoidHidingContent)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Picker("Anno", selection: $selectedYear) {
                            Text("Tutti").tag(0)
                            ForEach(years.filter { $0 != 0 }, id: \.self) { y in Text(italianOrdinalYear(y)).tag(y) }
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "line.3.horizontal.decrease.circle")
                            Text(selectedYear == 0 ? "Tutti" : italianOrdinalYear(selectedYear))
                        }
                    }
                }
            }
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}


struct CourseDetailView: View {
    @EnvironmentObject var vm: SessionVM
    @Environment(\.openURL) private var openURL
    let corso: Esame
    @Environment(\.colorScheme) private var colorScheme

    private var docenteEmail: String? {
        guard let d = corso.docente else { return nil }
        return teacherEmails(from: d).first
    }

    // Questo corso è propedeutico per...
    private var nextCourses: [String] {
        if let p = corso.propedeutico {
            let clean = p.replacingOccurrences(of: "Corso propedeutico per ", with: "").trimmingCharacters(in: .whitespaces)
            return clean.isEmpty ? [] : [clean]
        }
        return []
    }

    // Per questo corso è richiesto aver sostenuto...
    private var previousRequired: Esame? {
        vm.esami.first { e in
            let target = corso.corso.uppercased()
            let p = (e.propedeutico ?? "").uppercased()
            return p.contains(target)
        }
    }

    var body: some View {
        List {
            Section {
                HStack { Text("Materia"); Spacer(); Text(prettifyTitle(corso.corso)).multilineTextAlignment(.trailing) }
                if let d = corso.docente { HStack { Text("Docente"); Spacer(); Text(d).multilineTextAlignment(.trailing) } }
                if let a = corso.anno { HStack { Text("Anno"); Spacer(); Text(italianOrdinalYear(a)) } }
                if let cfa = corso.cfa { HStack { Text("CFA"); Spacer(); Text(cfa) } }
            } header: {
                Text("Dettagli corso")
            }
            
            if let prev = previousRequired {
                Section {
                    HStack {
                        let passed = !(prev.voto ?? "").isEmpty
                        Image(systemName: passed ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                            .foregroundStyle(passed ? .green : .orange)
                        VStack(alignment: .leading) {
                            Text(prettifyTitle(prev.corso)).bold()
                            if let v = prev.voto, !v.isEmpty {
                                Text("Voto: \(v)").font(.footnote).foregroundStyle(.secondary)
                            }
                            if (prev.voto ?? "").isEmpty {
                                Pill(text: "Da sostenere", kind: .alert)
                            }
                        }
                    }
                } header: {
                    Text("Precedente richiesto")
                } footer: {
                    Text("Devi aver superato questo esame per poter prenotare \(prettifyTitle(corso.corso)).")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if !nextCourses.isEmpty {
                Section {
                    ForEach(nextCourses, id: \.self) { name in
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                            Text(prettifyTitle(name)).bold()
                        }
                    }
                } header: {
                    Text("Propedeuticità")
                } footer: {
                    Text("Superando \(prettifyTitle(corso.corso)) potrai prenotare gli esami elencati.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }

            if let email = docenteEmail, let url = URL(string: "mailto:\(email)") {
                Section {
                    Button {
                        openURL(url)
                    } label: {
                        Label("Invia mail al docente", systemImage: "envelope.fill")
                            .font(.headline.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .foregroundColor(colorScheme == .dark ? .black : .white)
                    }
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.roundedRectangle(radius: 12))
                    .padding(.vertical, 0)
                    .tint(Color.labaAccent)
                }
            }
        }
        .navigationTitle("Dettagli corso")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Seminari

struct SeminariView: View {
    @EnvironmentObject var vm: SessionVM
    @Environment(\.colorScheme) private var colorScheme
    @State private var query: String = ""
    private var filtered: [Seminario] {
        guard !query.isEmpty else { return vm.seminari }
        return vm.seminari.filter { prettifyTitle(seminarTitle(from: $0.titolo)).localizedCaseInsensitiveContains(query) }
    }
    var body: some View {
        NavigationStack {
            List {
                if vm.seminari.isEmpty {
                    Section {
                        Text("Nessun seminario disponibile").foregroundStyle(.secondary)
                    }
                } else {
                    Section {
                        ForEach(filtered) { s in
                            NavigationLink { SeminarioDetailView(seminario: s) } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(prettifyTitle(seminarTitle(from: s.titolo))).font(.body).bold().lineLimit(3)
                                    if s.richiedibile { Pill(text: "Prenotabile", kind: .grade) }
                                }
                            }
                        }

                    }
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .navigationTitle("Seminari")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Cerca seminari")
            .searchPresentationToolbarBehavior(.avoidHidingContent)
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}
struct SeminarioDetailView: View {
    let seminario: Seminario
    @State private var showBookingAlert = false
    @Environment(\.colorScheme) private var colorScheme

    private var details: SeminarDetails { parseSeminarDetails(html: seminario.descrizioneEstesa, esito: seminario.esito) }

    var body: some View {
        List {
            if let docente = details.docente, !docente.isEmpty {
                Section {
                    Text(docente)
                } header: {
                    Text("Docente")
                }
            }
            if !details.dateLines.isEmpty {
                Section {
                    ForEach(details.dateLines, id: \.self) { Text($0) }
                } header: {
                    Text("Date")
                }
            }
            if let aula = details.aula, !aula.isEmpty {
                Section {
                    Text(aula)
                } header: {
                    Text("Aula")
                }
            }
            if let all = details.allievi, !all.isEmpty {
                Section {
                    let groups = allieviGroups(from: all)
                    if groups.isEmpty {
                        Text(all)
                    } else {
                        ForEach(0..<groups.count, id: \.self) { i in
                            let g = groups[i]
                            HStack(spacing: 8) {
                                if let y = g.anno { Pill(text: italianOrdinalYear(y), kind: .year, tintOverride: yearTint(y)) }
                                if let c = g.corso { Pill(text: c, kind: .status) }
                                Spacer()
                            }
                        }
                    }
                } header: {
                    Text("Disponibile per:")
                }
            }
            
            if !details.groups.isEmpty {
                Section {
                    ForEach(details.groups.indices, id: \.self) { i in
                        let g = details.groups[i]
                        HStack {
                            Text("GRUPPO \(g.label):").bold()
                            Spacer()
                            Text(g.time.isEmpty ? "—" : g.time)
                        }
                    }
                } header: {
                    Text("Gruppi e orari")
                }
            }
            
            if let cfa = details.cfa, !cfa.isEmpty {
                Section {
                    Text(cfa)
                } header: {
                    Text("CFA acquisibili")
                }
            }
            if let ass = details.assenze, !ass.isEmpty {
                Section {
                    HStack { Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange); Text(ass) }
                } header: {
                    Text("Assenze consentite")
                }
            }
            if details.completed {
                Section {
                    HStack {
                        Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
                        Text("Seminario conseguito")
                    }
                }
            }
            Section {
                if seminario.richiedibile {
                    Button { showBookingAlert = true } label: { Label("Prenota ora", systemImage: "calendar.badge.plus") }
                } else { Text("Prenotazione non disponibile").foregroundStyle(.secondary) }
            } header: {
                Text("Prenotazione")
            }
        }
        .navigationTitle("Dettagli seminario")
        .navigationBarTitleDisplayMode(.large)
        .alert("Prenotazione", isPresented: $showBookingAlert) {
            Button("OK", role: .cancel) {}
        } message: { Text("Collegheremo qui l'endpoint di prenotazione appena disponibile.") }
    }
}

// MARK: - Push Inbox Model (local persistence)
extension Notification.Name {
    static let authTokenDidChange = Notification.Name("AuthTokenDidChange")
    static let shouldReloadAfterAuth = Notification.Name("LABAShouldReloadAfterAuth")
    static let labaDidReceiveRemoteNotification = Notification.Name("labaDidReceiveRemoteNotification")
    static let labaFCMTokenReady = Notification.Name("labaFCMTokenReady")
}

extension Notification.Name {
    static let openHiddenDebug = Notification.Name("labaOpenHiddenDebug")
}

struct InboxItem: Identifiable, Codable, Hashable {
    let id: String
    let title: String
    let body: String
    let date: Date
    var isRead: Bool
}

final class NotificationInboxStore: ObservableObject {
    @Published private(set) var items: [InboxItem] = []
    private let storageKey = "laba.inbox.items"

    init() {
        load()
        updateBadge()
    }

    func add(from userInfo: [AnyHashable: Any]) {
        var title: String = "Notifica"
        var body: String = ""

        // APNs classico: aps.alert può essere Dictionary o String
        if let aps = userInfo["aps"] as? [AnyHashable: Any] {
            if let alertDict = aps["alert"] as? [AnyHashable: Any] {
                if let t = alertDict["title"] as? String { title = t }
                if let b = alertDict["body"] as? String { body = b }
            } else if let alertStr = aps["alert"] as? String {
                body = alertStr
            }
        }

        // FCM console: può mettere anche "notification" top-level
        if let notif = userInfo["notification"] as? [AnyHashable: Any] {
            if let t = notif["title"] as? String { title = t }
            if let b = notif["body"] as? String { body = b }
        }

        // Fallback custom (alcune console mettono title/body top-level)
        if let t = userInfo["title"] as? String { title = t }
        if let b = userInfo["body"] as? String { body = b }

        let item = InboxItem(id: UUID().uuidString, title: title, body: body, date: Date(), isRead: false)
        DispatchQueue.main.async {
            self.items.insert(item, at: 0)
            self.save()
            self.updateBadge()
        }
    }

    func markRead(_ id: String, _ read: Bool) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        items[i].isRead = read
        save(); updateBadge()
    }

    func markAllRead() {
        items = items.map { var m = $0; m.isRead = true; return m }
        save(); updateBadge()
    }

    func delete(_ offsets: IndexSet) {
        items.remove(atOffsets: offsets)
        save(); updateBadge()
    }

    /// Remove an item by id (public remover)
    func remove(id: String) {
        if let idx = items.firstIndex(where: { $0.id == id }) {
            items.remove(at: idx)
            save(); updateBadge()
        }
    }

    var unreadCount: Int { items.filter { !$0.isRead }.count }

    private func save() {
        let enc = JSONEncoder(); enc.dateEncodingStrategy = .iso8601
        if let data = try? enc.encode(items) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return }
        let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
        if let arr = try? dec.decode([InboxItem].self, from: data) {
            self.items = arr
        }
    }

    private func updateBadge() {
        #if canImport(UIKit)
        UNUserNotificationCenter.current().setBadgeCount(unreadCount) { error in
            if let error = error {
                print("Errore nell'aggiornare il badge: \(error)")
            }
        }        #endif
    }
}

// MARK: - Profilo (minimal, keeps earlier behavior)


struct ProfilePill: View {
    let text: String
    let systemName: String
    var tint: Color? = nil
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: systemName).font(.caption2)
            Text(text).font(.caption)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 10)
        .background(
            Capsule().fill((tint?.opacity(0.12)) ?? Color(uiColor: scheme == .dark ? .tertiarySystemBackground : .secondarySystemBackground))
        )
        .overlay(
            Capsule().stroke((tint?.opacity(0.35)) ?? Color.primary.opacity(0.08), lineWidth: 1)
        )
    }
}

struct ProfiloView: View {
    @EnvironmentObject var vm: SessionVM
    @EnvironmentObject var inbox: NotificationInboxStore
    @State private var showPhotoPicker = false
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var profileImage: Image? = nil
    @State private var isRefreshing: Bool = false
    @State private var didJustRefresh: Bool = false
    @State private var showDebugDisclaimer: Bool = false
    @State private var navigateToDebug: Bool = false
    @State private var showLogoutConfirm: Bool = false
    @AppStorage("laba.usernameBase") private var usernameBase: String = ""
    @AppStorage("laba.notificationsEnabled") private var notificationsEnabled: Bool = false
    @AppStorage("laba.theme") private var themePreference: String = "system"
    @AppStorage("laba.accent") private var accentChoice: String = "system"
    @AppStorage("laba.avatarData") private var avatarData: Data = Data()
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase

    // Image derived from persisted avatar data (if any)
    private var avatarImage: Image? {
        guard !avatarData.isEmpty, let ui = UIImage(data: avatarData) else { return nil }
        return Image(uiImage: ui)
    }

    // Preferisci il livello del corso corrente e ripulisci la stringa matricola arrivata da Logos
    private func isBiennio(_ piano: String?) -> Bool {
        let ps = (piano ?? "")
            .folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
        return ps.contains("biennio")
            || ps.contains("ii livello")
            || ps.contains("2° livello")
            || ps.contains("secondo livello")
    }

    /// Esempio in input: "2628Fi (triennio)-3531 FI (biennio)"
    /// Output (se corso corrente = Biennio): "3531 FI"
    private func extractMatricolaForCurrentCourse(_ raw: String?, piano: String?) -> String? {
        guard let s0raw = raw, !s0raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let wantBiennio = isBiennio(piano)

        // 1) Spezza la stringa in parti su separatori comuni
        let seps = CharacterSet(charactersIn: "-—/,|;")
        let parts = s0raw
            .replacingOccurrences(of: "\n", with: " ")
            .components(separatedBy: seps)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        func norm(_ s: String) -> String {
            s.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        }

        // 2) Scegli il frammento che contiene "biennio"/"triennio" (in base al corso corrente)
        var chosen = parts.first { wantBiennio ? norm($0).contains("biennio")
                                              : (norm($0).contains("triennio")
                                                 || norm($0).contains("i livello")
                                                 || norm($0).contains("1° livello")) }
        // fallback: se non c'è etichetta, prendi l’ultimo per biennio o il primo per triennio
        if chosen == nil { chosen = wantBiennio ? parts.last : parts.first }
        guard var frag = chosen, !frag.isEmpty else { return s0raw.trimmingCharacters(in: .whitespacesAndNewlines) }

        // 3) Togli eventuali parentesi "(biennio)/(triennio)"
        frag = frag.replacingOccurrences(of: "\\([^)]*\\)", with: "", options: .regularExpression)
                   .trimmingCharacters(in: .whitespacesAndNewlines)

        // 4) Estrai numero + possibile suffisso sede (FI, MI, …)
        if let r = frag.range(of: #"(?:^|[^0-9])([0-9]{3,})\s*([A-Za-z]{0,3})"#, options: .regularExpression) {
            let match = String(frag[r])
            let digits = match.filter { $0.isNumber }
            let letters = match.filter { $0.isLetter }.uppercased()
            return letters.isEmpty ? digits : "\(digits) \(letters)"
        }

        // Fallback: tieni solo cifre + lettere
        let digits = frag.filter { $0.isNumber }
        let letters = frag.filter { $0.isLetter }.uppercased()
        if !digits.isEmpty { return letters.isEmpty ? digits : "\(digits) \(letters)" }
        return frag
    }

    private var matricolaDisplay: String {
        let raw = (vm.matricola ?? UserDefaults.standard.string(forKey: "laba.profile.matricola"))
        return extractMatricolaForCurrentCourse(raw, piano: vm.pianoStudi) ?? (raw ?? "—")
    }
    
    private func requestNotificationPermission() {
        // Verifica stato corrente, poi richiedi se necessario
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            switch settings.authorizationStatus {
            case .notDetermined:
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, _ in
                    DispatchQueue.main.async {
                        if granted {
                            #if canImport(UIKit)
                            UIApplication.shared.registerForRemoteNotifications()
                            #endif
                            notificationsEnabled = true
                        } else {
                            notificationsEnabled = false
                        }
                    }
                }
            case .denied:
                // Permesso negato a livello di sistema → ripristina toggle a OFF
                DispatchQueue.main.async { notificationsEnabled = false }
            case .authorized, .provisional, .ephemeral:
                // Già autorizzato → assicurati che APNs sia registrato
                DispatchQueue.main.async {
                    #if canImport(UIKit)
                    UIApplication.shared.registerForRemoteNotifications()
                    #endif
                    notificationsEnabled = true
                }
            @unknown default:
                break
            }
        }
    }

    private func profileCourseName(from s: String?) -> String? {
        guard let s = s, !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        if let r = s.range(of: "A.A.", options: [.caseInsensitive, .diacriticInsensitive]) {
            let name = s[..<r.lowerBound]
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .trimmingCharacters(in: CharacterSet(charactersIn: "–-•·:"))
            return name.isEmpty ? s : String(name)
        }
        return s
    }

    // Preferisce la matricola del corso corrente (Biennio/Triennio)
    private var isBiennioCurrent: Bool {
        let ps = (vm.pianoStudi ?? "").folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return ps.contains("biennio") || ps.contains("ii livello") || ps.contains("2° livello") || ps.contains("secondo livello")
    }

    private func preferredMatricolaString(_ raw: String?) -> String? {
        guard let s0 = raw, !s0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let s = s0.folding(options: .diacriticInsensitive, locale: .current).lowercased()

        // estrai tutte le sequenze numeriche (>=4 cifre)
        var nums: [(val: String, range: Range<String.Index>)] = []
        var i = s.startIndex
        while i < s.endIndex {
            if s[i].isNumber {
                var j = i
                while j < s.endIndex, s[j].isNumber { j = s.index(after: j) }
                let r = i..<j
                let token = String(s[r])
                if token.count >= 4 { nums.append((token, r)) }
                i = j
            } else {
                i = s.index(after: i)
            }
        }
        guard !nums.isEmpty else { return s0.trimmingCharacters(in: .whitespacesAndNewlines) }
        if nums.count == 1 { return nums[0].val }

        func nearest(to markers: [String]) -> String? {
            let anchors = markers.compactMap { s.range(of: $0)?.lowerBound }
            guard let anchor = anchors.min(by: { s.distance(from: s.startIndex, to: $0) < s.distance(from: s.startIndex, to: $1) }) else { return nil }
            return nums.min(by: { abs(s.distance(from: anchor, to: $0.range.lowerBound)) < abs(s.distance(from: anchor, to: $1.range.lowerBound)) })?.val
        }

        if isBiennioCurrent {
            if let v = nearest(to: ["biennio", "ii livello", "2° livello", "secondo livello"]) { return v }
            return nums.last?.val // fallback: la seconda (di solito il biennio è la più recente)
        } else {
            if let v = nearest(to: ["triennio", "i livello", "1° livello", "primo livello"]) { return v }
            return nums.first?.val
        }
    }
    
    // Synchronize the notifications toggle with the real system status
    private func syncNotificationToggleFromSystem() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            let isOn: Bool
            switch settings.authorizationStatus {
            case .authorized, .provisional, .ephemeral:
                isOn = true
            case .denied, .notDetermined:
                isOn = false
            @unknown default:
                isOn = false
            }
            DispatchQueue.main.async {
                self.notificationsEnabled = isOn
            }
        }
    }

    /// Aggiorna le sottoscrizioni FCM in base ai dati correnti della VM (solo corso/anno)
    private func updateFCMTopicsFromVM() {
        let isGrad = (vm.status ?? "").localizedCaseInsensitiveContains("laureat")
        TopicAssegnato.update(
            pianoStudi: vm.pianoStudi,
            annoCorrente: vm.currentYear,
            isGraduated: isGrad
        )
    }

    @MainActor
    private func reloadProfileOverview() async {
        // Riallinea sessione e ricarica i dati di profilo/overview
        await vm.restoreSessionStrong()
        if vm.tokenIsUsableNow {
            // opzionale: manteniamo anche gli esami aggiornati come in altri punti
            await vm.loadEsami()
        }
        // Persisti snapshot per fallback UI
        if let chosen = preferredMatricolaString(vm.matricola), !chosen.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            UserDefaults.standard.set(chosen, forKey: "laba.profile.matricola")
        }
        if let p = vm.pagamenti, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            UserDefaults.standard.set(p, forKey: "laba.profile.pagamenti")
        }
        updateFCMTopicsFromVM()
    }

    @MainActor
    private func refreshAll() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        // Re-run the full bootstrap (come allo startup) e poi ricarica notifiche esplicite
        await vm.restoreSessionStrong()
        if vm.tokenIsUsableNow {
            await vm.loadNotifications()
        }

        // Feedback utente
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        didJustRefresh = true
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 1_200_000_000)
            didJustRefresh = false
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 12) {
                            Button { showPhotoPicker = true } label: {
                                if let img = (profileImage ?? avatarImage) {
                                    img.resizable().scaledToFill().frame(width: 56, height: 56).clipShape(Circle())
                                } else {
                                    Image(systemName: "person.crop.circle.fill").font(.system(size: 56)).foregroundStyle(colorScheme == .dark ? .white : Color.labaAccent)
                                        .frame(width: 56, height: 56)
                                }
                            }
                            .buttonStyle(.plain)
                            VStack(alignment: .leading) {
                                Text(
                                    {
                                        let combined = [vm.nome, vm.cognome].compactMap { $0 }.joined(separator: " ")
                                        if combined.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                            return fullName(from: usernameBase.isEmpty ? (vm.displayName ?? "") : usernameBase)
                                        } else {
                                            return combined
                                        }
                                    }()
                                )
                                .font(.title3).bold()
                            }
                        }

                        HStack(spacing: 8) {
                            if let p = (vm.pagamenti ?? UserDefaults.standard.string(forKey: "laba.profile.pagamenti")) {
                                let ok = p.uppercased() == "OK"
                                ProfilePill(
                                    text: ok ? "Pagamenti in regola" : "Pagamenti non in regola",
                                    systemName: ok ? "checkmark.seal.fill" : "exclamationmark.triangle.fill",
                                    tint: ok ? .green : .red
                                )
                            }
                            ProfilePill(
                                    text: "Matricola: \(matricolaDisplay)",
                                    systemName: "number"
                                )
                            Spacer()
                        }
                        .padding(.top, 4)
                    }
                }

                Section {
                    NavigationLink { MaterialiView() } label: {
                        Label("Programmi didattici", systemImage: "list.bullet.rectangle.fill")
                    }
                    NavigationLink { DispenseView() } label: {
                        Label("Dispense", systemImage: "books.vertical.fill")
                    }
                    NavigationLink { ThesisDocsView() } label: {
                        Label("Tesi di laurea", systemImage: "graduationcap.fill")
                    }
                } header: {
                    Text("Risorse")
                }

                Section {
                    NavigationLink { RegolamentiView() } label: {
                        Label("Regolamenti", systemImage: "scroll.fill")
                    }
                    NavigationLink { FAQView().environmentObject(vm) } label: {
                        Label("Consulta FAQ", systemImage: "questionmark.circle.fill")
                    }
                } header: {
                    Text("Assistenza")
                }

                Section {
                    Toggle(isOn: $notificationsEnabled) {
                        Label("Notifiche", systemImage: "bell.fill")
                    }
                    .tint(Color.labaAccent)

                    NavigationLink { AppearanceSettingsView() } label: {
                        Label("Aspetto", systemImage: "paintbrush.fill")
                    }
                } header: {
                    Text("Preferenze")
                }

                Section {
                    Link(destination: URL(string: "mailto:info@laba.biz")!) {
                        HStack(spacing: 8) {
                            Image(systemName: "envelope.fill")
                                .foregroundColor(Color.labaAccent) // icona = accent
                            Text("Scrivi alla Segreteria")
                                .foregroundColor(colorScheme == .dark ? .white : .primary) // testo: bianco in dark, default in light
                        }
                    }
                    Link(destination: URL(string: "https://wa.me/393516905915")!) {
                        HStack(spacing: 8) {
                            Image(systemName: "ellipsis.message.fill")
                                .foregroundColor(Color(red: 37/255, green: 185/255, blue: 102/255)) // WhatsApp green
                            Text("Scrivici su WhatsApp")
                                .foregroundColor(Color(red: 37/255, green: 185/255, blue: 102/255)) // WhatsApp green
                        }
                    }
                } header: {
                    Text("Contatti")
                }
                
                
                
                Section {
                    Link(destination: URL(string: "https://www.laba.biz")!) {
                        HStack(spacing: 8) {
                            Image(systemName: "globe")
                                .foregroundColor(Color.labaAccent)
                            Text("Sito web LABA")
                                .foregroundColor(colorScheme == .dark ? .white : .primary)
                        }
                    }
                    Link(destination: URL(string: "https://iris.rete.toscana.it/public/")!) {
                        HStack(spacing: 8) {
                            Image(systemName: "creditcard.fill")
                                .foregroundColor(Color.red)
                            Text("Pagamento DSU Toscana")
                                .foregroundColor(.red)
                        }
                    }
                    Link(destination: URL(string: "https://www.laba.biz/privacy-policy")!) {
                        HStack(spacing: 8) {
                            Image(systemName: "hand.raised.fill")
                                .foregroundColor(Color.labaAccent)
                            Text("Privacy Policy")
                                .foregroundColor(colorScheme == .dark ? .white : .primary)
                        }
                    }
                } header: {
                    Text("Link utili")
                }
                
                
                Section {
                    // Ricarica dati — mostra spinner durante refresh, disabilita durante refresh
                    Button {
                        Task { await refreshAll() }
                    } label: {
                        HStack(spacing: 8) {
                            if isRefreshing {
                                ProgressView().progressViewStyle(.circular)
                            } else {
                                Image(systemName: "arrow.clockwise.circle.fill")
                            }
                            Text(isRefreshing ? "Aggiorno…" : "Ricarica dati")
                        }
                        .foregroundColor(Color.labaAccent)
                    }
                    .disabled(isRefreshing)

                    Button {
                        showDebugDisclaimer = true
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "hammer.fill")
                                .foregroundColor(Color.indigo)
                            Text("Debug")
                                .foregroundColor(Color.indigo)
                        }
                    }
                    .sheet(isPresented: $showDebugDisclaimer) {
                        VStack(spacing: 16) {
                            Text("Attenzione")
                                .font(.headline)
                            Text("Qua c'è roba seria: se tocchi, rischi di rompere l'applicazione.\nLa sezione Debug è visibile perché sei su una build beta, ma poi sparirà.\nEntra e modifica solo se sai quello che fai.")
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                            HStack(spacing: 16) {
                                Button("Indietro") {
                                    showDebugDisclaimer = false
                                }
                                .buttonStyle(.bordered)
                                .tint(.indigo)
                                .padding(.vertical, 6)
                                .padding(.horizontal, 12)

                                Button("Ho capito") {
                                    showDebugDisclaimer = false
                                    navigateToDebug = true
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(.indigo)
                                .padding(.vertical, 6)
                                .padding(.horizontal, 12)
                            }
                        }
                        .padding()
                        .presentationDetents([.height(260)])
                        .presentationDragIndicator(.visible)
                    }
                    // Esci — rosso: icona + testo
                    Button(role: .destructive) {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        TopicAssegnato.clearAll()
                        vm.logout()
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "rectangle.portrait.and.arrow.right.fill")
                            Text("Esci")
                        }
                        .foregroundColor(.red)
                    }
                    .alert("Vuoi davvero uscire?", isPresented: $showLogoutConfirm) {
                        Button("Annulla", role: .cancel) {}
                        Button("Esci", role: .destructive) { vm.logout() }
                    }
                }header: {
                    Text("Azioni")
                }

            }
            .navigationTitle("Profilo")
            .navigationBarTitleDisplayMode(.large)
            .photosPicker(isPresented: $showPhotoPicker, selection: $selectedItem, matching: .images)
            .onChange(of: selectedItem) { _, newValue in
                guard let item = newValue else { return }
                Task {
                    // Try to get raw Data, then normalize to JPEG to reduce size and ensure compatibility
                    if let raw = try? await item.loadTransferable(type: Data.self),
                       let ui = UIImage(data: raw) {
                        if let jpeg = ui.jpegData(compressionQuality: 0.9) {
                            avatarData = jpeg
                        } else if let png = ui.pngData() {
                            avatarData = png
                        } else {
                            avatarData = raw
                        }
                        profileImage = Image(uiImage: ui)
                    }
                }
            }
            .onChange(of: notificationsEnabled) { _, newValue in
                if newValue {
                    requestNotificationPermission()
                } else {
                    #if canImport(UIKit)
                    UIApplication.shared.unregisterForRemoteNotifications()
                    #endif
                }
            }
            .onAppear {
                syncNotificationToggleFromSystem()
                if let ui = (!avatarData.isEmpty ? UIImage(data: avatarData) : nil) {
                    profileImage = Image(uiImage: ui)
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                // Mantiene il toggle notifiche allineato allo stato iOS
                syncNotificationToggleFromSystem()
                // Ricarica sempre il profilo quando l'app torna attiva (copre i casi di VM scaricata dal sistema)
                Task { await reloadProfileOverview() }
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    Task { await reloadProfileOverview() }
                }
            }
            .task {
                // Assicura che i dati profilo (pagamenti, matricola, piano studi) vengano ricaricati
                await vm.restoreSessionStrong()           // ricarica il profilo/overview utente
                if vm.tokenIsUsableNow {
                    await vm.loadEsami()                // opzionale: mantiene il comportamento di aggiornare gli esami
                }
                if let m = vm.matricola, !m.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    UserDefaults.standard.set(m, forKey: "laba.profile.matricola")
                    updateFCMTopicsFromVM()
                }
                if let p = vm.pagamenti, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    UserDefaults.standard.set(p, forKey: "laba.profile.pagamenti")
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: .shouldReloadAfterAuth)) { _ in
                Task {
                    // Dopo un refresh token/reauth, ricarica anche i dati profilo
                    await vm.restoreSessionStrong()
                    if vm.tokenIsUsableNow {
                        await vm.loadEsami()
                    }
                    if let m = vm.matricola, !m.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        UserDefaults.standard.set(m, forKey: "laba.profile.matricola")
                        updateFCMTopicsFromVM()
                    }
                    if let p = vm.pagamenti, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        UserDefaults.standard.set(p, forKey: "laba.profile.pagamenti")
                    }
                }
            }
            .overlay(alignment: .center) {
                if isRefreshing {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16).fill(.ultraThinMaterial)
                        VStack(spacing: 10) {
                            ProgressView("Aggiornamento in corso…")
                            Text("Sincronizzo i dati dal server").font(.footnote).foregroundStyle(.secondary)
                        }
                        .padding(16)
                    }
                    .frame(width: 260, height: 120)
                } else if didJustRefresh {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16).fill(.ultraThinMaterial)
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Dati aggiornati")
                        }
                        .font(.headline)
                        .padding(12)
                    }
                    .frame(width: 200, height: 60)
                    .transition(.opacity)
                }
            }
            .navigationDestination(isPresented: $navigateToDebug) {
                DebugView().environmentObject(vm)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        NotificheInboxView().environmentObject(inbox)
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "bell.fill")
                                .font(.headline)
                                .foregroundStyle(inbox.unreadCount > 0 ? Color.red : Color.primary)
                            if inbox.unreadCount > 0 {
                                Text("\(min(inbox.unreadCount, 99))")
                                    .font(.subheadline.weight(.bold))
                                    .foregroundColor(.red)
                                    .monospacedDigit()
                            }
                        }
                        .padding(.vertical, 2)
                        .contentShape(Rectangle())
                        .accessibilityLabel("Notifiche")
                        .accessibilityValue(inbox.unreadCount > 0 ? "\(inbox.unreadCount) non lette" : "Nessuna notifica non letta")
                    }
                }
            }
        }
    }
}

/// Converte una stringa voto in intero su scala /30 ("lode" -> 30, formati tipo "28/30" accettati, "idoneo" escluso)
func parseVoteForThesis(_ voto: String?) -> Int? {
    guard var s = voto?.lowercased() else { return nil }
    // Escludi idoneità
    if s.contains("idoneo") || s.contains("idonea") || s.contains("idoneit") { return nil }
    // Lode = 30
    if s.contains("lode") { return 30 }
    // Cattura cifre sparse
    let digits = s.compactMap { $0.isNumber ? $0 : nil }
    if let n = Int(String(digits)), (18...30).contains(n) { return n }
    // Supporta formati "28/30", spazi ecc.
    s = s.replacingOccurrences(of: " ", with: "")
    if let first = s.split(separator: "/").first, let n = Int(first), (18...30).contains(n) { return n }
    return nil
}

// MARK: - Tesi di laurea documenti

struct ThesisDocsView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var isLoading = false
    @State private var errorMessage: String? = nil
    @State private var items: [ThesisItem] = []
    @State private var query: String = ""

    // MARK: - Model
    struct ThesisItem: Identifiable, Hashable {
        let id: String                // allegatoOid se disponibile, altrimenti hash dell’URL
        let title: String             // maiuscole ripulite in UI
        let type: String?
        let course: String?
        let directURL: URL?
    }

    // MARK: - UX: percorso e requisiti
    private var isBiennio: Bool {
        let ps = (vm.pianoStudi ?? "").folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return ps.contains("biennio") || ps.contains("ii livello") || ps.contains("2° livello") || ps.contains("secondo livello")
    }
    private var levelLabel: String { isBiennio ? "Biennio (II livello)" : "Triennio (I livello)" }
    private var minPages: Int { isBiennio ? 90 : 80 }

    // MARK: - Helpers
    private func deShout(_ s: String) -> String {
        // Se è tutto maiuscolo, converte in Capitalized; altrimenti lascia intatto
        let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let letters = trimmed.unicodeScalars.filter { CharacterSet.letters.contains($0) }
        let lettersStr = String(String.UnicodeScalarView(letters))
        if !lettersStr.isEmpty && lettersStr == lettersStr.uppercased() {
            return trimmed.localizedCapitalized
        }
        return trimmed
    }

    

    private func match(_ it: ThesisItem, any ks: [String]) -> Bool {
        let hay = [it.title, it.type ?? "", it.course ?? ""].joined(separator: " ")
            .folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return ks.contains { hay.contains($0) }
    }
    private func shortLabel(for it: ThesisItem) -> String {
        let t = it.title.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if t.contains("regol") { return "Regolamento" }
        if t.contains("domanda") || t.contains("richiesta") { return "Domanda tesi" }
        if t.contains("frontespizio") || t.contains("front") { return "Frontespizio" }
        if t.contains("certificat") { return "Certificati" }
        if t.contains("pagament") || t.contains("bollett") || t.contains("versament") { return "Pagamenti" }
        return deShout(it.title)
    }
    private func iconFor(_ it: ThesisItem) -> String {
        let t = it.title.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if t.contains("regol") { return "book.closed.fill" }
        if t.contains("domanda") || t.contains("richiesta") { return "doc.badge.plus" }
        if t.contains("frontespizio") || t.contains("front") { return "doc.text" }
        if t.contains("certificat") { return "checkmark.seal" }
        if t.contains("pagament") || t.contains("bollett") || t.contains("versament") { return "creditcard" }
        return "doc.plaintext"
    }

    // MARK: - KPI & Quick chips helpers (safe)
    private func examsCompletedFlag() -> Bool? {
        // Se non ho caricato esami, non posso sapere
        let items = vm.esami
        if items.isEmpty { return nil }

        // Considera "esami" quelli di corso, escludendo attività integrative e tesi
        let core = items.filter { e in
            let title = e.corso.folding(options: .diacriticInsensitive, locale: .current).lowercased()
            return !title.contains("attivit") && !title.contains("tesi")
        }
        if core.isEmpty { return nil }

        // Completato = voto presente (numerico o lode) oppure data sostenimento
        let allDone = core.allSatisfy { e in
            let voto = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return !voto.isEmpty || (e.sostenutoIl != nil)
        }
        return allDone
    }

    private func presentationGradeString() -> String {
        // 👇 rimpiazza tutto il corpo con quello qui sotto
        // Media ARITMETICA dei soli esami di corso (no tesi, no attività integrative), poi conversione su 110
        let grades: [Int] = vm.esami.compactMap { e in
            let title = e.corso.folding(options: .diacriticInsensitive, locale: .current).lowercased()
            if title.contains("attivit") { return nil }
            if title.contains("tesi") { return nil }
            return parseVoteForThesis(e.voto)
        }
        guard !grades.isEmpty else { return "—" }
        let avg = Double(grades.reduce(0, +)) / Double(grades.count)
        let present = Int((avg / 30.0 * 110.0).rounded())
        return String(present)
    }
    
    // Helper to open Voto d’Ingresso section
    private func openEntranceGradeSection() {
        NotificationCenter.default.post(name: .init("LABA.navigate.votoIngresso"), object: nil)
    }
    
    private func openExamsSection() {
        NotificationCenter.default.post(name: .init("LABA.navigate.exams"), object: nil)
    }

    @ViewBuilder private func kpiExamsCompleted() -> some View {
        let flag = examsCompletedFlag()
        VStack(spacing: 4) {
            Image(systemName: flag == true ? "checkmark.circle.fill" : (flag == false ? "xmark.circle.fill" : "questionmark.circle"))
                .font(.title3)
                .foregroundStyle(flag == true ? Color.green : (flag == false ? Color.red : .secondary))
            Text(flag == true ? "Terminati" : (flag == false ? "Da terminare" : "Da verificare"))
                .font(.title3.bold())
            Text("Esami")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill((flag == true ? Color.green.opacity(0.12) : (flag == false ? Color.red.opacity(0.12) : Color.cardBG)))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke((flag == true ? Color.green.opacity(0.35) : (flag == false ? Color.red.opacity(0.35) : Color.primary.opacity(0.06))), lineWidth: 1)
        )
    }

    @ViewBuilder private func kpiPresentationGrade() -> some View {
        let value = presentationGradeString()
        VStack(spacing: 4) {
            Image(systemName: "graduationcap.fill").font(.title3)
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()
            Text("Voto di presentazione")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 10).fill(Color.cardBG)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10).stroke(Color.primary.opacity(0.06), lineWidth: 1)
        )
    }

    @ViewBuilder private func quickChip(_ item: ThesisItem?, _ title: String, _ systemImage: String) -> some View {
        if let it = item {
            NavigationLink {
                MaterialiDocumentViewer(allegatoOid: it.id, title: deShout(it.title), directURL: it.directURL)
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: systemImage).font(.caption2)
                    Text(title).font(.caption.weight(.semibold))
                }
                .padding(.vertical, 6)
                .padding(.horizontal, 10)
                .background(Capsule().fill(Color.cardBG))
                .overlay(Capsule().stroke(Color.primary.opacity(0.06), lineWidth: 1))
            }
        }
    }

    // Mostra/Nasconde documenti in base al livello (solo per frontespizio)
    private func showForCurrentLevel(_ it: ThesisItem) -> Bool {
        let hay = [it.title, it.type ?? "", it.course ?? ""]
            .joined(separator: " ")
            .folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
        // Applica filtro solo ai frontespizi
        if hay.contains("frontespizio") || hay.contains("front") {
            if isBiennio {
                // se Biennio, escludi frontespizi Triennio / I livello
                if hay.contains("triennio") || hay.contains("i livello") || hay.contains("primo") || hay.contains("1 livello") { return false }
            } else {
                // se Triennio, escludi frontespizi Biennio / II livello
                if hay.contains("biennio") || hay.contains("ii livello") || hay.contains("secondo") || hay.contains("2 livello") { return false }
            }
        }
        return true
    }

    // MARK: - Quick actions estratte automaticamente
    private var quickRegolamento: ThesisItem? { items.first { match($0, any: ["regolamento", "regulation"]) } }
    private var quickDomanda: ThesisItem? { items.first { match($0, any: ["domanda", "richiesta tesi"]) } }
    private var quickFrontespizio: ThesisItem? {
        let cand = items.filter { match($0, any: ["frontespizio", "front"]) }
        if cand.isEmpty { return nil }
        return isBiennio ? (cand.first { match($0, any: ["biennio", "ii", "secondo"]) } ?? cand.first)
                         : (cand.first { match($0, any: ["triennio", "i", "primo"]) } ?? cand.first)
    }
    private var quickCertificati: ThesisItem? { items.first { match($0, any: ["certificat"]) } }
    private var quickPagamenti: ThesisItem? { items.first { match($0, any: ["pagament", "bollett", "versament"]) } }
    private var quickItems: [ThesisItem] { [quickRegolamento, quickDomanda, quickFrontespizio, quickCertificati, quickPagamenti].compactMap { $0 } }

    // MARK: - Categorie documento (presentazione più chiara)
    private enum DocCategory: String, CaseIterable, Hashable { case regolamento = "Regolamento tesi", domanda = "Domande e modulistica", frontespizio = "Modelli di frontespizio", certificati = "Certificati e attestati", pagamenti = "Pagamenti e bollettini", altro = "Altri documenti" }
    private func category(for it: ThesisItem) -> DocCategory {
        let t = it.title.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if t.contains("regol") { return .regolamento }
        if t.contains("frontespizio") || t.contains("front") { return .frontespizio }
        if t.contains("domanda") || t.contains("richiesta") { return .domanda }
        if t.contains("certificat") { return .certificati }
        if t.contains("pagament") || t.contains("bollett") || t.contains("versament") { return .pagamenti }
        return .altro
    }
    private var groupedByCategory: [(DocCategory, [ThesisItem])] {
        // Ricerca di base
        let baseUnfiltered: [ThesisItem] = {
            let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !q.isEmpty else { return items }
            let ql = q.folding(options: .diacriticInsensitive, locale: .current).lowercased()
            return items.filter { it in
                [it.title, it.type ?? "", it.course ?? ""]
                    .joined(separator: " ")
                    .folding(options: .diacriticInsensitive, locale: .current)
                    .lowercased()
                    .contains(ql)
            }
        }()
        // Filtro per livello (frontespizi)
        let base = baseUnfiltered.filter { showForCurrentLevel($0) }
        // Raggruppamento per categoria
        let dict = Dictionary(grouping: base, by: { category(for: $0) })
        let order: [DocCategory] = [.regolamento, .domanda, .frontespizio, .pagamenti, .certificati, .altro]
        return order.compactMap { cat in
            guard let arr = dict[cat], !arr.isEmpty else { return nil }
            return (cat, arr.sorted { deShout($0.title).localizedStandardCompare(deShout($1.title)) == .orderedAscending })
        }
    }

    // Lista piatta per "Moduli, pagamenti e modelli" (già filtrata per query e livello)
    private var flatDocs: [ThesisItem] {
        groupedByCategory.flatMap { $0.1 }
    }

    // MARK: - Networking
    private func load() async {
        await MainActor.run { isLoading = true; errorMessage = nil }
        guard let url = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/ThesisInfo") else {
            await MainActor.run { errorMessage = "URL non valido"; isLoading = false }
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue("Bearer \(vm.accessToken)", forHTTPHeaderField: "Authorization")
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) { throw NSError(domain: "ThesisDocsView", code: http.statusCode) }
            let any = try JSONSerialization.jsonObject(with: data, options: [])
            let parsed = extractThesisItems(from: any)
            await MainActor.run { items = parsed; isLoading = false }
        } catch {
            await MainActor.run { errorMessage = error.localizedDescription; isLoading = false }
        }
    }

    // MARK: - Body
    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Caricamento…").frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let err = errorMessage {
                    ContentUnavailableView("Impossibile caricare", systemImage: "graduationcap", description: Text(err))
                } else if items.isEmpty {
                    ContentUnavailableView("Nessun documento tesi", systemImage: "graduationcap", description: Text("Quando disponibili, appariranno qui."))
                } else {
                    List {
                        
                        // INTRO rivista (snella)
                        Section {
                            // Titolo + descrizione breve
                            VStack(spacing: 8) {
                                Text("Tesi di laurea")
                                    .font(.headline)
                                Text("Qui trovi regolamenti, modelli e scadenze per preparare la prova finale. Usa questa sezione come guida rapida insieme alle indicazioni del relatore e della segreteria.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 6)

                        // KPI principali: stato esami + voto di presentazione
                        HStack(spacing: 12) {
                            kpiExamsCompleted()
                                .frame(maxWidth: .infinity)
                            kpiPresentationGrade()
                                .frame(maxWidth: .infinity)
                        }
                        .padding(.vertical, 6)


                            // Nota + pulsante per Voto d’Ingresso
                            VStack(spacing: 8) {
                                VStack(spacing: 6) {
                                    Text("Voto d'ingresso: La tua stima in tempo reale")
                                        .font(.subheadline.weight(.semibold))
                                        .multilineTextAlignment(.center)
                                    Text("Il Voto di presentazione è un calcolo automatico basato sulla media aritmetica dei tuoi esami verbalizzati. Il voto finale è convertito su una scala di 110.")
                                        .font(.footnote)
                                        .foregroundStyle(.secondary)
                                        .multilineTextAlignment(.center)
                                    Text("Come lo verifichi e lo ricalcoli?")
                                        .font(.footnote.weight(.semibold))
                                        .multilineTextAlignment(.center)
                                    Text("• Dalla Home: tocca la sezione \"Voto d'ingresso\".\n• Dalla sezione Esami: accedi alla lista dei tuoi voti.")
                                        .font(.footnote)
                                        .foregroundStyle(.secondary)
                                        .multilineTextAlignment(.leading)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 2)

                        }
                        // CHECKLIST
                        Section("Checklist rapida") {
                            VStack(alignment: .leading, spacing: 8) {
                                Label("Scegli argomento e relatore", systemImage: "person.2.fill")
                                Label("Concorda revisioni periodiche con il relatore", systemImage: "calendar.badge.clock")
                                Label("Alla scadenza delle consegne invia al relatore una versione PDF (almeno l’80% dell’elaborato)", systemImage: "paperplane.fill")
                                Label("Imposta il frontespizio seguendo le indicazioni sul file che trovi qua", systemImage: "doc.text.fill")
                                Label("Almeno \(minPages) pagine; 2/3 ricerca e 1/3 progetto", systemImage: "text.justify")
                                Label("Stampa 4 copie fisiche e consegnale in segreteria entro la scadenza", systemImage: "printer")
                                Label("Il giorno della discussione porta una USB con materiali e PDF della tesi", systemImage: "externaldrive.fill")
                                Label("Pagamenti: dopo la tesi, solo per il ritiro pergamena (se previsto)", systemImage: "eurosign.circle")
                            }
                            .font(.footnote)
                        }

                        // DOCUMENTI: Moduli, pagamenti e modelli (sezione unica)
                        Section("Moduli, pagamenti e modelli") {

                            ForEach(flatDocs, id: \.id) { it in
                                NavigationLink {
                                    MaterialiDocumentViewer(allegatoOid: it.id, title: deShout(it.title), directURL: it.directURL)
                                } label: {
                                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                                        Image(systemName: iconFor(it)).foregroundStyle(.secondary)
                                        Text(deShout(it.title)).font(.body.weight(.semibold)).lineLimit(2)
                                        Spacer(minLength: 6)
                                        if let t = it.type, !t.isEmpty { Pill(text: t, kind: .status) }
                                    }
                                    .padding(.vertical, 2)
                                }
                            }
                        }
                        
                        // COSTI
                        Section("Pergamena ufficiale") {
                            NavigationLink {
                                PergamenaRitiroView(pagamenti: quickPagamenti)
                            } label: {
                                Label("Come richiederla e ritirarla", systemImage: "newspaper.fill")
                            }
                        }

                        // CONTATTI
                        Section("Hai dubbi?") {
                            NavigationLink {
                                // Apri un placeholder regolamento/FAQ se presente, altrimenti nulla
                                if let it = quickRegolamento {
                                    MaterialiDocumentViewer(allegatoOid: it.id, title: deShout(it.title), directURL: it.directURL)
                                } else {
                                    EmptyView()
                                }
                            } label: {
                                Label("Apri regolamento tesi", systemImage: "book.closed.fill")
                            }
                            Link(destination: URL(string: "mailto:info@laba.biz")!) {
                                Label("Scrivi alla Segreteria", systemImage: "envelope.fill")
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Tesi di laurea")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Cerca tesi e moduli")
            .task {
                if vm.esami.isEmpty {
                    await vm.restoreSessionStrong()
                    if vm.tokenIsUsableNow {
                        await vm.loadEsami()
                    }
                }
                await load()
            }
            .refreshable { await load() }
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
    
    // Sessione corrente (in base al mese): giu/ott/feb
    private func currentSessionLabel(now: Date = Date()) -> String {
        let m = Calendar.current.component(.month, from: now)
        switch m {
        case 3...6:  return "sessione giugno"
        case 7...10: return "sessione ottobre"
        default:     return "sessione febbraio"
        }
    }

    // MARK: - Parser tollerante a schemi diversi
    private func extractThesisItems(from any: Any) -> [ThesisItem] {
        var out: [ThesisItem] = []
        var seen = Set<String>()
        func parse(_ obj: Any) {
            if let arr = obj as? [Any] { for el in arr { parse(el) }; return }
            guard let dict = obj as? [String: Any] else { return }

            let title = (dict["descrizione"] ?? dict["description"] ?? dict["titolo"] ?? dict["title"] ?? dict["nome"] ?? dict["name"]) as? String
            let type  = (dict["tipo"] ?? dict["type"]) as? String
            let corso = (dict["corso"] ?? dict["course"] ?? dict["materia"]) as? String

            var foundId: String? = (dict["allegatoOid"] ?? dict["id"]) as? String
            var direct: URL? = nil
            if let urlStr = (dict["url"] ?? dict["href"]) as? String, let u = URL(string: urlStr) {
                direct = u
                if foundId == nil, let comps = URLComponents(url: u, resolvingAgainstBaseURL: false),
                   let qid = comps.queryItems?.first(where: { $0.name.lowercased() == "id" })?.value, !qid.isEmpty {
                    foundId = qid
                }
            }

            if let t = title, !t.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, (foundId != nil || direct != nil) {
                let ident = foundId ?? (direct?.absoluteString ?? UUID().uuidString)
                if !seen.contains(ident) {
                    out.append(ThesisItem(id: ident, title: t, type: type, course: corso, directURL: direct))
                    seen.insert(ident)
                }
            }

            // Ricorsione su eventuali figli
            for v in dict.values { parse(v) }
        }
        parse(any)
        return out
    }
}

// Simulatore media: UX rivista (sheet ricercabile + pillole voto)
struct MediaSimulatorView: View {
    @EnvironmentObject var vm: SessionVM
    @Environment(\.dismiss) private var dismiss

    // Stato
    @State private var simulated: [SimItem] = []
    @State private var showGraduatedGate = false

    // Sheet “Aggiungi esami…”
    @State private var showAddSheet = false
    @State private var courseQuery = ""

    @ViewBuilder
    private func statusPill(title: String, value: String, tint: Color?) -> some View {
        let bg = tint == nil ? Color.cardBG : tint!.opacity(0.16)
        let stroke = (tint?.opacity(0.25)) ?? Color.primary.opacity(0.06)

        HStack(spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundStyle(tint ?? .secondary)
            Text(value)
                .font(.caption.weight(.semibold))
                .foregroundStyle(tint ?? .primary)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 10)
        .background(Capsule().fill(bg))
        .overlay(Capsule().stroke(stroke, lineWidth: 1))
    }
    
    
    private struct SimItem: Identifiable, Hashable {
        let id = UUID()
        let title: String
        var grade: Int
    }

    // Esami core (niente tesi/attività integrative)
    private var coreExams: [Esame] {
        vm.esami.filter { e in
            let t = e.corso.folding(options: .diacriticInsensitive, locale: .current).lowercased()
            return !t.contains("attivit") && !t.contains("tesi")
        }
    }

    // Voti numerici già registrati (18–30, lode→30, no idoneità)
    private var numericGrades: [Int] {
        // SE il tuo helper si chiama diversamente, cambia qui:
        coreExams.compactMap { parseVoteForThesis($0.voto) }
    }

    private var sustainedCount: Int {
        coreExams.filter { e in
            let voto = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return !voto.isEmpty || (e.sostenutoIl != nil)
        }.count
    }
    private var totalCount: Int { coreExams.count }
    private var notSustainedCount: Int { max(0, totalCount - sustainedCount) }

    // Materie non sostenute
    private var unsustainedCourses: [String] {
        coreExams.filter { e in
            let voto = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return voto.isEmpty && (e.sostenutoIl == nil)
        }
        .map { prettifyTitle($0.corso) }
    }

    private var availableCourses: [String] {
        let chosen = Set(simulated.map { $0.title })
        return unsustainedCourses.filter { !chosen.contains($0) }.sorted()
    }

    private var filteredCourses: [String] {
        let base = availableCourses
        let q = courseQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return base }
        let ql = q.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return base.filter { $0.folding(options: .diacriticInsensitive, locale: .current).lowercased().contains(ql) }
    }

    // MARK: - Meta corso (docente cognome + CFA) con fallback via Mirror
    private func normalized(_ s: String) -> String {
        s.folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func examForCourse(title: String) -> Esame? {
        let key = normalized(title)
        return coreExams.first { normalized(prettifyTitle($0.corso)) == key || normalized($0.corso) == key }
    }

    private func mirrorString(from e: Esame, keys: [String]) -> String? {
        let m = Mirror(reflecting: e)
        for c in m.children {
            let label = (c.label ?? "").lowercased()
            if keys.contains(where: { label.contains($0) }) {
                if let s = c.value as? String, !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return s }
                if let opt = c.value as? Optional<String>, let s = opt, !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return s }
                if let any = c.value as? CustomStringConvertible { return String(describing: any) }
            }
        }
        return nil
    }

    private func mirrorInt(from e: Esame, keys: [String]) -> Int? {
        let m = Mirror(reflecting: e)
        for c in m.children {
            let label = (c.label ?? "").lowercased()
            if keys.contains(where: { label.contains($0) }) {
                if let i = c.value as? Int { return i }
                if let d = c.value as? Double { return Int(d.rounded()) }
                if let s = c.value as? String {
                    let digits = s.compactMap { $0.isNumber ? $0 : nil }
                    if let i = Int(String(digits)) { return i }
                }
            }
        }
        return nil
    }

    private func professorSurname(for title: String) -> String? {
        guard let e = examForCourse(title: title) else { return nil }
        let raw = mirrorString(from: e, keys: ["docente", "profess", "teacher"])?.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let full = raw, !full.isEmpty else { return nil }
        let parts = full.split{ $0 == " " || $0 == "\t" || $0 == "\n" }
        guard let last = parts.last else { return full }
        return String(last).localizedCapitalized
    }

    private func cfaForCourse(title: String) -> Int? {
        guard let e = examForCourse(title: title) else { return nil }
        return mirrorInt(from: e, keys: ["cfa", "cfu", "credit", "ects"]) // supporta CFA/CFU/crediti/ECTS
    }

    // Medie
    private var currentAvg30: Double? {
        guard !numericGrades.isEmpty else { return nil }
        return Double(numericGrades.reduce(0,+)) / Double(numericGrades.count)
    }
    private var currentAvg110: Int? { currentAvg30.map { Int(($0 / 30.0 * 110.0).rounded()) } }

    private var newAvg30: Double? {
        let baseSum = numericGrades.reduce(0,+)
        let baseCount = numericGrades.count
        let simSum = simulated.reduce(0) { $0 + $1.grade }
        let simCount = simulated.count
        guard baseCount + simCount > 0 else { return nil }
        return Double(baseSum + simSum) / Double(baseCount + simCount)
    }
    private var newAvg110: Int? { newAvg30.map { Int(($0 / 30.0 * 110.0).rounded()) } }

    private var delta30: Double? {
        guard let cur = currentAvg30, let n = newAvg30 else { return nil }
        return n - cur
    }
    private var delta110: Int? {
        guard let cur = currentAvg110, let n = newAvg110 else { return nil }
        return n - cur
    }

    var body: some View {
        NavigationStack {
            List {
                // Stato attuale
                Section {
                    VStack(spacing: 12) {
                        HStack {
                            Label("Situazione attuale", systemImage: "chart.bar.fill")
                                .font(.headline)
                            Spacer()
                        }
                        HStack(spacing: 12) {
                            statBox(currentAvg30.map { String(format: "%.2f", $0) } ?? "—", "Media attuale", "number")
                            statBox(currentAvg110.map { "\($0)" } ?? "—", "Voto d'Ingresso", "graduationcap.fill")
                        }
                        HStack(spacing: 8) {
                            statusPill(title: "Sostenuti", value: "\(sustainedCount)", tint: .green)
                            statusPill(title: "Totali", value: "\(totalCount)", tint: nil)
                            statusPill(title: "Da sostenere", value: "\(notSustainedCount)", tint: .red)
                        }
                    }
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.cardBG))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                }

                // Aggiungi esami non sostenuti (NUOVA UX)
                Section("Aggiungi esami non sostenuti") {
                    if availableCourses.isEmpty && simulated.isEmpty {
                        Text("Hai già completato tutti gli esami previsti dal piano.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    } else if simulated.isEmpty {
                        VStack(spacing: 8) {
                            HStack(spacing: 6) {
                                Image(systemName: "sparkles").imageScale(.medium)
                                Text("Nessuna simulazione")
                                    .font(.subheadline.weight(.semibold))
                            }
                            Text("Aggiungi un esame non sostenuto per iniziare il calcolo della tua media. Potrai impostare il voto dalla pillola nella lista.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                            Button {
                                showAddSheet = true
                            } label: {
                                Label("Aggiungi esami", systemImage: "plus.circle")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                    }

                    // Elenco simulazioni aggiunte
                    if !simulated.isEmpty {
                        ForEach(simulated) { item in
                            HStack(spacing: 6) {
                                Text(item.title)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Spacer(minLength: 4)

                                // Menu compatto per cambiare voto
                                Menu {
                                    if let idx = simulated.firstIndex(of: item) {
                                        ForEach((18...30).reversed(), id: \.self) { v in
                                            Button("\(v)") { simulated[idx].grade = v }
                                        }
                                    }
                                } label: {
                                    gradeBadge(item.grade)
                                }
                                .menuStyle(.automatic)
                            }
                        }
                        .onDelete { simulated.remove(atOffsets: $0) }
                        HStack(spacing: 8) {
                            Button {
                                showAddSheet = true
                            } label: {
                                Label("Aggiungi esami", systemImage: "plus.square.fill")
                                    .labelStyle(.iconOnly)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.blue)
                            .disabled(availableCourses.isEmpty)
                            .accessibilityLabel("Aggiungi esami")
                            .accessibilityHint("Aggiungi un esame alla simulazione")

                            Button(role: .destructive) {
                                simulated.removeAll()
                            } label: {
                                Label("Azzera simulazioni", systemImage: "trash")
                                    .labelStyle(.iconOnly)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.red)
                            .accessibilityLabel("Azzera simulazioni")
                            .accessibilityHint("Rimuove tutti gli esami simulati")
                        }
                    }
                }

                // Riepilogo nuova media
                Section {
                    VStack(spacing: 12) {
                        HStack {
                            Label("Media stimata", systemImage: "sparkles")
                                .font(.headline)
                            Spacer()
                        }
                        HStack(spacing: 12) {
                            statBox(newAvg30.map { String(format: "%.2f", $0) } ?? "—", "Media stimata", "number")
                            statBox(newAvg110.map { "\($0)" } ?? "—", "Voto d'Ingresso", "graduationcap.fill")
                        }
                        if !simulated.isEmpty, let cur = currentAvg30, let n = newAvg30, abs(n - cur) > 0.00001 {
                            HStack(spacing: 6) {
                                Image(systemName: n >= cur ? "arrow.up.right" : "arrow.down.right")
                                    .foregroundStyle(n >= cur ? Color.green : Color.red)
                                Text("Da \(String(format: "%.2f", cur)) a \(String(format: "%.2f", n)) in base agli esami simulati.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.cardBG))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                }

                if notSustainedCount > 0 {
                    Section {
                        Text("Suggerimento: questa simulazione considera solo i voti **verbalizzati**. Gli esami senza voto non influenzano la media finché non vengono registrati.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Simulatore media")
            .navigationBarTitleDisplayMode(.inline)
            // Toolbar removed as per instructions
        }
        // Gate laureato (blur)
        .overlay {
            if showGraduatedGate {
                ZStack {
                    Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
                    VStack(spacing: 12) {
                        Image(systemName: "graduationcap.fill").font(.title)
                        Text("Sei laureato, a cosa ti serve questa sezione?")
                            .font(.headline)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        HStack(spacing: 12) {
                            Button(role: .cancel) { dismiss() } label: { Text("Indietro") }
                            Button { withAnimation { showGraduatedGate = false } } label: {
                                Text("Entra comunque")
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }
                    .padding(24)
                    .background(RoundedRectangle(cornerRadius: 16).fill(.regularMaterial))
                    .padding()
                }
            }
        }
        .onAppear {
            showGraduatedGate = (notSustainedCount == 0)
        }
        // Sheet “Aggiungi esami…”
        .sheet(isPresented: $showAddSheet) {
            NavigationStack {
                List {
                    if filteredCourses.isEmpty {
                        ContentUnavailableView("Nessuna materia",
                                               systemImage: "book.closed",
                                               description: Text("Nessun risultato per la ricerca."))
                    } else {
                        ForEach(filteredCourses, id: \.self) { c in
                            Button {
                                if !simulated.contains(where: { $0.title == c }) {
                                    simulated.append(.init(title: c, grade: 30))
                                }
                                showAddSheet = false
                            } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(c)
                                        .font(.body.weight(.semibold))
                                        .lineLimit(2)
                                    HStack(spacing: 4) {
                                        if let prof = professorSurname(for: c) {
                                            HStack(spacing: 3) {
                                                Image(systemName: "person.fill").imageScale(.small)
                                                Text(prof)
                                            }
                                        }
                                        if let cfa = cfaForCourse(title: c) {
                                            if professorSurname(for: c) != nil { Text("•") }
                                            HStack(spacing: 3) {
                                                Image(systemName: "graduationcap.fill").imageScale(.small)
                                                Text("CFA \(cfa)")
                                            }
                                        }
                                        Spacer(minLength: 4)
                                        Image(systemName: "chevron.right").foregroundStyle(.tertiary)
                                    }
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                }
                            }
                            .buttonStyle(.plain)
                            .padding(.vertical, 1)
                        }
                    }
                }
                .searchable(text: $courseQuery,
                            placement: .navigationBarDrawer(displayMode: .always),
                            prompt: "Cerca materia")
                .navigationTitle("Aggiungi esami")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Chiudi") { showAddSheet = false } } }
            }
        }
    }

    @ViewBuilder private func statBox(_ value: String, _ caption: String, _ systemImage: String) -> some View {
        VStack(spacing: 2) {
            HStack(spacing: 6) {
                Image(systemName: systemImage).font(.caption)
                Text(caption).font(.caption).foregroundStyle(.secondary)
                Spacer(minLength: 0)
            }
            Text(value)
                .font(.title3.weight(.semibold))
                .monospacedDigit()
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.cardBG)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.primary.opacity(0.06), lineWidth: 1)
        )
    }

    // Badge voto compatta
    @ViewBuilder private func gradeBadge(_ v: Int) -> some View {
        Text("\(v)")
            .font(.caption.weight(.semibold))
            .monospacedDigit()
            .padding(.vertical, 4)
            .padding(.horizontal, 8)
            .background(Capsule().fill(Color.labaAccent.opacity(0.15)))
            .overlay(Capsule().stroke(Color.labaAccent.opacity(0.25), lineWidth: 1))
    }

    // Pill generica già usata sopra
    @ViewBuilder private func pill(_ text: String) -> some View {
        Text(text)
            .font(.caption)
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(Capsule().fill(Color.cardBG))
            .overlay(Capsule().stroke(Color.primary.opacity(0.06), lineWidth: 1))
    }
}

struct PergamenaRitiroView: View {
    // Documento opzionale (modulo pagamenti) da mostrare in "Documenti"
    let pagamenti: ThesisDocsView.ThesisItem?

    private enum Pane: String, CaseIterable, Identifiable { case overview, pagamento, consegna; var id: String { rawValue } }
    @State private var pane: Pane = .overview

    var body: some View {
        NavigationStack {
            List {
                // SWITCHER
                Section {
                    Picker("Sezione", selection: $pane) {
                        Text("Panoramica").tag(Pane.overview)
                        Text("Pagamento").tag(Pane.pagamento)
                        Text("Consegna").tag(Pane.consegna)
                    }
                    .pickerStyle(.segmented)
                }

                // ========== OVERVIEW ==========
                if pane == .overview {
                    Section {
                        VStack(spacing: 10) {
                            Image(systemName: "checkmark.seal.fill").font(.system(size: 38))
                            Text("Ritiro pergamena").font(.headline)
                            // KPI rapidi
                            HStack(spacing: 8) {
                                kpi("€ 90,86", "Bollettino c/c 1016", tint: .orange)
                                kpi("€ 16", "Marca da bollo", tint: .orange)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                    }

                    Section("In breve") {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Richiedi la pergamena dopo aver superato la tesi", systemImage: "graduationcap.fill")
                            Label("Paga il bollettino e prepara la marca da bollo", systemImage: "eurosign.square")
                            Label("Compila e consegna in Segreteria il modulo di richiesta", systemImage: "arrow.up.document.fill")
                            Label("Una volta disponibile, verrai contattato per fissare il ritiro", systemImage: "calendar.badge.clock")
                        }
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    }

                    Section("Certificato Sostutitivo") {
                        Text("Una volta completato il pagamento e inviata la richiesta, la Segreteria Didattica potrà rilasciare in tempi brevi un *Certificato Sostitutivo* che ha lo stesso valore *legale* della pergamena e il *Diploma Supplement* in italiano e in inglese contenente anche tutti gli esami sostenuti, poiché i tempi di consegna della pergamena potrebbero essere lunghi.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    
                    Section("Cos'è il Diploma Supplement?") {
                        
                        Text("È un documento ufficiale europeo che accompagna il diploma ufficiale. Riporta in modo chiaro il percorso di studi svolto in lingua Italiana e Inglese (corsi, esami, crediti, livello della qualifica) ed è pensato per facilitare il riconoscimento del titolo in Italia e all’estero, sia in ambito accademico che professionale.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                if pane == .pagamento {
                    Section {
                        card("Bollettino", icon: "doc.text.fill") {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text("Conto").font(.caption).foregroundStyle(.secondary)
                                    Spacer()
                                    Text("c/c 1016").font(.callout.weight(.semibold))
                                }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Intestazione").font(.caption).foregroundStyle(.secondary)
                                    Text("AGENZIA DELLE ENTRATE – CENTRO OPERATIVO DI PESCARA – TASSE SCOLASTICHE")
                                        .font(.footnote)
                                }
                            }
                        }

                        card("Causale", icon: "text.justify") {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Indica chiaramente:")
                                    .font(.footnote.weight(.semibold))
                                VStack(alignment: .leading, spacing: 6) {
                                    Label("richiesta di diploma (primo o secondo livello)", systemImage: "checkmark.circle")
                                    Label("nome, cognome e indirizzo del diplomato", systemImage: "checkmark.circle")
                                    Label("percorso accademico", systemImage: "checkmark.circle")
                                }
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                            }
                        }

                        card("Fac‑simile bollettino", icon: "square.and.arrow.down") {
                            NavigationLink {
                                MaterialiDocumentViewer(
                                    allegatoOid: "84b249c9-a61e-4f72-a0f9-d3f1bf215fd4",
                                    title: "Fac-simile bollettino postale",
                                    directURL: nil
                                )
                            } label: {
                                Label("Scarica fac‑simile", systemImage: "arrow.down.circle.fill")
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(Color.labaAccent)
                            .controlSize(.small)
                        }

                        card("Consegna ricevuta", icon: "tray.and.arrow.down.fill") {
                            Text("Porta in Segreteria la ricevuta del bollettino **accompagnata da una marca da bollo da € 16**.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }

                        card("Note", icon: "info.circle") {
                            Text("Gli importi possono variare in base a disposizioni degli organi statali competenti.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    } header: {
                        Text("Pagamento, causale e ricevuta")
                    }
                }

                if pane == .consegna {
                    Section("Appuntamento") {
                        HStack(spacing: 8) { kpi("Strettamente necessario", "per il ritiro della pergamena", warning: true) }
                        Text("Il ritiro avviene **solo su appuntamento** concordato presso la sede di Piazza di Badia a Ripoli 1/A.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }

                    // Delega (layout a 3 icone)
                    Section("Delega (se non puoi presentarti)") {
                        HStack(spacing: 12) {
                            VStack(spacing: 6) {
                                Image(systemName: "person.text.rectangle").font(.title3)
                                Text("Documento del delegato").font(.caption).multilineTextAlignment(.center)
                            }.frame(maxWidth: .infinity)
                            VStack(spacing: 6) {
                                Image(systemName: "doc.text").font(.title3)
                                Text("Delega firmata").font(.caption).multilineTextAlignment(.center)
                            }.frame(maxWidth: .infinity)
                            VStack(spacing: 6) {
                                Image(systemName: "person.crop.rectangle").font(.title3)
                                Text("Documento studente").font(.caption).multilineTextAlignment(.center)
                            }.frame(maxWidth: .infinity)
                        }
                        .padding(.vertical, 4)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Cos'è la delega")
                                .font(.subheadline.weight(.semibold))
                            Text("Con la delega puoi incaricare un'altra persona a ritirare la pergamena al posto tuo.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                            Text("Per procedere servono:")
                                .font(.footnote.weight(.semibold))
                            VStack(alignment: .leading, spacing: 6) {
                                Label("Documento del delegato: carta d'identità o patente in corso di validità.", systemImage: "person.text.rectangle")
                                Label("Delega firmata: semplice autorizzazione scritta e firmata dallo studente (usa il modulo standard se disponibile).", systemImage: "doc.text")
                                Label("Documento studente: copia del documento d'identità del titolare (\"fronte/retro\").", systemImage: "person.crop.rectangle")
                            }
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            Text("Senza uno di questi documenti il ritiro non può essere effettuato. La Segreteria potrebbe richiedere una copia da trattenere.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                // (DOCUMENTI pane and fallback removed)
            }
            .navigationTitle("Ritiro pergamena")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    // MARK: - UI helpers
    @ViewBuilder private func card(_ title: String, icon: String, @ViewBuilder content: () -> some View) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.headline)
                    .foregroundStyle(.primary)
                Text(title)
                    .font(.headline)
                Spacer(minLength: 0)
            }
            content()
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(uiColor: .secondarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.primary.opacity(0.06), lineWidth: 1)
        )
    }

    @ViewBuilder private func kpi(_ value: String, _ caption: String, tint: Color? = nil, warning: Bool = false) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.callout.weight(.semibold))
            Text(caption).font(.caption2).foregroundStyle(.secondary)
        }
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(warning ? Color.red.opacity(0.12) : (tint?.opacity(0.15) ?? Color.cardBG))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke((warning ? Color.red.opacity(0.3) : (tint?.opacity(0.35) ?? Color.primary.opacity(0.06))), lineWidth: 1)
        )
    }
}

struct DebugView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var notifStatus: UNAuthorizationStatus = .notDetermined
    @State private var isRegisteredAPNs: Bool = false
    @State private var apnsTokenHex: String = "—"
    @State private var fcmToken: String = "—"
    @State private var savedTopics: [String] = []
    @State private var desiredTopics: [String] = []

    private func short(_ s: String) -> String {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.count > 20 else { return t.isEmpty ? "—" : t }
        return String(t.prefix(10)) + "…" + String(t.suffix(8))
    }

    private func dataToHex(_ data: Data) -> String {
        data.map { String(format: "%02.2hhx", $0) }.joined()
    }

    private func indirizzoCode(from piano: String?) -> String? {
        guard let raw = piano, !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let ps = raw.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        // Bienni (2 anni)
        if ps.contains("interior") { return "INT" }
        if ps.contains("cinema") || ps.contains("audiovisiv") { return "CINEMA" }
        // Trienni (3 anni)
        if ps.contains("graphic") || ps.contains("multimedia") || ps.contains("grafica") { return "GD" }
        if ps.contains("fotografia") || ps.contains("photo") { return "FOTO" }
        if ps.contains("fashion") { return "FD" }
        if ps.contains("pittura") || ps.contains("painting") { return "PIT" }
        if ps.contains("regia") || ps.contains("videomaking") || ps.contains("regia e video") { return "REGIA" }
        if ps.contains("design") { return "DES" } // dopo Interior
        return nil
    }

    private func clampYear(_ year: Int, for indirizzo: String) -> Int {
        switch indirizzo {
        case "INT", "CINEMA": return max(1, min(2, year))
        default: return max(1, min(3, year))
        }
    }

    private func computeDesiredTopics() -> [String] {
        var out: Set<String> = ["tutti"]
        let isGraduated = (vm.status ?? "").localizedCaseInsensitiveContains("laureat")
        if let ind = indirizzoCode(from: vm.pianoStudi) { out.insert(ind) }
        if let ind = indirizzoCode(from: vm.pianoStudi), let yRaw = vm.currentYear {
            let y = clampYear(yRaw, for: ind)
            out.insert("anno_\(y)")
            out.insert("\(y)anno_\(ind)")
        } else if let y = vm.currentYear {
            out.insert("anno_\(y)")
        }
        if vm.currentYear == nil && !isGraduated, let ind = indirizzoCode(from: vm.pianoStudi) {
            out.insert("fuoricorso_\(ind)")
        }
        return Array(out).sorted()
    }

    private func permissionString(_ s: UNAuthorizationStatus) -> String {
        switch s {
        case .authorized: return "Autorizzato"
        case .denied: return "Negato"
        case .provisional: return "Provisional"
        case .ephemeral: return "Ephemeral"
        case .notDetermined: return "Non determinato"
        @unknown default: return "Sconosciuto"
        }
    }

    private func refreshFCMDiagnostics() {
        // Permessi + registrazione
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.notifStatus = settings.authorizationStatus
                #if canImport(UIKit)
                self.isRegisteredAPNs = UIApplication.shared.isRegisteredForRemoteNotifications
                #endif
            }
        }
        // APNs token
        #if canImport(FirebaseMessaging)
        if let apns = Messaging.messaging().apnsToken {
            self.apnsTokenHex = dataToHex(apns)
        } else {
            self.apnsTokenHex = "—"
        }
        // FCM token
        Messaging.messaging().token { token, _ in
            DispatchQueue.main.async { self.fcmToken = token ?? "—" }
        }
        #endif
        // Snapshot topics salvati
        self.savedTopics = (UserDefaults.standard.array(forKey: "laba.fcm.topics") as? [String] ?? []).sorted()
        // Desired dall’attuale stato VM
        self.desiredTopics = computeDesiredTopics()
    }

    private func forceRefetchFCMToken() {
        #if canImport(FirebaseMessaging)
        Messaging.messaging().token { token, error in
            DispatchQueue.main.async {
                if let error = error { print("[FCM] token fetch error=\(error.localizedDescription)") }
                self.fcmToken = token ?? "—"
            }
        }
        #endif
    }

    private func realignTopicsNow() {
        applyFCMTopicsIfReady(using: vm)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.savedTopics = (UserDefaults.standard.array(forKey: "laba.fcm.topics") as? [String] ?? []).sorted()
        }
    }

    private func clearTopicsSnapshot() {
        TopicAssegnato.clearAll()
        self.savedTopics = []
    }

    private let df: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .short
        f.timeStyle = .short
        return f
    }()

    private func ts(_ t: Double) -> String { t > 0 ? df.string(from: Date(timeIntervalSince1970: t)) : "—" }

    private func humanize(_ s: Int) -> String {
        let v = max(0, s)
        if v < 60 { return "\(v) s" }
        if v < 3600 { return "\(v/60) min" }
        let h = v / 3600
        let m = (v % 3600) / 60
        return m > 0 ? "\(h) h \(m) min" : "\(h) h"
    }


    // MARK: - App/Device info & copy helpers
    @State private var copied: String? = nil

    private var appVersion: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "—"
    }
    private var buildNumber: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "—"
    }
    private var bundleId: String {
        Bundle.main.bundleIdentifier ?? "—"
    }
    private var appName: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String)
        ?? (Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String)
        ?? "—"
    }
    private var osVersion: String {
        "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)"
    }
    private var deviceIdentifier: String {
        var sys = utsname(); uname(&sys)
        let id = Mirror(reflecting: sys.machine).children.reduce(into: "") { acc, el in
            guard let v = el.value as? Int8, v != 0 else { return }
            acc.append(String(UnicodeScalar(UInt8(v))))
        }
        return id.isEmpty ? UIDevice.current.model : id
    }

    private func copyToPasteboard(_ value: String?) {
        guard let s = value, !s.isEmpty else { return }
        UIPasteboard.general.string = s
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        copied = s
    }
    
    var body: some View {
        List {
            // SESSIONE
            Section("Sessione") {
                LabeledContent("Logged in") { Text(vm.isLoggedIn ? "Sì" : "No") }
                LabeledContent("Utente") { Text(vm.displayName ?? "—") }
                LabeledContent("Piano studi") { Text(vm.pianoStudi ?? "—") }
                LabeledContent("Anno attuale") { Text(vm.currentYear != nil ? String(vm.currentYear!) : "—") }
            }

            // TOKEN
            Section("Token JWT") {
                LabeledContent("Prefix") { Text(vm.tokenPrefix).textSelection(.enabled) }
                LabeledContent("Lunghezza") { Text("\(vm.accessToken.count) chars") }
                LabeledContent("Stato") {
                    if let rem = vm.tokenSecondsRemaining { Text(rem > 0 ? "valido" : "scaduto") } else { Text("—") }
                }
                LabeledContent("Scadenza") {
                    if let exp = vm.tokenExpiryDate { Text(df.string(from: exp)) } else { Text("—") }
                }
                LabeledContent("Residuo") {
                    if let s = vm.tokenSecondsRemaining { Text("\(humanize(s)) (") + Text("\(max(0,s)) s").monospacedDigit() + Text(")") } else { Text("—") }
                }
            }
            
            // APP / DEVICE
            Section("App / Device") {
                LabeledContent("App") { Text(appName) }
                LabeledContent("Versione") { Text("\(appVersion) (\(buildNumber))") }
                LabeledContent("Bundle") { Text(bundleId).textSelection(.enabled) }
                LabeledContent("iOS") { Text(osVersion) }
                LabeledContent("Modello") { Text(deviceIdentifier) }
            }
            
            Section("Keychain / Credentials") {
                // Lettura con type-erasure + unwrap Optional per mostrare i campi reali
                let rawAnyOpt: Any? = (KeychainHelper.loadCredentials() as Any)
                if let rawAny = rawAnyOpt {
                    let any: Any = {
                        let m = Mirror(reflecting: rawAny)
                        return m.displayStyle == .optional ? (m.children.first?.value ?? rawAny) : rawAny
                    }()

                    Text("🔑 Keychain: trovato")
                    if let dict = any as? [String:String] {
                        let u = dict["username"] ?? dict["usernameBase"] ?? "?"
                        let p = dict["password"] ?? "?"
                        Text(" - username: \(u)")
                        Text(" - password: \(String(repeating: "•", count: max(1, p.count)))")
                    } else {
                        // Tupla/struct via Mirror, supporta label e posizioni .0/.1
                        let m = Mirror(reflecting: any)
                        let extracted: (String?, String?) = {
                            var u: String? = nil
                            var p: String? = nil
                            for c in m.children {
                                switch c.label ?? "" {
                                case "usernameBase", "username", ".0":
                                    u = (c.value as? String) ?? u
                                case "password", ".1":
                                    p = (c.value as? String) ?? p
                                default: break
                                }
                            }
                            return (u, p)
                        }()
                        let u = extracted.0
                        let p = extracted.1
                        Text(" - username: \(u ?? "?")")
                        Text(" - password: \(p != nil ? String(repeating: "•", count: max(1, p!.count)) : "?")")
                        Text(" - formato: \(String(describing: type(of: any)))")
                            .foregroundStyle(.secondary)
                    }
                } else {
                    Text("🔑 Keychain: vuoto")
                }

                // fallback UserDefaults
                let u = UserDefaults.standard.string(forKey: "laba.username") ?? "–"
                let p = UserDefaults.standard.string(forKey: "laba.password") ?? "–"
                Text("📦 Defaults:")
                Text(" - username: \(u)")
                Text(" - password: \(p)")
            }

            // REFRESH & SILENT LOGIN
            Section("Refresh & Silent login") {
                let ud = UserDefaults.standard
                LabeledContent("Ultimo restore") { Text(ts(ud.double(forKey: "laba.auth.lastRestoreAt"))) }
                LabeledContent("Ultimo tentativo") { Text(ts(ud.double(forKey: "laba.auth.lastAttemptAt"))) }
                LabeledContent("Tentativo prefix") { Text(ud.string(forKey: "laba.auth.lastAttemptPrefix") ?? "—").textSelection(.enabled) }
                LabeledContent("Ultimo successo") { Text(ts(ud.double(forKey: "laba.auth.lastSuccessAt"))) }
                LabeledContent("Success prefix") { Text(ud.string(forKey: "laba.auth.lastSuccessPrefix") ?? "—").textSelection(.enabled) }
                LabeledContent("Fail count") { Text(String(ud.integer(forKey: "laba.auth.failCount"))).monospacedDigit() }
                LabeledContent("Backoff fino a") {
                    let t = ud.double(forKey: "laba.auth.backoffUntil")
                    Text(t > 0 ? ts(t) : "—")
                }
            }
            
            Section(header: Text("Notifiche Push (FCM)")) {
                HStack { Text("Permesso"); Spacer(); Text(permissionString(notifStatus)).foregroundStyle(.secondary) }
                HStack { Text("APNs registrato"); Spacer(); Text(isRegisteredAPNs ? "sì" : "no").foregroundStyle(.secondary) }
                HStack {
                    Text("APNs token")
                    Spacer()
                    HStack(spacing: 8) {
                        Text(apnsTokenHex)
                            .font(.callout.monospaced())
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .textSelection(.enabled)
                        Button {
                            copyToPasteboard(apnsTokenHex)
                        } label: {
                            Image(systemName: "doc.on.doc")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Copia APNs token")
                    }
                }
                HStack {
                    Text("FCM token")
                    Spacer()
                    HStack(spacing: 8) {
                        Text(fcmToken)
                            .font(.callout.monospaced())
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .textSelection(.enabled)
                        Button {
                            copyToPasteboard(fcmToken)
                        } label: {
                            Image(systemName: "doc.on.doc")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Copia FCM token")
                    }
                }

                if !savedTopics.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Topic salvati").font(.footnote.weight(.semibold))
                        Text(savedTopics.joined(separator: ", ")).font(.footnote)
                    }
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                if !desiredTopics.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Iscrizione per i topic:").font(.footnote.weight(.semibold))
                        Text(desiredTopics.joined(separator: ", ")).font(.footnote)
                    }
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }

                HStack {
                    Button("Forza re-fetch") { forceRefetchFCMToken() }
                    Spacer()
                    Button("Riallinea topic") { realignTopicsNow() }
                }
                Button(role: .destructive) {
                    clearTopicsSnapshot()
                } label: {
                    Label("Pulisci snapshot topic salvati", systemImage: "trash")
                }
            }
            .onAppear { refreshFCMDiagnostics() }
            
            // AZIONI
            Section("Azioni") {
                Button("Forza restore sessione") {
                    Task {
                        let model = vm
                        await model.restoreSessionStrong()
                        NotificationCenter.default.post(name: .shouldReloadAfterAuth, object: nil)
                    }
                }
                Button("Ricarica dataset principali") {
                    Task {
                        let model = vm
                        await model.loadEsami()
                        await model.loadCorsi()
                        await model.loadSeminari()
                        await model.loadNotifications()
                    }
                }
                #if canImport(UIKit)
                Button("Copia token negli appunti") { UIPasteboard.general.string = vm.accessToken }
                    .buttonStyle(.bordered)
                #endif
            }

        }
        .tint(.indigo)
        .navigationTitle("Debug")
        .navigationBarTitleDisplayMode(.inline)
    }
}


fileprivate struct NotificationRowStock: View {
    let item: InboxItem

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Circle()
                .frame(width: 8, height: 8)
                .foregroundStyle(Color.labaAccent)
                .opacity(item.isRead ? 0 : 1)
                .padding(.top, 6)
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.body.weight(.semibold))
                    .lineLimit(2)
                Text(item.body)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            Spacer(minLength: 8)
            Text(relativeNoSeconds(from: item.date))
                .font(.footnote)
                .foregroundStyle(.secondary)
                .frame(minWidth: 58, alignment: .trailing)
        }
        .contentShape(Rectangle())
    }
}

fileprivate let relativeNoSecondsFormatter: DateComponentsFormatter = {
    let f = DateComponentsFormatter()
    f.unitsStyle = .abbreviated       // "3 min", "2 h", "1 g"
    f.allowedUnits = [.day, .hour, .minute]
    f.maximumUnitCount = 1            // una sola unità
    f.includesApproximationPhrase = false
    f.includesTimeRemainingPhrase = false
    return f
}()

fileprivate func relativeNoSeconds(from date: Date) -> String {
    let now = Date()
    let interval = now.timeIntervalSince(date)
    // Evitiamo i secondi: per <60s forziamo 60
    let clamped = max(interval, 60)
    let s = relativeNoSecondsFormatter.string(from: abs(clamped)) ?? ""
    return s.isEmpty ? tokenDateFormatter.string(from: date) : "\(s) fa"
}

struct NotificheInboxView: View {
    @EnvironmentObject var inbox: NotificationInboxStore

    @State private var previewItem: InboxItem? = nil
    @State private var showBulkConfirm: Bool = false
    @State private var bulkAction: BulkAction? = nil
    @State private var selectedItem: InboxItem? = nil

    private enum BulkAction { case markAllRead, markAllUnread, deleteAll }

    private func format(_ d: Date) -> String {
        let f = DateFormatter(); f.dateStyle = .short; f.timeStyle = .short; return f.string(from: d)
    }

    var body: some View {
        List {
            // Pulsante in cima: sempre presente
            Section {
                NavigationLink {
                    NotificheView().environmentObject(inbox)
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "tray.and.arrow.down.fill").font(.headline)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Avvisi sui caricamenti").font(.headline.bold())
                            Text("Vai alla lista completa")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 6)
                }
            }

            // Sotto: elenco o placeholder
            if inbox.items.isEmpty {
                Section {
                    VStack(spacing: 10) {
                        Image(systemName: "bell.slash.fill").font(.largeTitle).foregroundStyle(.secondary)
                        Text("Nessuna notifica").font(.headline)
                        Text("Quando arriveranno, le troverai qui.").font(.footnote).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 24)
                }
            } else {
                Section {
                    ForEach(inbox.items) { item in
                        NotificationRowStock(item: item)
                            .onTapGesture { selectedItem = item }
                            .onLongPressGesture { previewItem = item }
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                if item.isRead {
                                    Button {
                                        inbox.markRead(item.id, false)
                                    } label: {
                                        Label("Da leggere", systemImage: "envelope.badge")
                                    }
                                    .tint(.orange)
                                } else {
                                    Button {
                                        inbox.markRead(item.id, true)
                                    } label: {
                                        Label("Letta", systemImage: "checkmark.seal.fill")
                                    }
                                    .tint(.green)
                                }
                                Button(role: .destructive) {
                                    inbox.remove(id: item.id)
                                } label: {
                                    Label("Elimina", systemImage: "trash")
                                }
                            }
                            .contextMenu {
                                if item.isRead {
                                    Button("Da leggere", systemImage: "envelope.badge") { inbox.markRead(item.id, false) }
                                } else {
                                    Button("Segna letta", systemImage: "checkmark.seal.fill") { inbox.markRead(item.id, true) }
                                }
                                Divider()
                                Button(role: .destructive) { inbox.remove(id: item.id) } label: {
                                    Label("Elimina", systemImage: "trash")
                                }
                            }
                    }
                    .onDelete { idx in inbox.delete(idx) }
                }
            }
        }
        .listStyle(.insetGrouped)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("Segna tutte lette", systemImage: "checkmark.seal.fill") { bulkAction = .markAllRead; showBulkConfirm = true }
                    Button("Segna tutte da leggere", systemImage: "envelope.badge") { bulkAction = .markAllUnread; showBulkConfirm = true }
                    Divider()
                    Button(role: .destructive) { bulkAction = .deleteAll; showBulkConfirm = true } label: {
                        Label("Elimina tutte", systemImage: "trash")
                            .tint(.red)
                    }
                } label: {
                    Label("Azioni", systemImage: "ellipsis.circle")
                }
            }
        }
        .navigationTitle("Notifiche")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $previewItem) { it in
            NotificaPreviewSheet(item: it, dateString: format(it.date))
        }
        .alert("Sei sicuro?", isPresented: $showBulkConfirm) {
            switch bulkAction {
            case .markAllRead:
                Button("Segna tutte lette", role: .none) { inbox.markAllRead() }
            case .markAllUnread:
                Button("Segna tutte da leggere", role: .none) {
                    for id in inbox.items.map({ $0.id }) { inbox.markRead(id, false) }
                }
            case .deleteAll:
                Button("Elimina tutte", role: .destructive) {
                    let idx = IndexSet(inbox.items.indices)
                    inbox.delete(idx)
                }
            case .none:
                EmptyView()
            }
            Button("Annulla", role: .cancel) {}
        } message: {
            Text("Questa azione non può essere annullata.")
        }
        .navigationDestination(item: $selectedItem) { it in
            NotificaDetailView(item: it)
                .environmentObject(inbox)
        }
    }
}

fileprivate struct NotificaRowCard: View {
    let item: InboxItem
    let dateString: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill((item.isRead ? Color.gray.opacity(0.15) : Color.labaAccent.opacity(0.18)))
                    .frame(width: 34, height: 34)
                Image(systemName: item.isRead ? "bell" : "bell.badge.fill")
                    .font(.subheadline)
                    .foregroundStyle(item.isRead ? .secondary : Color.labaAccent)
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(item.title)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(2)
                    Spacer(minLength: 8)
                    Text(dateString)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Text(item.body)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .lineLimit(3)
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(uiColor: .secondarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.primary.opacity(0.06), lineWidth: 1)
        )
    }
}

fileprivate struct NotificaPreviewSheet: View, Identifiable {
    var id: String { item.id }
    let item: InboxItem
    let dateString: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Anteprima").font(.caption).foregroundStyle(.secondary)
                Spacer()
                Text(dateString).font(.caption2).foregroundStyle(.secondary)
            }
            Text(item.title).font(.headline)
            Text(item.body).font(.body)
                .foregroundStyle(.primary)
                .lineLimit(nil)
            Spacer(minLength: 0)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color(uiColor: .secondarySystemGroupedBackground)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.primary.opacity(0.06), lineWidth: 1))
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}

struct NotificaDetailView: View {
    @EnvironmentObject var inbox: NotificationInboxStore
    @Environment(\.dismiss) private var dismiss
    let item: InboxItem

    private func format(_ d: Date) -> String {
        let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .short; return f.string(from: d)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Header compact
                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.labaAccent.opacity(0.18))
                            .frame(width: 34, height: 34)
                        Image(systemName: "bell.fill")
                            .font(.subheadline)
                            .foregroundStyle(Color.labaAccent)
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.title)
                            .font(.title3.weight(.semibold))
                            .fixedSize(horizontal: false, vertical: true)

                        HStack(spacing: 8) {
                            Text(format(item.date))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                            HStack(spacing: 6) {
                                Image(systemName: item.isRead ? "checkmark.seal.fill" : "envelope.badge")
                                Text(item.isRead ? "Letta" : "Da leggere")
                            }
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Capsule().fill((item.isRead ? Color.green : Color.orange).opacity(0.15)))
                            .foregroundStyle(item.isRead ? Color.green : Color.orange)
                        }
                    }
                }
                .padding(16)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color(uiColor: .secondarySystemGroupedBackground)))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.06), lineWidth: 1))

                // Body text
                Text(item.body)
                    .font(.body)
                    .textSelection(.enabled)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.cardBG))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.06), lineWidth: 1))
            }
            .padding()
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Dettaglio")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    if item.isRead {
                        Button("Da leggere", systemImage: "envelope.badge") { inbox.markRead(item.id, false) }
                    } else {
                        Button("Segna letta", systemImage: "checkmark.seal.fill") { inbox.markRead(item.id, true) }
                    }
                    Divider()
                    Button(role: .destructive) { inbox.remove(id: item.id); dismiss() } label: {
                        Label("Elimina", systemImage: "trash")
                    }
                    ShareLink(item: "\(item.title) — \(item.body)") {
                        Label("Condividi", systemImage: "square.and.arrow.up")
                    }
                } label: {
                    Label("Azioni", systemImage: "ellipsis.circle")
                }
            }
        }
        .onAppear { inbox.markRead(item.id, true) }
    }
}

fileprivate struct ActionTile: View {
    let icon: String
    let label: String
    let tint: Color
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundStyle(tint)
                    .frame(width: 56, height: 56)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(tint.opacity(0.15))
                    )
                Text(label)
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Appearance Settings View


struct AppearanceSettingsView: View {
    @AppStorage("laba.theme") private var themePreference: String = "system"
    @AppStorage("laba.accent") private var accentChoice: String = "system"

    var body: some View {
        List {
            Section("Tema") {
                appearanceRow(title: "Sistema", tag: "system", icon: "gearshape.fill")
                appearanceRow(title: "Chiaro", tag: "light", icon: "sun.max.fill")
                appearanceRow(title: "Scuro", tag: "dark", icon: "moon.fill")
            }
            Section("Colore accento") {
                ForEach([
                    ("system","Sistema"),
                    ("peach","Pesca"),
                    ("lavender","Lavanda"),
                    ("mint","Menta"),
                    ("sand","Sabbia"),
                    ("sky","Cielo")
                ], id: \.0) { key, label in
                    HStack(spacing: 12) {
                        Circle()
                            .fill(AccentPalette.previewColor(named: key))
                            .frame(width: 18, height: 18)
                            .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                        Text(label)
                        Spacer()
                        if accentChoice == key { Image(systemName: "checkmark").foregroundStyle(.secondary) }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        accentChoice = key
                        UserDefaults.standard.set(key, forKey: "laba.accent")
                    }
                }
            }

            Section("Colori speciali") {
                HStack(spacing: 12) {
                    Circle()
                        .fill(AccentPalette.previewColor(named: "brand"))
                        .frame(width: 18, height: 18)
                        .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                    Text("Blu LABA")
                    Spacer()
                    if accentChoice == "brand" { Image(systemName: "checkmark").foregroundStyle(.secondary) }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
                .onTapGesture {
                    accentChoice = "brand"
                    UserDefaults.standard.set("brand", forKey: "laba.accent")
                }

                HStack(spacing: 12) {
                    Circle()
                        .fill(Color(red: 187/255, green: 39/255, blue: 26/255))
                        .frame(width: 18, height: 18)
                        .overlay(Circle().stroke(Color.primary.opacity(0.15), lineWidth: 1))
                    Text("Il male che risIEDe in voi")
                    Spacer()
                    if accentChoice == "IED" { Image(systemName: "checkmark").foregroundStyle(.secondary) }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
                .onTapGesture {
                    accentChoice = "IED"
                    UserDefaults.standard.set("IED", forKey: "laba.accent")
                }
            }
        }
        .navigationTitle("Aspetto")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if accentChoice == "seafoam" { // migrazione dal vecchio turchese
                accentChoice = "system"
                UserDefaults.standard.set("system", forKey: "laba.accent")
            }
        }
    }

    @ViewBuilder
    private func appearanceRow(title: String, tag: String, icon: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
            Text(title)
            Spacer()
            if themePreference == tag { Image(systemName: "checkmark").foregroundStyle(.secondary) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .onTapGesture {
            themePreference = tag
            UserDefaults.standard.set(tag, forKey: "laba.theme")
        }
    }
}

fileprivate struct RowPulseGlow: View {
    let active: Bool
    let color: Color
    let corner: CGFloat
    let minOpacity: Double
    let maxOpacity: Double
    @State private var on: Bool = false

    var body: some View {
        RoundedRectangle(cornerRadius: corner)
            .fill(Color.clear)
            .shadow(color: color.opacity(active ? (on ? maxOpacity : minOpacity) : 0.0),
                    radius: active ? (on ? 12 : 6) : 0,
                    x: 0, y: 0)
            .onAppear {
                guard active else { return }
                withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) {
                    on.toggle()
                }
            }
    }
}


struct DocumentiView: View {
    var body: some View {
        ContentUnavailableView(
            "In lavorazione…",
            systemImage: "hourglass",
            description: Text("Presto vedrai aggiornamenti in questa sezione.")
        )
        .navigationTitle("Documenti")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Regolamenti (documenti ufficiali LABA)
struct RegolamentiView: View {
    @State private var query: String = ""

    // Categorie logiche per raggruppare i documenti
    enum RegCategory: String, CaseIterable, Hashable {
        case istituzione = "Istituzione"
        case didattica   = "Didattica"
        case studenti    = "Studenti"
        case qualita     = "Qualità"
        case inclusione  = "Inclusione"
    }

    struct RegDoc: Identifiable, Hashable {
        let id = UUID()
        let title: String
        let url: URL
        let category: RegCategory
        let icon: String
        let note: String?
    }

    // Sorgente: link pubblici dal sito LABA (come da elenco fornito)
    private var allDocs: [RegDoc] {
        [
            RegDoc(
                title: "Statuto dell’istituzione",
                url: URL(string: "https://laba.biz/wp-content/uploads/2019/03/4.-Statuto-dellIstituzione.pdf")!,
                category: .istituzione,
                icon: "scroll.fill",
                note: "Finalità e principi dell'accademia"
            ),
            RegDoc(
                title: "Norme generali",
                url: URL(string: "https://laba.biz/wp-content/uploads/2025/03/REGOLAMENTO-GENERALE-24-25.pdf")!,
                category: .didattica,
                icon: "list.bullet.rectangle.portrait.fill",
                note: "Approfondimenti e integrazioni al Regolamento Didattico"
            ),
            RegDoc(
                title: "Regolamento didattico",
                url: URL(string: "https://laba.biz/wp-content/uploads/2025/03/REGOLAMENTO-DIDATTICO-APPROVATO.pdf")!,
                category: .didattica,
                icon: "book.pages.fill",
                note: "Approvato dal MUR"
            ),
            RegDoc(
                title: "Regolamento tesi",
                url: URL(string: "https://laba.biz/wp-content/uploads/2025/03/REGOLAMENTO-TESI-da-feb-2024.pdf")!,
                category: .didattica,
                icon: "graduationcap.fill",
                note: "Scadenze, consegne e voto finale"
            ),
            RegDoc(
                title: "Supporto per allievi",
                url: URL(string: "https://laba.biz/wp-content/uploads/2025/03/SUPPORTO-ALLA-DIDATTICA-PER-ALLIEVI-CON-DSA-BES-ADHD-A.A.-2024-2025.pdf")!,
                category: .inclusione,
                icon: "figure.and.child.holdinghands",
                note: "Tutor dedicati e modalità d’esame DSA/BES/ADHD"
            ),
            RegDoc(
                title: "Consulta degli Studenti",
                url: URL(string: "https://laba.biz/wp-content/uploads/2024/06/regolamento-consulta-degli-studenti.pdf")!,
                category: .studenti,
                icon: "person.3.fill",
                note: "Elezioni, funzioni e durata"
            ),
            RegDoc(
                title: "Qualità LABA",
                url: URL(string: "https://laba.biz/wp-content/uploads/2024/06/regolamento-qualita.pdf")!,
                category: .qualita,
                icon: "checkmark.seal.fill",
                note: "Comitato qualità e processi AQ"
            ),
            RegDoc(
                title: "Parità di genere",
                url: URL(string: "https://laba.biz/wp-content/uploads/2025/01/parita-di-Genere-Allegato-E-Piano-Strategico.pdf")!,
                category: .qualita,
                icon: "equal.circle.fill",
                note: "Obiettivi e misure adottate"
            )
        ]
    }

    // Filtro testuale
    private var filtered: [RegDoc] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return allDocs }
        let ql = q.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        return allDocs.filter { d in
            let hay = [d.title, d.note ?? "", d.category.rawValue]
                .joined(separator: " ")
                .folding(options: .diacriticInsensitive, locale: .current)
                .lowercased()
            return hay.contains(ql)
        }
    }

    // Raggruppo in sezioni con ordine fisso
    private struct RegSection: Identifiable {
        let id: RegCategory
        let title: String
        let items: [RegDoc]
    }
    private var grouped: [RegSection] {
        let order: [RegCategory] = [.istituzione, .didattica, .studenti, .qualita, .inclusione]
        let dict = Dictionary(grouping: filtered, by: { $0.category })
        return order.compactMap { cat in
            guard let arr = dict[cat], !arr.isEmpty else { return nil }
            return RegSection(id: cat, title: cat.rawValue,
                              items: arr.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending })
        }
    }

    var body: some View {
        NavigationStack {
            List {
                // INTRO (hero stile Tesi: icona e testo centrati, nessun background card)
                Section {
                    VStack(spacing: 12) {
                        Image(systemName: "scroll.fill")
                            .font(.system(size: 44, weight: .semibold))
                        Text("Regolamenti e Documenti Ufficiali")
                            .font(.headline)
                        Text("Raccolta dei testi ufficiali LABA: statuto, regolamenti didattici e generali, tesi, consulta studenti, qualità e inclusione.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                }

                // DOCUMENTI PER CATEGORIA
                ForEach(grouped) { group in
                    Section(group.title) {
                        ForEach(group.items) { d in
                            NavigationLink {
                                // Viewer PDF interno con URL diretto
                                MaterialiDocumentViewer(
                                    allegatoOid: "external-\(d.url.lastPathComponent)",
                                    title: d.title,
                                    directURL: d.url
                                )
                            } label: {
                                HStack(alignment: .firstTextBaseline, spacing: 8) {
                                    Image(systemName: d.icon).foregroundStyle(.secondary)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(d.title)
                                            .font(.body.weight(.semibold))
                                            .lineLimit(2)
                                        if let note = d.note, !note.isEmpty {
                                            Text(note)
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                }
                                .padding(.vertical, 2)
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Regolamenti")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query,
                        placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Cerca nei regolamenti")
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}

// MARK: - FAQ

struct FAQView: View {
    @EnvironmentObject var vm: SessionVM

    // Modelli
    struct FAQItem: Identifiable, Hashable { let id = UUID(); let q: String; let a: String }
    struct FAQCategory: Identifiable, Hashable { let id = UUID(); let title: String; let items: [FAQItem] }

    // TUTTE le categorie/Q&A (versione completa)
    private let cats: [FAQCategory] = [

        // 1) Domande comuni
        FAQCategory(title: "Domande comuni", items: [
            FAQItem(q: "Dove sono le sedi LABA Firenze?",
                    a: "Fashion Design: Via de' Vecchietti 6. Sede principale e altri indirizzi: Piazza di Badia a Ripoli 1/A."),
            FAQItem(q: "Come ricevo comunicazioni ufficiali?",
                    a: "Alla mail @labafirenze.com e come avvisi/notifiche in app."),
            FAQItem(q: "A chi scrivo per informazioni generali?",
                    a: "Alla Segreteria Didattica (info@laba.biz) indicando nome, cognome e matricola."),
            FAQItem(q: "Cos'è la media di carriera nell'app?",
                    a: "Media matematica sui CFA degli esami con voto; idoneità/attività senza voto non influiscono.")
        ]),

        // 2) Permessi e fuori corso
        FAQCategory(title: "Permessi e fuori corso", items: [
            FAQItem(q: "Posso chiedere un permesso prolungato?",
                    a: "Sì. Invia richiesta formale alla segreteria con documentazione. La Direzione valuta e risponde via mail."),
            FAQItem(q: "Quante assenze sono consentite?",
                    a: "Dipende dal corso. Consulta il programma o il docente."),
            FAQItem(q: "Sono fuori corso: cosa cambia?",
                    a: "Rimani iscritto finché completi esami/tesi; potrebbero valere quote e limiti. Verifica con la segreteria."),
            FAQItem(q: "Posso sostenere esami da fuoricorso?",
                    a: "Sì, nel rispetto di propedeuticità e calendario. Prenota gli appelli quando disponibili.")
        ]),

        // 3) Agevolazioni
        FAQCategory(title: "Agevolazioni", items: [
            FAQItem(q: "Esistono riduzioni o esoneri?",
                    a: "Eventuali agevolazioni (ISEE, merito, esigenze specifiche) sono pubblicate in bandi/regolamenti."),
            FAQItem(q: "Supporto per DSA/disabilità?",
                    a: "Sì. Scrivi alla segreteria allegando certificazione per attivare misure compensative/dispensive."),
            FAQItem(q: "Borse di studio?",
                    a: "Verifica i bandi regionali/nazionali e gli avvisi LABA pubblicati nei canali ufficiali.")
        ]),

        // 4) Iscrizione ad esami e seminari
        FAQCategory(title: "Iscrizione ad esami e seminari", items: [
            FAQItem(q: "Come mi iscrivo a un esame?",
                    a: "In app: Esami → corso → Prenota, quando l’appello è aperto."),
            FAQItem(q: "Perché non vedo ‘Prenota’?",
                    a: "Finestra non aperta, propedeuticità non superata o posizione amministrativa da regolarizzare."),
            FAQItem(q: "Posso annullare una prenotazione?",
                    a: "Sì se la finestra è aperta: apri la scheda e tocca Annulla; altrimenti contatta la segreteria."),
            FAQItem(q: "Come mi iscrivo a un seminario/tirocinio?",
                    a: "In app: Seminari → dettaglio → Prenota. Controlla requisiti, posti e CFA."),
            FAQItem(q: "Quando aprono gli appelli?",
                    a: "Le finestre sono comunicate da segreteria e compaiono in app quando attive."),
            FAQItem(q: "Serve aver superato esami propedeutici?",
                    a: "Sì. Senza i propedeutici richiesti non potrai prenotare l’esame successivo.")
        ]),

        // 5) Regolamenti e carriera
        FAQCategory(title: "Regolamenti e carriera", items: [
            FAQItem(q: "Cosa sono i CFA?",
                    a: "Crediti Formativi Accademici: misurano il carico di lavoro delle attività didattiche."),
            FAQItem(q: "Come vengono registrati i CFA dei seminari?",
                    a: "Dopo verifica presenze/prova, il docente/ufficio verbalizza e i crediti appaiono nel libretto."),
            FAQItem(q: "Cos'è una propedeuticità?",
                    a: "Vincolo: devi superare l’esame A per poterti iscrivere all’esame B."),
            FAQItem(q: "Posso sostenere esami di anno superiore?",
                    a: "Sì se rispetti propedeuticità e le regole del tuo indirizzo."),
            FAQItem(q: "Dove trovo i regolamenti?",
                    a: "In Profilo → Regolamenti e sul sito istituzionale LABA.")
        ]),

        // 6) Tesi e laurea
        FAQCategory(title: "Tesi e laurea", items: [
            FAQItem(q: "Cos'è la tesi di laurea?",
                    a: "Progetto/ricerca conclusiva con relatore, secondo linee guida su struttura e formati."),
            FAQItem(q: "Come scelgo relatore e tema?",
                    a: "Contatta i docenti dell’indirizzo con una proposta; la conferma passa dal coordinamento."),
            FAQItem(q: "Quando e come consegno i file?",
                    a: "Le scadenze e i formati sono nelle linee guida tesi. Rispetta nomi file e dimensioni."),
            FAQItem(q: "Sessioni di laurea: quando?",
                    a: "Le date sono comunicate dalla segreteria e pubblicate nei canali ufficiali."),
            FAQItem(q: "Come ritiro la pergamena?",
                    a: "La segreteria avvisa quando pronta. Ritiro su appuntamento con documento o delega."),
            FAQItem(q: "Cosa porto alla seduta?",
                    a: "Il materiale previsto dal regolamento tesi (presentazione, book, elaborati) e documento d’identità.")
        ]),

        // 7) Uso dell'app
        FAQCategory(title: "Uso dell'app", items: [
            FAQItem(q: "Non riesco ad accedere: cosa controllo?",
                    a: "Formato mail (nome.cognome@labafirenze.com), password, blocco maiuscole, connessione."),
            FAQItem(q: "Come cambio tema o colore accento?",
                    a: "Profilo → Aspetto: sistema/chiaro/scuro e palette colori."),
            FAQItem(q: "Perché non ricevo notifiche?",
                    a: "Verifica permessi iOS e la sezione Notifiche in app; le mail istituzionali arrivano comunque."),
            FAQItem(q: "Dove vedo media e CFA totali?",
                    a: "In Home nel riquadro Riepilogo e nel widget iOS."),
            FAQItem(q: "Posso contattare un docente dall'app?",
                    a: "Sì: swipe a sinistra sul corso o nel dettaglio → ‘Invia mail al docente’."),
            FAQItem(q: "Posso caricare una foto profilo?",
                    a: "Sì dall’avatar in Profilo; resta locale e non sostituisce la foto ufficiale.")
        ]),

        // 8) Software e laboratori
        FAQCategory(title: "Software e laboratori", items: [
            FAQItem(q: "Quali software si usano?",
                    a: "Suite Adobe, 3D (Cinema 4D, Rhinoceros) e strumenti specifici per indirizzo."),
            FAQItem(q: "Come attivo licenze educational?",
                    a: "Segui le istruzioni inviate alla mail istituzionale; licenze con scadenza annuale."),
            FAQItem(q: "Posso usare i laboratori fuori orario?",
                    a: "Orari e regole di prenotazione sono comunicati dall’Accademia."),
            FAQItem(q: "Problema tecnico in aula/lab: chi contatto?",
                    a: "Avvisa docente e reparto IT, indicando corso, aula e postazione."),
            FAQItem(q: "Uso software a casa: requisiti minimi?",
                    a: "Dipende dal software; consulta le specifiche fornite dal docente o nelle guide LABA.")
        ]),

        // 9) Orari e calendario
        FAQCategory(title: "Orari e calendario", items: [
            FAQItem(q: "Quando esce l'orario provvisorio?",
                    a: "All’inizio del semestre; variazioni via mail/avvisi."),
            FAQItem(q: "Dove vedo il calendario appelli?",
                    a: "In app (Esami) e nelle comunicazioni ufficiali quando attivati."),
            FAQItem(q: "Ci sono chiusure straordinarie?",
                    a: "Eventuali chiusure sono annunciate via mail e in app (Avvisi/Notifiche)."),
            FAQItem(q: "Come vengo informato sugli eventi?",
                    a: "Tramite sito, social e comunicazioni interne/seminari in app.")
        ]),

        // 10) Coordinatori e referenti
        FAQCategory(title: "Coordinatori e referenti", items: [
            FAQItem(q: "Chi è il coordinatore del mio indirizzo?",
                    a: "È indicato nell’organigramma sul sito; contatti reperibili anche tramite la segreteria."),
            FAQItem(q: "Come contatto il coordinamento?",
                    a: "Scrivi alla segreteria che indirizzerà la richiesta al referente corretto."),
            FAQItem(q: "A chi segnalo richieste didattiche?",
                    a: "Al docente del corso o al coordinatore di indirizzo, a seconda del tema.")
        ]),

        // 11) Pagamenti e posizione
        FAQCategory(title: "Pagamenti e posizione", items: [
            FAQItem(q: "Cosa significa ‘pagamenti non in regola’?",
                    a: "Verifica la posizione amministrativa; alcune funzioni (prenotazioni) possono essere bloccate."),
            FAQItem(q: "Posso sostenere esami con pagamenti in sospeso?",
                    a: "Di norma no, finché non regolarizzi."),
            FAQItem(q: "Dove trovo le scadenze di pagamento?",
                    a: "Nel contratto/iscrizione e nelle comunicazioni della segreteria."),
            FAQItem(q: "Ricevute e certificazioni?",
                    a: "Richiedile alla segreteria amministrativa indicando matricola e periodo d’interesse.")
        ]),

        // 12) Privacy e sicurezza
        FAQCategory(title: "Privacy e sicurezza", items: [
            FAQItem(q: "L'app salva dati sensibili?",
                    a: "Solo impostazioni locali (tema, accento, avatar). I dati accademici passano per servizi autenticati."),
            FAQItem(q: "Come gestite i miei dati?",
                    a: "Secondo privacy policy LABA. Consulta Profilo → Privacy Policy."),
            FAQItem(q: "Posso cancellare i dati locali dell'app?",
                    a: "Sì: effettua il logout e rimuovi l’app; alla nuova installazione ripartirai da zero.")
        ])
    ]

    @State private var selected: String = "Tutte"
    private var titles: [String] { ["Tutte"] + cats.map { $0.title } }
    private var categoriesToShow: [FAQCategory] {
        selected == "Tutte" ? cats : cats.filter { $0.title == selected }
    }

    var body: some View {
        List {
            ForEach(categoriesToShow) { c in
                Section {
                    ForEach(c.items) { it in
                        DisclosureGroup(it.q) {
                            Text(it.a)
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text(c.title)
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    // Puoi usare direttamente un Picker dentro al Menu
                    Picker("Categoria", selection: $selected) {
                        ForEach(titles, id: \.self) { Text($0).tag($0) }
                    }
                } label: {
                    // Etichetta con categoria corrente o “Tutte”
                    Label(selected == "Tutte" ? "Categoria" : selected,
                          systemImage: "line.3.horizontal.decrease.circle")
                }
            }
        }
    }
}


// MARK: - Calcolo Media (Ingresso Tesi)
struct CalcolaMediaView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var inputAvg: String = ""
    @State private var rawScaled: Double? = nil
    @State private var officialScaled: Int? = nil

    private func suggestedAverageFromApp() -> Double? {
        let numeric: [Int] = vm.esami.compactMap { e in
            let lowered = e.corso.lowercased()
            if lowered.contains("attivit") || lowered.contains("tesi") { return nil }
            guard let v = e.voto, !v.isEmpty else { return nil }
            let cleaned = v.replacingOccurrences(of: " e lode", with: "")
            let first = cleaned.components(separatedBy: "/").first ?? cleaned
            return Int(first.trimmingCharacters(in: .whitespaces))
        }
        guard !numeric.isEmpty else { return nil }
        let sum = numeric.reduce(0, +)
        return Double(sum) / Double(numeric.count)
    }

    private func computeScaledTo110(from avg30: Double) -> (raw: Double, official: Int) {
        let x = avg30 * (110.0 / 30.0)
        let frac = x - floor(x)
        let official: Int = (frac > 0.50) ? Int(ceil(x)) : Int(floor(x))
        return (x, official)
    }

    var body: some View {
        List {
            // Sezione calcolo – righe stabili, niente pop-in
            Section("Con quanto mi presenterò?") {
                HStack(spacing: 12) {
                    TextField("Media su 30 (es. 26,8)", text: $inputAvg)
                        .keyboardType(.decimalPad)
                    Button("Calcola") {
                        let cleaned = inputAvg.replacingOccurrences(of: ",", with: ".")
                        if let v = Double(cleaned) {
                            let out = computeScaledTo110(from: v)
                            rawScaled = out.raw
                            officialScaled = out.official
                        } else {
                            rawScaled = nil
                            officialScaled = nil
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.capsule)
                }
                .listRowSeparator(.hidden, edges: .bottom)

                LabeledContent("Ti presenterai con") {
                    Text(officialScaled != nil ? "\(officialScaled!)/110" : "—/110")
                        .font(.headline)
                }
                .listRowSeparator(.hidden, edges: .top)

                if let raw = rawScaled {
                    Text(String(format: "Valore preciso: %.2f/110", raw))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            // Sezione suggerimenti – usa footer per testo lungo (stock)
            Section {
                if let s = suggestedAverageFromApp() {
                    Button {
                        inputAvg = String(format: "%.1f", s)
                    } label: {
                        HStack(spacing: 12) {
                            Label("Usa la media proposta", systemImage: "sparkles")
                            Spacer()
                            Text(String(format: "%.1f", s))
                                .font(.headline)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Capsule().fill(Color(uiColor: .tertiarySystemGroupedBackground)))
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                } else {
                    Text("Non è disponibile una media proposta. Inseriscila manualmente.")
                        .foregroundStyle(.secondary)
                }
            } header: {
                Text("Suggerimenti")
            } footer: {
                VStack(alignment: .leading, spacing: 6) {
                    Text("1) Consideriamo solo gli esami con voto numerico. ‘30 e lode’ vale 30/30.")
                    Text("2) Idoneità, attività integrative e tirocini sono esclusi dal calcolo.")
                    Text("3) Sommiamo i voti numerici registrati e dividiamo per il loro numero.")
                    Text("4) Convertiamo la media in /110: media × 110 ÷ 30.")
                    Text("5) Arrotondamento: se la parte decimale > 0,50 arrotondiamo in su, altrimenti in giù.")
                    Text("Esempio: 28,8 × 110 ÷ 30 = 105,69 → 106/110.")
                        .monospaced()
                }
                .font(.footnote)
                .foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Voto d'Ingresso")
        .navigationBarTitleDisplayMode(.inline)
    }
}



// MARK: - Lesson Calendar (local + JSONBin)
struct LessonEvent: Identifiable, Codable, Hashable {
    // Prefer an explicit OID when available (or the first of oidCorsi), otherwise fall back to normalized name
    var id: String {
        let base: String
        if let single = oidCorso?.lowercased(), !single.isEmpty {
            base = single
        } else if let multi = oidCorsi?.first?.lowercased(), !multi.isEmpty {
            base = multi
        } else {
            let lowered = corso.lowercased()
            let filtered = lowered.unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }
            base = String(String.UnicodeScalarView(filtered))
        }
        return "\(base)-\(anno)-\(Int(start.timeIntervalSince1970))"
    }
    let corso: String
    let oidCorso: String?
    let oidCorsi: [String]? // se la lezione vale per più corsi
    let anno: Int
    let aula: String?
    let docente: String?
    let start: Date
    let end: Date
    let note: String?
}

final class LessonCalendarStore: ObservableObject {
    @Published private(set) var events: [LessonEvent] = []

    // Robust ISO8601 parsing (with/without fractional seconds)
    nonisolated(unsafe) private static let isoNoFrac: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withTimeZone, .withDashSeparatorInDate, .withColonSeparatorInTime]
        return f
    }()
    nonisolated(unsafe) private static let isoFrac: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds, .withTimeZone, .withDashSeparatorInDate, .withColonSeparatorInTime]
        return f
    }()
    nonisolated private static func decodeDate(_ decoder: Decoder) throws -> Date {
        let c = try decoder.singleValueContainer()
        let s = try c.decode(String.self)
        if let d = isoFrac.date(from: s) ?? isoNoFrac.date(from: s) { return d }
        throw DecodingError.dataCorruptedError(in: c, debugDescription: "Bad ISO8601 date: \(s)")
    }

    // Loader da bundle (sviluppo)
    func loadFromBundle(named name: String = "lezioni") {
        guard let url = Bundle.main.url(forResource: name, withExtension: "json") else { return }
        do {
            let data = try Data(contentsOf: url)
            let dec = JSONDecoder(); dec.dateDecodingStrategy = .custom(Self.decodeDate)
            let list = try dec.decode([LessonEvent].self, from: data)
            print("[Calendar] Bundle ok count=\(list.count) first=\(list.first?.corso ?? "-") @ \(String(describing: list.first?.start))")
            DispatchQueue.main.async { self.events = list }
        } catch {
            print("[Calendar] Errore parsing bundle: \(error)")
        }
    }
}

// Remote sync + cache (JSONBin)
extension LessonCalendarStore {
    private var cacheURL: URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent("lezioni-cache.json")
    }

    func loadCacheIfAvailable() {
        if let data = try? Data(contentsOf: cacheURL) {
            let dec = JSONDecoder(); dec.dateDecodingStrategy = .custom(Self.decodeDate)
            if let list = try? dec.decode([LessonEvent].self, from: data) {
                print("[Calendar] Cache ok count=\(list.count)")
                DispatchQueue.main.async { self.events = list }
            }
        }
    }

    @discardableResult
    func syncFromJsonBin(binId: String, accessKey: String, force: Bool = true) async -> Bool {
        print("[Calendar] Fetching JSONBin bin=\(binId.prefix(6))…")
        guard let url = URL(string: "https://api.jsonbin.io/v3/b/\(binId)/latest?meta=false") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue(accessKey, forHTTPHeaderField: "X-Access-Key")
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else { return false }
            print("[Calendar] HTTP status=\(http.statusCode), bytes=\(data.count)")
            let dec = JSONDecoder(); dec.dateDecodingStrategy = .custom(Self.decodeDate)
            let list = try dec.decode([LessonEvent].self, from: data)
            print("[Calendar] JSONBin ok count=\(list.count)")
            DispatchQueue.main.async { self.events = list }
            try? data.write(to: cacheURL, options: .atomic)
            return true
        } catch {
            print("[Calendar] JSONBin error: \(error.localizedDescription)")
            loadCacheIfAvailable()
            return false
        }
    }
}

fileprivate extension Array where Element == LessonEvent {
    func forToday() -> [LessonEvent] {
        let cal = Calendar.current
        return self.filter { cal.isDateInToday($0.start) }.sorted { $0.start < $1.start }
    }
}

struct HomeView: View {
    @EnvironmentObject var vm: SessionVM
    @EnvironmentObject var calendar: LessonCalendarStore
    // Kick a one-time refresh to ensure announcements are fetched (old Home did this explicitly)
    @State private var didKickAnnouncementsFetch = false

    // MARK: - Helpers (nuove regole LABA)
    private func isAttivitaOTesi(_ e: Esame) -> Bool {
        let t = e.corso.lowercased()
        return t.contains("attivit") || t.contains("tesi")
    }

    private func isIdoneita(_ e: Esame) -> Bool {
        let v = (e.voto ?? "").lowercased()
        return v.contains("idoneo") || v.contains("idonea") || v.contains("idone")
    }

    private func hasNumericVote(_ e: Esame) -> Bool {
        let v = e.voto ?? ""
        return v.range(of: #"^\s*\d+\s*/\s*\d+"#, options: .regularExpression) != nil
    }

    // Helpers per distinguere Attività integrative e Tesi
    private func isAttivitaIntegrativa(_ e: Esame) -> Bool {
        // Esempio nei dati: "ATTIVITÀ A SCELTA (Workshop/Seminari/Stage)"
        return e.corso.lowercased().contains("attivit")
    }

    private func isTesiFinale(_ e: Esame) -> Bool {
        return e.corso.lowercased().contains("tesi")
    }

    /// Conteggio esami totali: conta tutti i corsi che non sono Attività/Tesi,
    /// indipendentemente dal fatto che abbiano già un voto.
    private func isCountableForTotals(_ e: Esame) -> Bool {
        // Conta nel TOTALE tutti i corsi che non sono Attività/Tesi,
        // indipendentemente dal fatto che abbiano già un voto.
        return !isAttivitaOTesi(e)
    }

    /// Esami conteggiati (totali) = numerici + idoneità; esclusi Attività/Tesi
    private var validExams: [Esame] { vm.esami.filter { isCountableForTotals($0) } }

    /// Sostenuti ai fini del conteggio (numerici O idoneità con voto presente)
    private var passedExamsCount: Int {
        validExams.filter { !(($0.voto ?? "").isEmpty) }.count
    }

    /// Totale esami (numerici + idoneità), esclusi Attività/Tesi
    private var totalExamsCount: Int { validExams.count }
    private var missingExamsCount: Int { max(totalExamsCount - passedExamsCount, 0) }

    /// Stato: utente laureato
    private var isGraduated: Bool {
        (vm.status ?? "").lowercased().contains("laureat")
    }

    /// CFA: il TARGET è la somma di TUTTI i CFA (esami, idoneità, attività, tesi)
    private var cfaTarget: Int {
        vm.esami.reduce(0) { $0 + (Int($1.cfa ?? "") ?? 0) }
    }
    /// CFA guadagnati secondo regole LABA (esami + max 10 Attività integrative + Tesi)
    private var cfaEarned: Int {
        // Completamento = ha un voto (numerico o idoneità) oppure una data di sostenimento
        func isCompleted(_ e: Esame) -> Bool { !(e.voto ?? "").isEmpty || (e.sostenutoIl != nil) }

        // 1) Esami (escludi Attività e Tesi)
        let examsEarned = vm.esami.reduce(0) { acc, e in
            guard !isAttivitaIntegrativa(e), !isTesiFinale(e) else { return acc }
            guard isCompleted(e), let c = Int(e.cfa ?? "") else { return acc }
            return acc + c
        }

        // 2) Attività integrative (Seminari/Workshop/Tirocini) → max 10 CFA totali
        let attivita = vm.esami.filter { isAttivitaIntegrativa($0) }
        let declaredActivitiesCFA = attivita.compactMap { Int($0.cfa ?? "") }.reduce(0, +) // di solito 10
        let anyActivityCompleted = attivita.contains { isCompleted($0) }
        let activitiesEarned: Int = {
            if isGraduated { return 10 } // laureato: consideriamo acquisiti i 10 CFA totali di Attività
            return anyActivityCompleted ? min(10, declaredActivitiesCFA) : 0
        }()

        // 3) Tesi finale
        let thesis = vm.esami.filter { isTesiFinale($0) }
        let thesisCFA = thesis.compactMap { Int($0.cfa ?? "") }.first ?? 0
        let thesisCompleted = thesis.contains { isCompleted($0) }
        let thesisEarned = (isGraduated || thesisCompleted) ? thesisCFA : 0

        return examsEarned + activitiesEarned + thesisEarned
    }
    private var cfaPercent: Double {
        let tot = cfaTarget
        guard tot > 0 else { return 0 }
        return Double(cfaEarned) / Double(tot)
    }

    /// Avanzamento per ANNO CORRENTE: (anno, sostenuti, totali, percentuale)
    private var yearProgress: (year: Int, passed: Int, total: Int, percent: Double)? {
        guard let y = vm.currentYear else { return nil }
        let examsYear = vm.esami.filter { !isAttivitaOTesi($0) && $0.anno == y }
        let total = examsYear.count
        let passed = examsYear.filter { !(($0.voto ?? "").isEmpty) }.count
        let percent = total > 0 ? Double(passed) / Double(total) : 0
        return (y, passed, total, percent)
    }

    // Statistiche per anno: restituisce sostenuti, totali, mancanti e percentuale di completamento (1 - missing/total)
    private func statsForYear(_ y: Int) -> (passed: Int, total: Int, missing: Int, percent: Double) {
        let exams = vm.esami.filter { !isAttivitaOTesi($0) && $0.anno == y }
        let total = exams.count
        let passed = exams.filter { !(($0.voto ?? "").isEmpty) }.count
        let missing = max(0, total - passed)
        let percent = total > 0 ? 1.0 - (Double(missing) / Double(total)) : 0
        return (passed, total, missing, percent)
    }

    /// Media aritmetica sui soli voti numerici (0..30). Nil se assente
    private var careerAverageValue: Double? {
        let numeric = vm.esami.filter { !isAttivitaOTesi($0) && hasNumericVote($0) }
        let marks: [Int] = numeric.compactMap { e in
            let raw = (e.voto ?? "").replacingOccurrences(of: " e lode", with: "")
            return Int(raw.components(separatedBy: "/").first ?? "")
        }
        guard !marks.isEmpty else { return nil }
        return Double(marks.reduce(0, +)) / Double(marks.count)
    }

    // Schiarisce leggermente il colore d'accento per la pill in Hero
    private func lighterAccent(by delta: CGFloat = 0.15) -> Color {
#if canImport(UIKit)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        let ui = UIColor(.labaAccent)
        _ = ui.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        // aumenta la luminosità e riduce di poco la saturazione per migliorare il contrasto del testo bianco
        let nb = min(1.0, b + delta)
        let ns = max(0.0, s - (delta * 0.35))
        let out = UIColor(hue: h, saturation: ns, brightness: nb, alpha: a)
        return Color(out)
#else
        return Color.labaAccent.opacity(0.90)
#endif
    }

    // Calcola un outline accent che contrasta con il fill e con l'hero
    private func outlineAccent(from base: Color) -> Color {
#if canImport(UIKit)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        let ui = UIColor(base)
        // se non riesco a leggere HSB, ripiego su labaAccent più scuro
        guard ui.getHue(&h, saturation: &s, brightness: &b, alpha: &a) else {
            return Color.labaAccent.opacity(0.95)
        }
        // Outline più saturo e più scuro per staccare sia dal fill che dal gradient hero
        let ns = min(1.0, s + 0.18)
        let nb = max(0.0, b - 0.15)
        return Color(UIColor(hue: h, saturation: ns, brightness: nb, alpha: a))
#else
        return Color.labaAccent.opacity(0.95)
#endif
    }
    

    @ViewBuilder
    private var statusPillRow: some View {
        let isLaureato = vm.status?.lowercased().contains("laureat") ?? false
        if isLaureato {
            HStack(spacing: 6) {
                Pill(text: vm.graduatedWord(), kind: .status)
                    .foregroundStyle(Color.white) // testo bianco nella pillola
                    .background(
                        Capsule().fill(lighterAccent()) // fondo accent leggermente più chiaro
                    )
                    .overlay(
                        Capsule().stroke(outlineAccent(from: lighterAccent()), lineWidth: 1) // outline accent
                    )
                    .compositingGroup()

                Text("ma perché usi ancora l'app?")
                    .font(.callout)
                    .foregroundStyle(.white.opacity(0.95))

                Spacer()
            }
        } else if let year = vm.currentYear {
            HStack(spacing: 8) {
                Pill(text: italianOrdinalYear(year), kind: .year)
                    .foregroundStyle(Color.white) // testo bianco nella pillola
                    .background(
                        Capsule().fill(lighterAccent()) // fondo accent leggermente più chiaro
                    )
                    .overlay(
                        Capsule().stroke(outlineAccent(from: lighterAccent()), lineWidth: 1) // outline accent
                    )
                    .compositingGroup()

                let disp = courseDisplayInfo(from: vm.pianoStudi)
                Text((disp?.name ?? "") + ((disp?.aa ?? "").isEmpty ? "" : " • \(disp!.aa)"))
                    .font(.callout)
                    .foregroundStyle(.white.opacity(0.95)) // corso + A.A. sempre bianchi in HERO
                Spacer()
            }
        }
    }

    private func normalizeCourse(_ s: String) -> String {
        let folded = s.folding(options: .diacriticInsensitive, locale: .current)
        let lowered = folded.lowercased()
        let filtered = lowered.unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }
        return String(String.UnicodeScalarView(filtered))
    }

    private func surnamesOnly(from doc: String) -> String {
        // Separa eventuali docenti multipli su '/', '&', ','
        let separators = CharacterSet(charactersIn: "/,&")
        let parts = doc.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        // Particelle tipiche dei cognomi composti (italiano + comuni stranieri)
        let particles: Set<String> = [
            "di","de","del","della","dello","dei","degli","da",
            "van","von","la","le","lo","du","des","dos"
        ]

        func extractSurname(_ full: String) -> String {
            let tokens = full.split(separator: " ")
            guard !tokens.isEmpty else { return full }
            if tokens.count >= 2 {
                let last = String(tokens.last!)
                let penult = String(tokens[tokens.count - 2]).lowercased()
                if particles.contains(penult) || penult.hasPrefix("d'") {
                    return tokens.suffix(2).joined(separator: " ")
                }
                return last
            }
            return String(tokens[0])
        }

        let surnames = parts.map { extractSurname($0) }
        return surnames.joined(separator: " / ")
    }

    private func todaysLessonsForUser() -> [LessonEvent] {
        // Filtra le lezioni di OGGI per corsi dell'utente e, se noto, per anno corrente
        let todays: [LessonEvent] = calendar.events.forToday()
        guard !todays.isEmpty else { return [] }

        let myIds: Set<String> = Set(vm.esami.compactMap { e in
            if let direct = (Mirror(reflecting: e).children.first { $0.label == "oidCorso" }?.value as? String)?
                .lowercased(), !direct.isEmpty {
                return direct
            }
            return nil
        })
        let myKeys: Set<String> = Set(vm.esami.map { normalizeCourse($0.corso) })
        let userCode = indirizzoCodeFromPiano(vm.pianoStudi)

        let byCourse = todays.filter { ev in
            // Regola AULE Fashion-only → visibili solo a FD
            if let aula = ev.aula?.folding(options: String.CompareOptions.diacriticInsensitive, locale: Locale.current).lowercased() {
                let fashionRooms = ["sala rossa", "sala gialla", "atelier", "manifattura", "bottega"]
                if fashionRooms.contains(where: { aula.contains($0) }) {
                    return userCode == "FD"
                }
            }

            // Match forte via OID del corso
            if !myIds.isEmpty {
                if let oid = ev.oidCorso?.lowercased(), myIds.contains(oid) { return true }
                if let arr = ev.oidCorsi?.map({ $0.lowercased() }), !arr.isEmpty {
                    if !Set(arr).isDisjoint(with: myIds) { return true }
                }
            }

            // Se deduciamo indirizzo e non coincide con l'utente → escludi
            if let userCode, let evCode = indirizzoCodeFromCourseTitle(ev.corso), evCode != userCode {
                return false
            }

            // Fallback legacy: confronto su titolo normalizzato
            return myKeys.contains(normalizeCourse(ev.corso))
        }
        
        // Secondo filtro: per anno, se disponibile
        if let year = vm.currentYear {
            return byCourse.filter { $0.anno == year }
        } else {
            return byCourse
        }
    }

    private func nextLessonsForUser(limit: Int = 3) -> [LessonEvent] {
        // Prossimi eventi a partire da ora
        let upcoming = calendar.events
            .filter { $0.start >= Date() }
            .sorted { $0.start < $1.start }

        let myIds: Set<String> = Set(vm.esami.compactMap { e in
            if let direct = (Mirror(reflecting: e).children.first { $0.label == "oidCorso" }?.value as? String)?.lowercased(), !direct.isEmpty {
                return direct
            }
            return nil
        })
        let myKeys: Set<String> = Set(vm.esami.map { normalizeCourse($0.corso) })
        let byCourse: [LessonEvent] = upcoming.filter { ev in
            if !myIds.isEmpty {
                if let oid = ev.oidCorso?.lowercased(), myIds.contains(oid) { return true }
                if let arr = ev.oidCorsi?.map({ $0.lowercased() }), !arr.isEmpty {
                    if !Set(arr).isDisjoint(with: myIds) { return true }
                }
            }
            return myKeys.contains(normalizeCourse(ev.corso))
        }
        let filtered: [LessonEvent]
        if let year = vm.currentYear { filtered = byCourse.filter { $0.anno == year } } else { filtered = byCourse }
        return Array(filtered.prefix(limit))
    }
    
    // Cerchio data (accent color, testo bianco): Mese (3 lettere) + Giorno
    @ViewBuilder
    private func dateBadge(for date: Date) -> some View {
        let cal = Calendar.current
        let day = cal.component(.day, from: date)
        let dowFmt: DateFormatter = {
            let f = DateFormatter()
            f.locale = Locale(identifier: "it_IT")
            f.dateFormat = "EEE" // giorno della settimana breve (lun, mar, ...)
            return f
        }()
        let dow = dowFmt.string(from: date).uppercased()

        ZStack {
            Circle().fill(lighterAccent())
                .overlay(Circle().stroke(outlineAccent(from: lighterAccent()), lineWidth: 1))
            VStack(spacing: -2) {
                Text(dow)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                Text(String(format: "%02d", day))
                    .font(.system(size: 16, weight: .heavy, design: .rounded))
            }
            .foregroundStyle(Color.white)
        }
        .frame(width: 40, height: 40)
        .accessibilityLabel("\(dow) \(day)")
    }

    // Ricava il codice indirizzo dal piano di studi utente (DES, FD, GD, INT, ...)
    private func indirizzoCodeFromPiano(_ piano: String?) -> String? {
        guard let raw = piano, !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let ps = raw.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if ps.contains("fashion") { return "FD" }
        if ps.contains("interior") || ps.contains("interni") { return "INT" }
        if ps.contains("cinema") || ps.contains("audiovisiv") { return "CINEMA" }
        if ps.contains("regia") || ps.contains("videomaking") { return "REGIA" }
        if ps.contains("graphic") || ps.contains("grafica") || ps.contains("multimedia") { return "GD" }
        if ps.contains("fotografia") || ps.contains("photo") { return "FOTO" }
        if ps.contains("pittura") || ps.contains("painting") { return "PIT" }
        if ps.contains("design") { return "DES" } // dopo Interior e Fashion
        return nil
    }

    // Prova a dedurre l’indirizzo dal titolo del corso/lezione
    private func indirizzoCodeFromCourseTitle(_ title: String) -> String? {
        let t = title.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if t.contains("fashion") { return "FD" }
        if t.contains("interior") || t.contains("interni") { return "INT" }
        if t.contains("cinema") || t.contains("audiovisiv") { return "CINEMA" }
        if t.contains("regia") || t.contains("videomaking") { return "REGIA" }
        if t.contains("graphic") || t.contains("grafica") || t.contains("multimedia") { return "GD" }
        if t.contains("fotografia") || t.contains("photo") { return "FOTO" }
        if t.contains("pittura") || t.contains("painting") { return "PIT" }
        if t.contains("design") { return "DES" }
        return nil
    }
    
    // Restituisce le lezioni dell’utente per un giorno relativo (0=oggi, 1=domani, ...)
    private func lessons(forDayOffset offset: Int, limit: Int? = nil) -> [LessonEvent] {
        let cal = Calendar.current
        let start = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: Date()))!
        let end   = cal.date(byAdding: .day, value: 1, to: start)!

        let list = calendar.events
            .filter { $0.start >= start && $0.start < end }
            .sorted { $0.start < $1.start }

        // Filtra per i corsi dell’utente (stessa logica usata altrove)
        let myIds: Set<String> = Set(vm.esami.compactMap { e in
            if let direct = (Mirror(reflecting: e).children.first { $0.label == "oidCorso" }?.value as? String)?.lowercased(), !direct.isEmpty {
                return direct
            }
            return nil
        })
        let myKeys: Set<String> = Set(vm.esami.map { normalizeCourse($0.corso) })
        let userCode = indirizzoCodeFromPiano(vm.pianoStudi)

        let byCourse = list.filter { ev in
            // Regola AULE Fashion-only → visibili solo a FD
            if let aula = ev.aula?.folding(options: String.CompareOptions.diacriticInsensitive, locale: Locale.current).lowercased() {
                let fashionRooms = ["sala rossa", "sala gialla", "atelier", "manifattura", "bottega"]
                if fashionRooms.contains(where: { aula.contains($0) }) {
                    return userCode == "FD"
                }
            }
            // 1) Match forte via OID del corso
            if !myIds.isEmpty {
                if let oid = ev.oidCorso?.lowercased(), myIds.contains(oid) { return true }
                if let arr = ev.oidCorsi?.map({ $0.lowercased() }), !arr.isEmpty {
                    if !Set(arr).isDisjoint(with: myIds) { return true }
                }
            }
            // 2) Se riusciamo a dedurre un indirizzo dall'evento e dall'utente, escludi mismatch
            if let userCode, let evCode = indirizzoCodeFromCourseTitle(ev.corso), evCode != userCode {
                return false
            }
            // 3) Fallback sul titolo normalizzato (compatibile con dati legacy)
            return myKeys.contains(normalizeCourse(ev.corso))
        }

        let filtered: [LessonEvent]
        if let year = vm.currentYear { filtered = byCourse.filter { $0.anno == year } } else { filtered = byCourse }

        if let limit = limit { return Array(filtered.prefix(limit)) } else { return filtered }
    }



    // Estrae un "soggetto" leggibile da un oggetto notifica (preferisce subject/oggetto)
    private func notificationSubject<T>(_ n: T) -> String? {
        let prefer = ["subject", "oggetto", "object", "categoria", "category", "tipo", "type", "title"]
        let mirror = Mirror(reflecting: n)
        // livello 1
        for child in mirror.children {
            guard let label = child.label?.lowercased() else { continue }
            if prefer.contains(label), let s = child.value as? String {
                let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                if !t.isEmpty { return t }
            }
        }
        // livello 2 (es. payload/dto annidati)
        for child in mirror.children {
            let subMirror = Mirror(reflecting: child.value)
            for sub in subMirror.children {
                guard let label = sub.label?.lowercased() else { continue }
                if prefer.contains(label), let s = sub.value as? String {
                    let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { return t }
                }
            }
        }
        return nil
    }

    // Estrae il campo "messaggio" (o equivalenti) dall'oggetto notifica
    private func notificationMessage<T>(_ n: T) -> String? {
        let prefer = ["messaggio", "message", "body", "text", "descrizione", "description"]
        let mirror = Mirror(reflecting: n)
        // livello 1
        for child in mirror.children {
            guard let label = child.label?.lowercased() else { continue }
            if prefer.contains(label), let s = child.value as? String {
                let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                if !t.isEmpty { return t }
            }
        }
        // livello 2 (es. payload/dto annidati)
        for child in mirror.children {
            let subMirror = Mirror(reflecting: child.value)
            for sub in subMirror.children {
                guard let label = sub.label?.lowercased() else { continue }
                if prefer.contains(label), let s = sub.value as? String {
                    let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { return t }
                }
            }
        }
        return nil
    }

    // Riformatta il messaggio per la preview in Home (es. "Dispensa di X inserita" → "Inserita dispensa di X")
    private func reformatMessaggioHome(_ s: String) -> String {
        let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let norm = trimmed.folding(options: String.CompareOptions.diacriticInsensitive, locale: Locale.current).lowercased()

        if norm.contains("dispensa") {
            if let rx = try? NSRegularExpression(pattern: "(?i)dispensa\\s+di\\s+(.+?)\\s+inserita"),
               let m = rx.firstMatch(in: trimmed, range: NSRange(trimmed.startIndex..., in: trimmed)),
               let r1 = Range(m.range(at: 1), in: trimmed) {
                let materia = String(trimmed[r1]).trimmingCharacters(in: .whitespacesAndNewlines)
                return "Inserita dispensa di \(materia)"
            }
            return "Nuova dispensa inserita"
        }

        if norm.contains("programma") {
            return "Nuovo programma caricato"
        }

        return trimmed
    }

    // Trova il primo giorno >= offset che abbia almeno una lezione per l'utente
    private func nextDayOffsetWithLessons(start offset: Int = 1, maxLookahead: Int = 14) -> Int? {
        for d in offset...maxLookahead {
            if !lessons(forDayOffset: d).isEmpty { return d }
        }
        return nil
    }

    // Titolo header per un giorno relativo: "Domani" se offset==1, altrimenti "Lunedì 25 ago"
    private func dayHeaderTitle(forOffset offset: Int) -> String {
        let cal = Calendar.current
        let base = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: Date()))!
        let df = DateFormatter()
        df.locale = Locale(identifier: "it_IT")
        if offset == 1 { return "Domani" }
        df.setLocalizedDateFormatFromTemplate("EEEE d MMM")
        let s = df.string(from: base)
        return s.prefix(1).uppercased() + s.dropFirst()
    }

    // Slim custom progress bar used in "Come stai andando?"
    @ViewBuilder
    private func thinProgress(pct: Double) -> some View {
        let clamped = max(0.0, min(1.0, pct))
        // Usa SEMPRE il colore d'accento per track e fill (niente fallback su .primary)
        let track = Color.labaAccent.opacity(0.14)
        let start = lighterAccent() // accent leggermente più chiaro
        let end   = outlineAccent(from: start).opacity(0.85) // accent più saturo/scuro
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 3)
                .fill(track)
                .frame(height: 6)
            GeometryReader { geo in
                RoundedRectangle(cornerRadius: 3)
                    .fill(LinearGradient(colors: [start, end], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(6, geo.size.width * clamped), height: 6)
            }
            .frame(height: 6)
        }
        .accessibilityHidden(true)
    }

    @ViewBuilder
    private func lessonRow(_ ev: LessonEvent) -> some View {
        HStack(alignment: .top, spacing: 8) {
            // Nuovo: badge data a sinistra
            dateBadge(for: ev.start)
                .frame(width: 40) // spazio fisso per allineare le righe

            // Colonna orari (inizio/fine)
            VStack(alignment: .trailing, spacing: 2) {
                Text(ev.start, style: .time)
                    .monospacedDigit()
                Text(ev.end, style: .time)
                    .monospacedDigit()
            }
            .font(.subheadline.weight(.semibold))
            .frame(width: 66, alignment: .trailing)
            VStack(alignment: .leading, spacing: 2) {
                Text(ev.corso)
                    .font(.subheadline)
                HStack(spacing: 8) {
                    if let aula = ev.aula, !aula.isEmpty {
                        Image(systemName: "mappin.and.ellipse")
                        Text(aula)
                    }
                    if let aula = ev.aula, !aula.isEmpty, let doc = ev.docente, !doc.isEmpty {
                        Text("–").foregroundStyle(.tertiary)
                    }
                    if let doc = ev.docente, !doc.isEmpty {
                        Image(systemName: "person")
                        Text(surnamesOnly(from: doc))
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Spacer()
            // Year capsule removed as requested
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var lessonsTodayCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "calendar")
                Text("Le tue lezioni (non reali)").font(.headline)
            }
            .foregroundStyle(.primary)

            // Calcola lezioni di oggi (ancora da svolgere) e di domani
            let allToday = todaysLessonsForUser().sorted { $0.start < $1.start }
            let now = Date()
            let remainingToday = allToday.filter { $0.end >= now }

            if !remainingToday.isEmpty {
                // Sezioni: Oggi + (opzionale) Domani (preview di 1 evento se oggi ne resta solo 1)
                Text("Oggi").font(.subheadline.weight(.bold)).foregroundStyle(.secondary)
                ForEach(Array(remainingToday.enumerated()), id: \.element.id) { idx, ev in
                    lessonRow(ev)
                    if idx != remainingToday.count - 1 { Divider() }
                }

                Divider().padding(.top, 2)
                if let off = nextDayOffsetWithLessons(start: 1) {
                    let header = (off == 1) ? "Domani" : "Prossime lezioni"
                    Text(header)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                    let nextOfDay = lessons(forDayOffset: off, limit: 1)
                    ForEach(nextOfDay, id: \.id) { ev in
                        lessonRow(ev)
                    }
                } else {
                    Text("Nessuna lezione in calendario nei prossimi giorni.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            } else {
                Text("Oggi")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.secondary)
                Text("Nessuna lezione oggi.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Divider().padding(.top, 2)
                if let off = nextDayOffsetWithLessons(start: 1) {
                    let header = (off == 1) ? "Domani" : "Prossime lezioni"
                    Text(header)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                    let list = lessons(forDayOffset: off, limit: nil)
                    ForEach(Array(list.enumerated()), id: \.element.id) { idx, ev in
                        lessonRow(ev)
                        if idx != list.count - 1 { Divider() }
                    }
                } else {
                    Text("Nessuna lezione in calendario nei prossimi giorni.")
                    Text("Nessuna lezione in calendario nei prossimi giorni.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    // Estrae (best-effort) il nome della materia dal messaggio
    private func parsedCourse(from message: String?) -> String {
        let s = (message ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return "Materia" }

        // Pattern comuni: "Dispensa di <Materia> inserita", "Dispensa n. X di <Materia>", ecc.
        let patterns = [
            #"(?i)dispensa\s*(?:n\.|num\.?|numero)?\s*\d*\s*di\s+(.+?)(?:\s+-|\s+inserit[aoe]|$)"#,
            #"(?i)di\s+(.+?)(?:\s+-|\s+inserit[aoe]|$)"#,
            #"(?i)per(?:\n|\s)+il(?:\n|\s)+corso(?:\n|\s)+di\s+(.+?)(?:\s+-|\s+inserit[aoe]|$)"#,
            #"(?i)per\s+(.+?)(?:\s+-|\s+inserit[aoe]|$)"#
        ]

        for p in patterns {
            if let rx = try? NSRegularExpression(pattern: p),
               let m  = rx.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)),
               m.numberOfRanges >= 2,
               let r  = Range(m.range(at: 1), in: s) {
                let materia = String(s[r]).trimmingCharacters(in: .whitespacesAndNewlines)
                if !materia.isEmpty { return materia }
            }
        }
        return s
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // HERO
                    ZStack(alignment: .leading) {
                        let heroPair = heroGradient(from: .labaAccent)
                        LinearGradient(
                            gradient: Gradient(colors: [heroPair.0, heroPair.1]),
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        )
                        .frame(height: 140)
                        .cornerRadius(22)
                        .shadow(color: Color.labaAccent.opacity(0.18), radius: 10, x: 0, y: 5)
                        .overlay(
                            ConfettiOverlay()
                                .clipShape(RoundedRectangle(cornerRadius: 22))
                        )

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Ciao, \(vm.displayName ?? "")! 👋")
                                .font(.largeTitle.bold())
                                .foregroundStyle(.white)
                            statusPillRow
                        }
                        .padding(.horizontal, 26)
                    }
                    .padding(.horizontal)
                    .padding(.top, 12)

                    // KPI – testo nero; glow su "mancanti"
                    HStack(spacing: 16) {
                        kpiCard(title: "Esami\nsostenuti",
                                value: "\(passedExamsCount)",
                                emphasizeGlow: false)
                        kpiCard(title: "Esami\nmancanti",
                                value: "\(missingExamsCount)",
                                emphasizeGlow: true)
                        kpiCard(title: "CFA \nacquisiti",
                                value: "\(cfaEarned)",
                                emphasizeGlow: false)
                    }
                    .padding(.horizontal)

                    // Riepilogo anno corrente + Media totale
                    VStack(alignment: .leading, spacing: 10) {
                        // Avanzamento per anno (1º, 2º, 3º) — layout in 3 colonne
                        Text("Come stai andando?").font(.subheadline.weight(.bold))
                        HStack(spacing: 12) {
                            ForEach([1, 2, 3], id: \.self) { y in
                                let s = statsForYear(y)
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("Esami \(italianOrdinalYear(y))")
                                        .font(.footnote.weight(.semibold))
                                    thinProgress(pct: s.total > 0 ? s.percent : 0)
                                    Group {
                                        if s.total > 0 {
                                            if s.missing == 0 {
                                                HStack(spacing: 4) {
                                                    Image(systemName: "checkmark.seal")
                                                        .imageScale(.small)
                                                    Text("Completati")
                                                }
                                            } else {
                                                Text("\(s.missing) mancanti")
                                            }
                                        } else {
                                            Text("—")
                                        }
                                    }
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                        Divider().padding(.vertical, 4)
                        
                        // Media totale (tappabile → Andamento voti)
                        NavigationLink {
                            GradeTrendView().environmentObject(vm)
                        } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text("La tua media").font(.subheadline.weight(.bold))
                                    Spacer()
                                    Text(careerAverageValue != nil ? String(format: "%.2f", careerAverageValue!) : "—")
                                        .font(.headline.weight(.semibold))
                                        .monospacedDigit()
                                    Image(systemName: "chevron.right")
                                        .font(.footnote.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                
                                // progress più “accattivante”
                                ZStack(alignment: .leading) {
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(Color.primary.opacity(0.08))
                                        .frame(height: 8)
                                    GeometryReader { geo in
                                        let pct = careerAverageValue != nil ? max(0, min(1, (careerAverageValue!/30.0))) : 0
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(LinearGradient(colors: [Color.labaAccent.opacity(0.8),
                                                                          Color.labaAccent.opacity(0.35)],
                                                                 startPoint: .leading, endPoint: .trailing))
                                            .frame(width: max(10, geo.size.width * pct), height: 8)
                                    }
                                    .frame(height: 8)
                                }
                                
                                HStack(spacing: 4) {
                                    Image(systemName: "cursorarrow.click")
                                        .font(.caption) // stessa dimensione del testo
                                        .foregroundStyle(.secondary)
                                    Text("Clicca per scoprirla nel dettaglio")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color(uiColor: .secondarySystemGroupedBackground))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.primary.opacity(0.08), lineWidth: 1)
                    )
                    .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 4)
                    .padding(.horizontal)
                        
                    // PROSSIME LEZIONI – full width, icona sinistra
                    lessonsTodayCard
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(uiColor: .secondarySystemGroupedBackground)))
                    .shadow(color: Color.labaAccent.opacity(0.08), radius: 6, x: 0, y: 2)
                    .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "calendar.badge.clock")
                            Text("Prossimi esami").font(.headline)
                        }
                        Text("Al momento non ci sono esami programmati")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.vertical, 8)
                    }
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(uiColor: .secondarySystemGroupedBackground))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.primary.opacity(0.08), lineWidth: 1)
                    )
                    .shadow(color: Color.labaAccent.opacity(0.08), radius: 6, x: 0, y: 2)
                    .padding(.horizontal)

                    // PER TE — Scorciatoie (as native List)
                    PerTeSection()
                        .environmentObject(vm)

                    Spacer(minLength: 30)
                }
                .padding(.top, 6)
            }
            .background(Color(uiColor: .systemGroupedBackground))
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .navigationTitle(" ")
        .navigationBarTitleDisplayMode(.large)
        .toolbarBackground(.automatic, for: .navigationBar)
        .navigationBarBackButtonHidden(true)
        .task {
            if !didKickAnnouncementsFetch {
                didKickAnnouncementsFetch = true
                await vm.loadNotifications()
            }
        }
    }

    // MARK: - Hero Gradient Helper
    private func heroGradient(from accent: Color) -> (Color, Color) {
#if canImport(UIKit)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        let ui = UIColor(accent)
        _ = ui.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        let left = UIColor(hue: h,
                           saturation: min(1.0, s + 0.05),
                           brightness: max(0.60, min(0.95, b - 0.02)),
                           alpha: a)
        let right = UIColor(hue: h,
                            saturation: max(0.45, s - 0.28),
                            brightness: min(0.88, b + 0.18),
                            alpha: a)
        return (Color(left), Color(right))
#else
        return (accent.opacity(0.9), accent.opacity(0.7))
#endif
    }

    // MARK: - Subviews
    @ViewBuilder
    private func kpiCard(title: String, value: String, emphasizeGlow: Bool) -> some View {
        let esamiMancanti = missingExamsCount
        let isComplete = esamiMancanti == 0
        let completedFocus = emphasizeGlow && isComplete && totalExamsCount > 0

        // Opacità interna in funzione degli esami mancanti
        let opacity: Double = {
            let m = esamiMancanti
            if m <= 0 { return 0.06 }
            switch m {
            case 1: return 0.50
            case 2: return 0.44
            case 3: return 0.38
            case 4: return 0.31
            case 5: return 0.24
            default: return 0.06
            }
        }()

        ZStack {
            RoundedRectangle(cornerRadius: 14)
                .fill(completedFocus ? Color.labaAccent : Color(uiColor: .secondarySystemGroupedBackground))
                .overlay(
                    Group {
                        if !completedFocus {
                            AnimatedGradientBackground(base: .labaAccent, esamiMancanti: esamiMancanti)
                                .opacity(emphasizeGlow ? opacity : 0.06)
                                .mask(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke((completedFocus ? Color.white.opacity(0.18) : Color.primary.opacity(0.06)), lineWidth: 1)
                )

            // Content
            VStack(spacing: 6) {
                if completedFocus {
                    RibbonCheckIcon(size: 28, tint: .white)
                    Text("Hai sostenuto tutti gli esami!")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.95))
                } else {
                    Text(value)
                        .font(.title2).bold()
                        .foregroundColor(.primary)
                    Text(title)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
            }
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity, minHeight: 96, alignment: .center)
            .padding(6)
            .padding(.vertical, 3)
        }
        .background(
            TightGlow(active: completedFocus, color: .labaAccent, corner: 14)
        )
    }
    
    fileprivate struct PulseGlow: View {
        let active: Bool
        let color: Color
        let corner: CGFloat
        @State private var phase: Bool = false
        @Environment(\.colorScheme) private var scheme

        var body: some View {
            ZStack {
                // base bloom
                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? 0.35 : 0.26) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? 28 : 20) : 0)
                    .scaleEffect(active ? (phase ? 1.03 : 1.00) : 1.0)

                // outer bloom
                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? 0.22 : 0.18) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? 44 : 32) : 0)
                    .scaleEffect(active ? (phase ? 1.08 : 1.04) : 1.0)
            }
            .opacity(active ? (scheme == .dark ? 0.9 : 0.68) : 0.0)
            .blendMode(scheme == .dark ? .screen : .overlay)
            .allowsHitTesting(false)
            .onAppear {
                guard active else { return }
                withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) {
                    phase.toggle()
                }
            }
            .onChange(of: active) { _, newVal in
                if newVal {
                    withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) {
                        phase = true
                    }
                } else {
                    phase = false
                }
            }
        }
    }

    // Static glow effect for completed KPI
    fileprivate struct StaticGlow: View {
        let active: Bool
        let color: Color
        let corner: CGFloat
        let opacity: Double
        let radius: CGFloat
        @Environment(\.colorScheme) private var scheme

        var body: some View {
            ZStack {
                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? 0.36 : 0.30) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? 22 : 16) : 0)

                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? 0.22 : 0.22) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? 34 : 26) : 0)
                    .scaleEffect(active ? 1.06 : 1.0)
            }
            .blendMode(scheme == .dark ? .screen : .overlay)
            .allowsHitTesting(false)
        }
    }

    // Glow additivo stile "Apple Intelligence": leggero, fuori bordo, con respiro
    fileprivate struct AIGlow: View {
        let active: Bool
        let color: Color
        let corner: CGFloat
        @State private var phase: Bool = false
        @Environment(\.colorScheme) private var scheme

        var body: some View {
            ZStack {
                // Bloom esterno morbido (additivo) con intensità adattiva
                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? (phase ? 0.24 : 0.14) : (phase ? 0.20 : 0.12)) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? (phase ? 22 : 14) : (phase ? 18 : 12)) : 0)
                    .scaleEffect(active ? (phase ? 1.05 : 1.02) : 1)
                    .padding(-12) // estendi oltre i bordi per far "uscire" il glow
                    .allowsHitTesting(false)
                    .compositingGroup()
            }
            .blendMode(scheme == .dark ? .screen : .overlay)
            .onAppear {
                guard active else { return }
                withAnimation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true)) {
                    phase.toggle()
                }
            }
            .onChange(of: active) { _, newVal in
                if newVal {
                    withAnimation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true)) {
                        phase = true
                    }
                } else {
                    phase = false
                }
            }
        }
    }

    // Ribbon/premio con checkmark (sempre disponibile, iOS 15+)
    fileprivate struct RibbonCheckIcon: View {
        var size: CGFloat = 28
        var tint: Color = .labaAccent
        var body: some View {
            ZStack {
                Image(systemName: "rosette")
                    .font(.system(size: size))
                    .foregroundColor(tint)
            }
            .accessibilityLabel("Tutti gli esami sono stati sostenuti")
        }
    }
    // Glow molto aderente ai bordi (tighter edge glow) con effetto pulse di opacità
    fileprivate struct TightGlow: View {
        let active: Bool
        let color: Color
        let corner: CGFloat
        @State private var phase: Bool = false
        @Environment(\.colorScheme) private var scheme

        var body: some View {
            ZStack {
                // soft outer bloom per dare corpo in light/dark
                RoundedRectangle(cornerRadius: corner)
                    .fill(color.opacity(active ? (scheme == .dark ? 0.22 : 0.12) : 0.0))
                    .blur(radius: active ? (scheme == .dark ? 18 : 12) : 0)
                    .padding(-6)
                    .allowsHitTesting(false)

                // anello vicino al bordo
                RoundedRectangle(cornerRadius: corner)
                    .stroke(color.opacity(active ? (scheme == .dark ? 0.55 : 0.34) : 0.0), lineWidth: 4)
                    .blur(radius: active ? 4 : 0)
                    .padding(-3)
                    .allowsHitTesting(false)

                // bordo interno luminoso sottile
                RoundedRectangle(cornerRadius: corner)
                    .stroke(color.opacity(active ? (scheme == .dark ? 0.42 : 0.28) : 0.0), lineWidth: 2)
                    .blur(radius: active ? 0.8 : 0)
                    .allowsHitTesting(false)
            }
            // meno energia in light, identico in dark
            .opacity(active ? (scheme == .dark ? (phase ? 1.0 : 0.85) : (phase ? 0.78 : 0.64)) : 0.0)
            // evita sbiancamento in light (lascio .screen in dark)
            .blendMode(scheme == .dark ? .screen : .overlay)
            .onAppear {
                guard active else { return }
                withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) {
                    phase.toggle()
                }
            }
        }
    }

    @ViewBuilder
    private func perTeRow(icon: String, text: String) -> some View {
        HStack(spacing: 16) {
            Text(icon).font(.title2)
            Text(text).font(.headline)
            Spacer()
        }
        .padding(.vertical, 18)
        .padding(.horizontal, 18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.labaAccent.opacity(0.13))
                .shadow(color: Color.labaAccent.opacity(0.11), radius: 3, x: 0, y: 1)
        )
    }

    @ViewBuilder
    private func perTeQuickItem(icon: String, title: String, disabled: Bool = false) -> some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title2)
                .frame(width: 34, height: 34)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.labaAccent.opacity(0.15))
                )
            Text(title)
                .font(.footnote.weight(.semibold))
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .frame(maxWidth: .infinity)
            if disabled {
                Text("Prossimamente")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(uiColor: .secondarySystemGroupedBackground))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.primary.opacity(0.06), lineWidth: 1)
        )
    }

    @ViewBuilder
    private func perTeSystemRow(icon: String, title: String, enabled: Bool = true) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.headline)
                .frame(width: 28, height: 28)
                .foregroundStyle(.primary)
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Spacer()
            if enabled {
                Image(systemName: "chevron.right")
                    .font(.footnote)
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 4)
        .opacity(enabled ? 1.0 : 0.55)
        .contentShape(Rectangle())
    }

    // Media ARITMETICA sui soli voti numerici (escluse idoneità, Attività, Tesi)
    private func careerAverage() -> String {
        let numeric = vm.esami.filter { !isAttivitaOTesi($0) && hasNumericVote($0) }
        let marks: [Int] = numeric.compactMap { e in
            let raw = (e.voto ?? "").replacingOccurrences(of: " e lode", with: "")
            return Int(raw.components(separatedBy: "/").first ?? "")
        }
        guard !marks.isEmpty else { return "—" }
        let avg = Double(marks.reduce(0, +)) / Double(marks.count)
        return String(format: "%.1f", avg)
    }
}

// MARK: - Confetti overlay (Canvas) ispirato a AnimatedPatternBackground
fileprivate struct ConfettiOverlay: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1.0/30.0)) { timeline in
            let time = timeline.date.timeIntervalSinceReferenceDate
            GeometryReader { _ in
                Canvas { ctx, sz in
                    // Use fixed white color for confetti overlay
                    let color: Color = .white.opacity(0.28)
                    let step: CGFloat = 28
                    let r: CGFloat = 3.0
                    drawPattern(in: &ctx, size: sz, color: color, step: step, r: r, time: CGFloat(time))
                }
            }
        }
    }

    private func drawPattern(in ctx: inout GraphicsContext, size sz: CGSize, color: Color, step: CGFloat, r: CGFloat, time: CGFloat) {
        let t = time * 0.6
        for y in stride(from: -step, through: sz.height + step, by: step) {
            for x in stride(from: -step, through: sz.width + step, by: step) {
                let seed = (x * 13 + y * 7)
                let dx = sin((x + y) / 140 + t * (1.2 + 0.17 * sin(seed))) * 9 * (0.8 + 0.3 * cos(seed))
                let dy = cos((x - y) / 120 + t * (1.3 + 0.23 * cos(seed + 99))) * 9 * (0.8 + 0.3 * sin(seed + 42))
                let rect = CGRect(x: x + dx, y: y + dy, width: r * 2, height: r * 2)
                ctx.fill(Path(ellipseIn: rect), with: .color(color))
                ctx.stroke(Path(ellipseIn: rect), with: .color(color), lineWidth: 0.5)
            }
        }
    }
}

fileprivate struct AnimatedGradientBackground: View {
    let base: Color
    let esamiMancanti: Int

    // A few stable random seeds so the motion looks organic but deterministic per view life
    private let seeds: [CGFloat]
    private let spotsCount: Int = 6

    init(base: Color, esamiMancanti: Int) {
        self.base = base
        self.esamiMancanti = esamiMancanti
        // generate seeds once
        self.seeds = (0..<6).map { _ in .random(in: 0...1000) }
    }

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1.0/30.0)) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate
            GeometryReader { geo in
                Canvas { ctx, size in
                    let shades = makeShades(from: base, esamiMancanti: esamiMancanti)
                    let minSide = min(size.width, size.height)

                    // intensity factor grows when esamiMancanti -> 1 (0...1)
                    let maxStep = 5
                    let clamped = max(1, min(maxStep, esamiMancanti)) // 1..5
                    let factor = 1 - CGFloat(clamped - 1) / CGFloat(maxStep - 1)

                    for i in 0..<spotsCount {
                        // Pick a color from palette, cycling to ensure variety
                        let c = shades.isEmpty ? base.opacity(0.6) : shades[i % shades.count].opacity(0.75 + 0.15 * factor)

                        // Organic motion: slow Lissajous using seeds
                        let sx = seeds[i % seeds.count]
                        let sy = seeds[(i + 1) % seeds.count]
                        let px = 0.5 + 0.42 * sin( (t * 0.18) + Double(sx) / 37.0 + Double(i) )
                        let py = 0.5 + 0.42 * cos( (t * 0.15) + Double(sy) / 41.0 + Double(i) )

                        // Radius scales with view size + intensity
                        let baseR = minSide * (0.20 + 0.10 * CGFloat(i % 3))
                        let r = baseR * (0.92 + 55 * factor)

                        let center = CGPoint(x: px * size.width, y: py * size.height)
                        let grad = Gradient(colors: [
                            c.opacity(0.85),
                            c.opacity(0.35 + 0.25 * factor),
                            c.opacity(0.0)
                        ])

                        ctx.fill(
                            Path(ellipseIn: CGRect(x: center.x - r, y: center.y - r, width: r * 2, height: r * 2)),
                            with: .radialGradient(
                                grad,
                                center: center,
                                startRadius: 0,
                                endRadius: r
                            )
                        )
                    }
                }
                .mask(RoundedRectangle(cornerRadius: 14)) // keep it inside the card
            }
        }
    }

    #if canImport(UIKit)
    private func makeShades(from color: Color, esamiMancanti: Int) -> [Color] {
        let ui = UIColor(color)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard ui.getHue(&h, saturation: &s, brightness: &b, alpha: &a) else {
            return [color.opacity(0.95), color.opacity(0.75), color.opacity(0.55)]
        }

        // Intensità 0..1 (max a 1 esame, min oltre 5 esami)
        let maxStep = 5
        let clamped = max(1, min(maxStep, esamiMancanti))
        let factor = 1 - CGFloat(clamped - 1) / CGFloat(maxStep - 1) // 1→1.0, 5→0.0

        // Evita neri/grigi/bianchi: saturazione >= 0.60, brightness ∈ [0.40, 0.88]
        let satBase = max(0.60, s) + (0.22 * factor)
        let clampB: (CGFloat) -> CGFloat = { min(max($0, 0.40), 0.88) }

        let brightnessCenters: [CGFloat] = [
            clampB(b + 0.06),
            clampB(b + 0.14),
            clampB(b + 0.22)
        ]

        let satShifts: [CGFloat] = [-0.04, 0.0, 0.06, 0.12]

        var shades: [Color] = []
        for nb in brightnessCenters {
            let ns = min(max(satBase + (satShifts.randomElement() ?? 0), 0.60), 1.0)
            let c = UIColor(hue: h, saturation: ns, brightness: nb, alpha: a)
            shades.append(Color(c))
        }
        // aggiungi un tono leggermente più scuro ma mai “grigio”
        let darkerB = clampB(b - 0.10 + 0.04 * factor)
        let darkerS = min(1.0, max(0.60, satBase + 0.05))
        shades.append(Color(UIColor(hue: h, saturation: darkerS, brightness: darkerB, alpha: a)))
        return shades
    }
    #else
    private func makeShades(from color: Color, esamiMancanti: Int) -> [Color] {
        return [color.opacity(0.9), color.opacity(0.7), color.opacity(0.55)]
    }
    #endif
}

// MARK: - Display‑aware light boost for opacity
@inline(__always)
fileprivate func lightBoost(_ base: Double) -> Double {
#if canImport(UIKit)
    let gamut = UIScreen.main.traitCollection.displayGamut
    let isWideGamut = (gamut == .P3)
    let scale = UIScreen.main.nativeScale
    // Su device XDR/P3 il glow "sparisce" in light se troppo conservativo: alza leggermente
    let boost: Double = (isWideGamut && scale >= 3.0) ? 1.25 : 1.12
    return min(1.0, base * boost)
#else
    return base
#endif
}

// MARK: - Accent Color Helper
// MARK: - TightGlow
fileprivate struct TightGlow: View {
    let color: Color
    let active: Bool
    let phase: Bool
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(active ? (scheme == .dark ? 0.22 : lightBoost(0.15)) : 0.0))
                .blur(radius: active ? (scheme == .dark ? 18 : 12) : 0)
            Circle()
                .stroke(color.opacity(active ? (scheme == .dark ? 0.55 : lightBoost(0.32)) : 0.0), lineWidth: 4)
            Circle()
                .stroke(color.opacity(active ? (scheme == .dark ? 0.42 : lightBoost(0.24)) : 0.0), lineWidth: 2)
        }
        .opacity(active ? (scheme == .dark ? (phase ? 1.0 : 0.85) : (phase ? lightBoost(0.74) : lightBoost(0.62))) : 0.0)
        .blendMode(scheme == .dark ? .screen : .normal)
    }
}

// MARK: - PulseGlow
fileprivate struct PulseGlow: View {
    let color: Color
    let active: Bool
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(active ? (scheme == .dark ? 0.35 : lightBoost(0.26)) : 0.0))
                .blur(radius: active ? (scheme == .dark ? 34 : 28) : 0)
            Circle()
                .fill(color.opacity(active ? (scheme == .dark ? 0.22 : lightBoost(0.18)) : 0.0))
                .blur(radius: active ? (scheme == .dark ? 18 : 12) : 0)
        }
        .opacity(active ? (scheme == .dark ? 0.9 : lightBoost(0.66)) : 0.0)
        .blendMode(scheme == .dark ? .screen : .normal)
    }
}

// MARK: - StaticGlow
fileprivate struct StaticGlow: View {
    let color: Color
    let active: Bool
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(active ? (scheme == .dark ? 0.36 : lightBoost(0.28)) : 0.0))
                .blur(radius: active ? (scheme == .dark ? 26 : 18) : 0)
            Circle()
                .fill(color.opacity(active ? (scheme == .dark ? 0.22 : lightBoost(0.20)) : 0.0))
                .blur(radius: active ? (scheme == .dark ? 10 : 8) : 0)
        }
        .blendMode(scheme == .dark ? .screen : .normal)
    }
}

// MARK: - AIGlow
fileprivate struct AIGlow: View {
    let color: Color
    let active: Bool
    let phase: Bool
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        Circle()
            .fill(color.opacity(active ? (scheme == .dark ? (phase ? 0.24 : 0.14) : (phase ? lightBoost(0.20) : lightBoost(0.12))) : 0.0))
            .blur(radius: active ? (scheme == .dark ? 44 : 32) : 0)
            .blendMode(scheme == .dark ? .screen : .normal)
    }
}
extension Color {
    static var labaAccent: Color {
        let key = UserDefaults.standard.string(forKey: "laba.accent") ?? "system"
        // Mappa "system" (e legacy "seafoam") al colore d'accento di iOS
        if key == "system" || key == "seafoam" {
            return Color.accentColor
        }
        // Per il colore "brand" (Blu LABA) usa una variante dinamica più leggibile in Dark Mode
        if key == "brand" {
            #if canImport(UIKit)
            let base = UIColor(AccentPalette.color(named: "brand"))
            let dynamic = UIColor { tc in
                if tc.userInterfaceStyle == .dark {
                    var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                    guard base.getHue(&h, saturation: &s, brightness: &b, alpha: &a) else { return base }
                    // Aumenta la leggibilità su sfondo scuro: alza la luminosità minima e riduci leggermente la saturazione
                    let nb = min(1.0, max(b, 0.86))          // almeno ~86% di brightness
                    let ns = min(1.0, max(0.60, s * 0.95))   // saturazione leggermente ridotta ma ancora "blu LABA"
                    return UIColor(hue: h, saturation: ns, brightness: nb, alpha: a)
                } else {
                    return base // Light Mode: blu LABA puro
                }
            }
            return Color(dynamic)
            #else
            return AccentPalette.color(named: "brand")
            #endif
        }
        // Altri accenti: usa la palette così com'è
        return AccentPalette.color(named: key)
    }
}


// MARK: - Token helpers (JWT exp decoding)
fileprivate func base64URLDecode(_ input: String) -> Data? {
    var s = input.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
    let pad = 4 - (s.count % 4)
    if pad < 4 { s.append(String(repeating: "=", count: pad)) }
    return Data(base64Encoded: s)
}

fileprivate let tokenDateFormatter: DateFormatter = {
    let f = DateFormatter()
    f.dateStyle = .short
    f.timeStyle = .short
    return f
}()


extension SessionVM {
    // Prevent concurrent restores
    private static var _restoreInFlight: Bool = false
    /// Decodifica `exp` (epoch seconds) dal JWT se presente
    var tokenExpiryDate: Date? {
        guard !accessToken.isEmpty else { return nil }
        let parts = accessToken.split(separator: ".")
        guard parts.count >= 2,
              let data = base64URLDecode(String(parts[1])),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let exp = obj["exp"] as? Double
        else { return nil }
        return Date(timeIntervalSince1970: exp)
    }
    /// Secondi residui alla scadenza (se calcolabili)
    var tokenSecondsRemaining: Int? {
        guard let exp = tokenExpiryDate else { return nil }
        return Int(exp.timeIntervalSinceNow)
    }
    /// Prefisso leggibile del token per debug UI
    var tokenPrefix: String {
        accessToken.isEmpty ? "—" : String(accessToken.prefix(12))
    }
}

// MARK: - Robust silent restore (ROPC password login via Keychain)
extension SessionVM {
    // Legge una sola volta; usa type erasure ad Any per evitare warning di cast-impossibile
    static func fetchKeychainCredentials() -> (String, String)? {
        // Type-erasure + unwrap Optional (se loadCredentials() ritorna Optional<tupla/struct>)
        let rawAnyOpt: Any? = (KeychainHelper.loadCredentials() as Any)
        guard let rawAny = rawAnyOpt else { return nil }
        let any: Any = {
            let m = Mirror(reflecting: rawAny)
            return m.displayStyle == .optional ? (m.children.first?.value ?? rawAny) : rawAny
        }()

        // 1) Dizionario
        if let d = any as? [String: String] {
            if let u = d["usernameBase"], let p = d["password"] { return (u, p) }
            if let u = d["username"],     let p = d["password"] { return (u, p) }
        }

        // 2) Struct o Tupla (anche unlabeled) via Mirror
        let m = Mirror(reflecting: any)
        var u: String? = nil
        var p: String? = nil
        for c in m.children {
            switch c.label ?? "" {
            case "usernameBase", "username", ".0":
                u = (c.value as? String) ?? u
            case "password", ".1":
                p = (c.value as? String) ?? p
            default: break
            }
        }
        if let u, let p { return (u, p) }

        // 3) Fallback UserDefaults (legacy)
        if let u = UserDefaults.standard.string(forKey: "laba.username"),
           let p = UserDefaults.standard.string(forKey: "laba.password") {
            return (u, p)
        }
        return nil
    }

    // Shim sicuri: se KeychainHelper non espone questi metodi, fornisci stub che ritornano nil
    //private static func _maybeLoad(_ key: String) -> String? {
    //    (KeychainHelper.loadString?(forKey: key)) ?? nil
    //}

    /// Esegue un restore "forte": se il token è scaduto/sta per scadere, prova un login silenzioso usando le credenziali salvate in Keychain (ROPC), quindi assegna il nuovo token.
    @MainActor
    func restoreSessionStrong(force: Bool = false) async {
        // Evita restore concorrenti
        if Self._restoreInFlight {
            print("[Restore] skip: already in flight")
            return
        }
        Self._restoreInFlight = true
        defer { Self._restoreInFlight = false }

        // Se non forzato e il token è ancora buono per > 30s, esci
        let remaining = self.tokenSecondsRemaining ?? -9_999
        if !force && remaining > 30 {
            print("[Auth] restore not needed (token has \(remaining)s left)")
            return
        }

        // Backoff (persistito in UserDefaults per robustezza) — bypass se forzato
        let ud = UserDefaults.standard
        let now = Date().timeIntervalSince1970
        let backoffUntil = ud.double(forKey: "laba.auth.backoffUntil")
        if backoffUntil > now && !force {
            print("[Restore] backoff active: \(Int(backoffUntil - now))s left")
            return
        } else if backoffUntil > now && force {
            print("[Restore] FORCE bypass backoff (\(Int(backoffUntil - now))s left)")
        }

        // Credenziali dal Keychain (sempre: niente toggle "Resta collegato")
        guard let (usernameRaw, password) = Self.fetchKeychainCredentials() else {
            print("[Restore] no credentials available in Keychain")
            return
        }
        let username = normalizeUsername(usernameRaw)

        print("[Restore] attempting password login via Keychain for=\(username)")
        do {
            let token = try await Self.passwordLogin(username: username, password: password)
            self.accessToken = token
            ud.set(0, forKey: "laba.auth.failCount")
            ud.set(0.0, forKey: "laba.auth.backoffUntil")
            ud.set(now, forKey: "laba.auth.lastSuccessAt")
            print("[Restore] success → new token prefix=\(self.tokenPrefix)")
        } catch {
            let msg = String(describing: error)
            print("[Restore] error: \(msg)")

            // Se il server risponde invalid_client, il problema è di configurazione del client (non dell'utente)
            // → non ha senso fare backoff: mostriamo subito la Login UI in modo che l'utente non resti bloccato sulla schermata di refresh.
            if msg.contains("invalid_client") {
                print("[Restore] invalid_client → skip backoff, show interactive login")
                ud.removeObject(forKey: "laba.auth.backoffUntil")
                // Svuota il token per tornare a LoginView
                self.accessToken = ""
                self.isLoggedIn = false
                return
            }

            // Per altri errori: applica backoff esponenziale
            let fails = ud.integer(forKey: "laba.auth.failCount") + 1
            ud.set(fails, forKey: "laba.auth.failCount")
            let base: Double = 5.0
            let delay = min(300.0, pow(2.0, Double(max(0, fails - 1))) * base) // 5,10,20,40,80... max 300s
            ud.set(now + delay, forKey: "laba.auth.backoffUntil")
            print("[Restore] backoff set to \(Int(delay))s (fails=\(fails))")
        }
    }

    /// Aggiunge automaticamente il dominio se manca
    private func normalizeUsername(_ u: String) -> String {
        let trimmed = u.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.contains("@") { return trimmed }
        return trimmed + "@labafirenze.com"
    }

    /// Esegue un login password driven (ROPC) usando configurazione Info.plist (supporta Basic Auth e body secret)
    private static func passwordLogin(username: String, password: String) async throws -> String {
        // Config da Info.plist (per allineare silent e manuale)
        let tokenURL = (Bundle.main.object(forInfoDictionaryKey: "LABA_TOKEN_URL") as? String) ?? "https://logosuni.laba.biz/identityserver/connect/token"
        let clientId  = (Bundle.main.object(forInfoDictionaryKey: "LABA_CLIENT_ID") as? String) ?? "98C96373243D"
        let clientSec = (Bundle.main.object(forInfoDictionaryKey: "LABA_CLIENT_SECRET") as? String)
        let scope     = (Bundle.main.object(forInfoDictionaryKey: "LABA_SCOPE") as? String) ?? "LogosUni.Laba.Api"

        guard let url = URL(string: tokenURL) else { throw URLError(.badURL) }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")

        // Se ho il client_secret, uso anche Basic Auth (molti IdP lo richiedono)
        if let s = clientSec, !s.isEmpty {
            let basic = Data("\(clientId):\(s)".utf8).base64EncodedString()
            req.setValue("Basic \(basic)", forHTTPHeaderField: "Authorization")
        }

        // Body form-encoded
        var form: [String: String] = [
            "grant_type": "password",
            "client_id": clientId,
            "username": username,
            "password": password,
            "scope": scope
        ]
        if let s = clientSec, !s.isEmpty { form["client_secret"] = s }

        let allowed: CharacterSet = {
            var set = CharacterSet.urlQueryAllowed
            set.remove(charactersIn: "&=?+")
            return set
        }()
        let body = form.map { k, v in
            let ek = k.addingPercentEncoding(withAllowedCharacters: allowed) ?? k
            let ev = v.addingPercentEncoding(withAllowedCharacters: allowed) ?? v
            return "\(ek)=\(ev)"
        }.joined(separator: "&")
        req.httpBody = body.data(using: .utf8)

        // Diagnostic print: show config (mask secret)
        let masked = (clientSec?.isEmpty == false) ? "<present>" : "<none>"
        print("[Auth] ROPC config → url=\(tokenURL), clientId=\(clientId), secret=\(masked), scope=\(scope)")

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard (200...299).contains(http.statusCode) else {
            let snippet = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "Auth", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "Login failed (\(http.statusCode))\n\(snippet)"])
        }
        let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        guard let token = obj?["access_token"] as? String ?? obj?["access_token"] as? String, !token.isEmpty else {
            throw NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Missing access_token in response"])
        }
        return token
    }

    /// Salva SEMPRE le credenziali (Keychain + Defaults)
    private func persistCredentialsAlways(usernameBase: String, password: String) {
        let u = usernameBase.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !u.isEmpty, !password.isEmpty else { return }
        KeychainHelper.saveCredentials(usernameBase: u, password: password)
        UserDefaults.standard.set(u, forKey: "laba.username")
        UserDefaults.standard.set(password, forKey: "laba.password")
        UserDefaults.standard.set(true, forKey: "laba.savedCredentials")
        print("[Auth] Credentials persisted (Keychain + Defaults)")
    }

    /// Login interattivo UNIFICATO: stesso endpoint del silent, salva sempre le credenziali, aggiorna il token.
    @MainActor
    func interactiveLogin(usernameBase: String, password: String) async throws {
        let username = normalizeUsername(usernameBase)
        let token = try await Self.passwordLogin(username: username, password: password)
        self.accessToken = token
        persistCredentialsAlways(usernameBase: usernameBase, password: password)
        // diagnostica successo
        UserDefaults.standard.set(0, forKey: "laba.auth.failCount")
        UserDefaults.standard.removeObject(forKey: "laba.auth.backoffUntil")
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastSuccessAt")
        UserDefaults.standard.set(self.tokenPrefix, forKey: "laba.auth.lastSuccessPrefix")
        NotificationCenter.default.post(name: .authTokenDidChange, object: nil)
        NotificationCenter.default.post(name: .shouldReloadAfterAuth, object: nil)
        print("[Auth] Interactive login OK → prefix=\(self.tokenPrefix)")
    }

    /// Pulisce tutte le credenziali salvate (logout hard)
    func clearSavedCredentials() {
        KeychainHelper.deleteCredentials()
        UserDefaults.standard.removeObject(forKey: "laba.username")
        UserDefaults.standard.removeObject(forKey: "laba.password")
        UserDefaults.standard.removeObject(forKey: "laba.savedCredentials")
        print("[Auth] Cleared saved credentials")
    }
}

// MARK: - Token usability helpers and forced logout
extension SessionVM {
    /// Token immediatamente utilizzabile (non vuoto e non scaduto)
    var tokenIsUsableNow: Bool {
        guard !accessToken.isEmpty else { return false }
        return (tokenSecondsRemaining ?? -1) > 0
    }

    /// Può tentare un refresh silenzioso? (solo se credenziali Keychain presenti)
    var canAttemptSilentRefresh: Bool {
        return KeychainHelper.loadCredentials() != nil
    }

    /// Se il token è scaduto e non posso fare silent refresh → forza logout
    @MainActor
    func forceLogoutIfExpired() async {
        let remaining = tokenSecondsRemaining ?? -1
        if remaining <= 0 && !canAttemptSilentRefresh {
            print("[Auth] Force logout: expired token & no silent refresh allowed")
            // Svuotare il token è sufficiente per considerare l'utente non loggato
            accessToken = ""
            // (opzionale) pulizia dati volatili per evitare UI "zombie"
            // esami = []
            // corsi = []
            // seminars = []
            NotificationCenter.default.post(name: .authTokenDidChange, object: nil)
        }
    }
}

// MARK: - AppDelegate (Firebase init only)
final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate, MessagingDelegate {
    private let pendingPushStorageKey = "laba.pendingPush.userInfo"

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        // Firebase
        FirebaseApp.configure()

        // Delegati notifiche & FCM
        UNUserNotificationCenter.current().delegate = self

        // Se l'app viene aperta toccando una notifica (da terminata), persiste il payload
        if let remote = launchOptions?[.remoteNotification] as? [AnyHashable: Any],
           let data = try? JSONSerialization.data(withJSONObject: remote, options: []) {
            UserDefaults.standard.set(data, forKey: pendingPushStorageKey)
        }

        Messaging.messaging().isAutoInitEnabled = true
        Messaging.messaging().delegate = self

        // Ensure we have APNs permission & registration early
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, _ in
            if granted {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            } else {
                print("[FCM] notifications permission not granted — skipping APNs registration")
            }
        }

        
        return true
    }

    // App in foreground: mostra banner/audio e inoltra il payload all’inbox
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        NotificationCenter.default.post(name: .labaDidReceiveRemoteNotification,
                                        object: nil,
                                        userInfo: userInfo)
        if let data = try? JSONSerialization.data(withJSONObject: userInfo, options: []) {
            UserDefaults.standard.set(data, forKey: pendingPushStorageKey)
        }
        completionHandler([.banner, .list, .sound, .badge])
    }

    // Tap su notifica (anche da freddo)
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        NotificationCenter.default.post(name: .labaDidReceiveRemoteNotification,
                                        object: nil,
                                        userInfo: userInfo)
        if let data = try? JSONSerialization.data(withJSONObject: userInfo, options: []) {
            UserDefaults.standard.set(data, forKey: pendingPushStorageKey)
        }
        completionHandler()
    }

    // Ricevi/aggiorna token FCM
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("📲 FCM Token (delegate):", fcmToken ?? "nil")
        // Non applicare i topic finché non abbiamo un APNs token
        #if canImport(FirebaseMessaging)
        if Messaging.messaging().apnsToken == nil {
            print("[FCM] defer topics: waiting for APNs token…")
            return
        }
        #endif
        if let _ = fcmToken {
            NotificationCenter.default.post(name: .labaFCMTokenReady, object: nil)
        }
    }

    // Passa il token APNs a Firebase e ritenta il fetch del token FCM
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // 1) Salva il token APNs in Firebase Messaging
        Messaging.messaging().apnsToken = deviceToken

        // 2) Log utile per debug
        let apnsHex = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        print("📩 APNs Token:", apnsHex)

        // 3) Re-fetch del token FCM ora che l'APNs è disponibile
        Messaging.messaging().token { token, error in
            if let error = error {
                print("❌ FCM token error (post-APNs):", error.localizedDescription)
            } else if let token = token {
                print("📲 FCM Token (post-APNs):", token)
                // Il token è pronto: lasciamo che TopicAssegnato.update gestisca tutte le sottoscrizioni (incluso "tutti")
                NotificationCenter.default.post(name: .labaFCMTokenReady, object: nil)
            }
        }
    }

    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("❌ Errore registrazione APNs:", error.localizedDescription)
    }
}

// MARK: - Main App entry (moved here)
@main
struct LABAv2App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var inbox = NotificationInboxStore()
    init() {
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

fileprivate func applyFCMTopicsIfReady(using vm: SessionVM) {
    #if canImport(FirebaseMessaging)
    // Serve APNs token + FCM token per poter sottoscrivere
    guard Messaging.messaging().apnsToken != nil,
          let fcm = Messaging.messaging().fcmToken, !fcm.isEmpty else {
        print("[FCM] defer topics: waiting APNs/FCM…")
        return
    }
    #endif

    // Serve un token app valido (per coerenza col ciclo di vita login)
    guard vm.tokenIsUsableNow else {
        print("[FCM] defer topics: app token not usable yet")
        return
    }

    // Almeno uno tra corso/anno deve essere noto, altrimenti finiremmo sempre su solo "tutti"
    let hasCourseOrYear = (vm.pianoStudi?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false) || (vm.currentYear != nil)
    guard hasCourseOrYear else {
        print("[FCM] defer topics: waiting course/year…")
        return
    }

    let isGrad = (vm.status ?? "").localizedCaseInsensitiveContains("laureat")
    print("[FCM] applyFCMTopics – corso=\(vm.pianoStudi ?? "nil"), anno=\(vm.currentYear?.description ?? "nil"), grad=\(isGrad)")

    TopicAssegnato.update(
        pianoStudi: vm.pianoStudi,
        annoCorrente: vm.currentYear,
        isGraduated: isGrad
    )
}

extension LessonCalendarStore {
    @discardableResult
    func syncFromURL(_ url: URL, force: Bool) async -> Bool {
        do {
            let (data, resp) = try await URLSession.shared.data(from: url)
            guard (resp as? HTTPURLResponse)?.statusCode == 200 else { return false }
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let events = try decoder.decode([LessonEvent].self, from: data)
            await MainActor.run {
                self.events = events
                self.saveCache()
            }
            print("[Calendar] npoint sync OK – events=\(events.count)")
            return true
        } catch {
            print("[Calendar] npoint sync error:", error.localizedDescription)
            return false
        }
    }
}

extension LessonCalendarStore {
    /// Persist the current events to a small JSON cache in the Caches directory.
    func saveCache() {
        #if DEBUG
        // Keep cache operations quiet in release; logs only in debug
        #endif
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        do {
            let data = try encoder.encode(self.events)
            let url = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
                .appendingPathComponent("lesson_calendar_cache.json", isDirectory: false)
            try data.write(to: url, options: .atomic)
        } catch {
            print("[Calendar] cache save error:", error.localizedDescription)
        }
    }
}

// MARK: - FCM Topic manager (integrated from TopicAssegnato.swift)
public enum TopicAssegnato {
    // Persistenza unica (non per-utente): manteniamo solo l'insieme corrente
    private static let savedKey = "laba.fcm.topics"
    private static let savedTokenKey = "laba.fcm.topics.lastFCMToken"

    // MARK: Public API
    /// Aggiorna le sottoscrizioni in base ai dati correnti
    public static func update(pianoStudi: String?, annoCorrente: Int?, isGraduated: Bool) {
        let desired = desiredTopics(pianoStudi: pianoStudi, annoCorrente: annoCorrente, isGraduated: isGraduated)

        // Se il token FCM è cambiato (o non è mai stato salvato), forziamo la ri-sottoscrizione completa.
        #if canImport(FirebaseMessaging)
        let currentToken = Messaging.messaging().fcmToken
        #else
        let currentToken: String? = nil
        #endif

        let previousToken = UserDefaults.standard.string(forKey: savedTokenKey)
        let forceResub = {
            guard let t = currentToken, !t.isEmpty else { return true } // senza token → riprova
            // Forza resub anche se non abbiamo ancora uno snapshot di topic salvato
            return previousToken != t || savedTopics().isEmpty
        }()

        applyDiff(desired: desired, forceResubscribe: forceResub)

        // Persistiamo solo se abbiamo un token valido
        if let t = currentToken, !t.isEmpty {
            persist(desired)
            UserDefaults.standard.set(t, forKey: savedTokenKey)
        } else {
            print("[FCM] token mancante: non persisto lo snapshot dei topic (ritenterò al prossimo token ready)")
        }

        print("[FCM] desired topics:", desired.sorted())
    }

    /// Pulisce tutte le sottoscrizioni correnti (da chiamare al logout)
    public static func clearAll() {
        let cur = savedTopics()
        #if canImport(FirebaseMessaging)
        let messaging = Messaging.messaging()
        for t in cur {
            messaging.unsubscribe(fromTopic: t) { err in
                if let err { print("[FCM] unsubscribe \(t) error=\(err.localizedDescription)") }
                else { print("[FCM] unsubscribed \(t)") }
            }
        }
        #else
        print("[FCM] (stub) would clear topics: \(cur)")
        #endif
        persist([])
        UserDefaults.standard.removeObject(forKey: savedTokenKey)
    }

    // MARK: Core
    private static func desiredTopics(pianoStudi: String?, annoCorrente: Int?, isGraduated: Bool) -> Set<String> {
        var out: Set<String> = ["tutti"]
        let indirizzo = indirizzoCode(from: pianoStudi)
        if let indirizzo { out.insert(indirizzo) }

        // Clamping anni: trienni 1..3, bienni 1..2
        if let indirizzo, let yRaw = annoCorrente {
            let y = clampYear(yRaw, for: indirizzo)
            out.insert("anno_\(y)")
            out.insert("\(y)anno_\(indirizzo)")
        } else if let y = annoCorrente {
            out.insert("anno_\(y)")
        }

        if annoCorrente == nil && !isGraduated, let indirizzo {
            out.insert("fuoricorso_\(indirizzo)")
        }
        return out
    }

    /// Mappa piano studi -> sigla corso (trienni+bienni)
    private static func indirizzoCode(from piano: String?) -> String? {
        guard let raw = piano, !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let ps = raw.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        // Bienni (2 anni)
        if ps.contains("interior") { return "INT" }
        if ps.contains("cinema") || ps.contains("audiovisiv") { return "CINEMA" }
        // Trienni (3 anni)
        if ps.contains("graphic") || ps.contains("multimedia") || ps.contains("grafica") { return "GD" }
        if ps.contains("fotografia") || ps.contains("photo") { return "FOTO" }
        if ps.contains("fashion") { return "FD" }
        if ps.contains("pittura") || ps.contains("painting") { return "PIT" }
        if ps.contains("regia") || ps.contains("videomaking") || ps.contains("regia e video") { return "REGIA" }
        if ps.contains("design") { return "DES" } // generico, dopo Interior
        return nil
    }

    /// Forza gli anni validi: trienni 1..3, bienni 1..2
    private static func clampYear(_ year: Int, for indirizzo: String) -> Int {
        switch indirizzo {
        case "INT", "CINEMA": return max(1, min(2, year))
        default: return max(1, min(3, year))
        }
    }

    // MARK: Subscribe/Unsubscribe con diff
    private static func applyDiff(desired: Set<String>, forceResubscribe: Bool) {
        let current = forceResubscribe ? Set<String>() : savedTopics()
        let toAdd = desired.subtracting(current)
        let toRemove = current.subtracting(desired)
        #if canImport(FirebaseMessaging)
        let messaging = Messaging.messaging()
        for t in toRemove { messaging.unsubscribe(fromTopic: t) { err in
            if let err { print("[FCM] unsubscribe \(t) error=\(err.localizedDescription)") } else { print("[FCM] unsubscribed \(t)") }
        }}
        for t in toAdd { messaging.subscribe(toTopic: t) { err in
            if let err { print("[FCM] subscribe \(t) error=\(err.localizedDescription)") } else { print("[FCM] subscribed \(t)") }
        }}
        #else
        print("[FCM] (stub) would subscribe: \(toAdd), unsubscribe: \(toRemove)")
        #endif
    }

    private static func savedTopics() -> Set<String> {
        let arr = UserDefaults.standard.array(forKey: savedKey) as? [String] ?? []
        return Set(arr)
    }
    private static func persist(_ topics: Set<String>) {
        UserDefaults.standard.set(Array(topics), forKey: savedKey)
    }
}

// MARK: - Grade Trend View (Andamento voti)

struct GradeTrendView: View {
    @EnvironmentObject var vm: SessionVM
    @Environment(\.colorScheme) private var scheme
    @State private var selectedIndex: Int? = nil // indice selezionato
    @State private var isTracking: Bool = false  // attiva overlay solo dopo long‑press
    @Environment(\.dismiss) private var dismiss
    @State private var chartKey = UUID()
    @State private var showKPIInfo = false
    @State private var showLodiInfo = false
    @State private var sortAscending = false
    @State private var kpiSheetDetent: CGFloat = 320
    @State private var lodiSheetDetent: CGFloat = 360


    private struct Exam: Identifiable { let id: Int; let idx: Int; let date: Date; let title: String; let grade: Int }
    private struct AvgPoint: Identifiable { let id: Int; let idx: Int; let date: Date; let avg: Double }
    private struct SheetHeightKey: PreferenceKey {
        static var defaultValue: CGFloat = 0
        static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
            value = max(value, nextValue())
        }
    }

    // Tutti gli esami (solo con voto numerico), in ordine cronologico — ESCLUDE TESI / PROVA FINALE / ELABORATO FINALE e ATTIVITÀ INTEGRATIVE
    private var exams: [Exam] {
        let raw = vm.esami.compactMap { e -> (Date, String, Int)? in
            // Escludi tesi & affini + attività integrative
            let titleNorm = e.corso.folding(options: .diacriticInsensitive, locale: .current).lowercased()
            if titleNorm.contains("tesi") || titleNorm.contains("prova finale") || titleNorm.contains("elaborato finale") || titleNorm.contains("attivit") {
                return nil
            }
            // Solo voti numerici validi (parseVote scarta idoneità)
            guard let d = e.sostenutoIl, let v = parseVote(e.voto) else { return nil }
            return (d, e.corso, v)
        }.sorted { $0.0 < $1.0 }
        return raw.enumerated().map { i, t in Exam(id: i, idx: i, date: t.0, title: prettifyTitle(t.1), grade: t.2) }
    }

    // Punti media cumulativa
    private var avgPoints: [AvgPoint] {
        var out: [AvgPoint] = []; var sum = 0
        for (i, ex) in exams.enumerated() { sum += ex.grade; out.append(.init(id: i, idx: i, date: ex.date, avg: Double(sum) / Double(i+1))) }
        return out
    }

    // STATISTICHE
    private var currentAvg: Double? { avgPoints.last?.avg }
    private var deltaAvg: Double { guard avgPoints.count >= 2 else { return 0 }; return avgPoints.last!.avg - avgPoints[avgPoints.count - 2].avg }
    private var best: Exam? { exams.max(by: { $0.grade < $1.grade }) }
    private var worst: Exam? { exams.min(by: { $0.grade < $1.grade }) }
    private var totalEligibleExams: Int {
        vm.esami.filter { e in
            let title = e.corso.lowercased()
            if title.contains("attivit") { return false }   // esclude attività integrative
            if title.contains("tesi") { return false }      // esclude tesi
            let vote = (e.voto ?? "").lowercased()
            if vote.contains("idone") { return false }      // esclude idoneità
            return true
        }.count
    }

    private var lodiCount: Int {
        vm.esami.filter { e in
            let title = e.corso.lowercased()
            if title.contains("attivit") { return false }
            if title.contains("tesi") { return false }
            let vote = (e.voto ?? "").lowercased()
            if vote.contains("idone") { return false }
            return vote.contains("lode")
        }.count
    }

    var body: some View {
        let accent = Color.labaAccent
        ScrollView(.vertical, showsIndicators: true) { // fa scorrere tutta la vista
            VStack(alignment: .leading, spacing: 14) {

                // KPI (più gerarchia + 2 pillole)
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    // Media attuale (grande) + doppia pillola sotto
                    VStack(alignment: .leading, spacing: 8) {
                        Text(currentAvg.map { String(format: "%.2f", $0) } ?? "—")
                            .font(.system(size: 40, weight: .bold, design: .rounded))
                            .monospacedDigit()
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                        // Pill: Media su N esami
                        HStack(spacing: 4) {
                            Text("Media su").font(.caption).foregroundStyle(.secondary)
                            Text("\(exams.count)").font(.caption.weight(.semibold))
                            Text(exams.count == 1 ? "esame" : "esami").font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 6)
                        .padding(.horizontal, 10)
                        .background(Capsule().fill(Color(uiColor: .tertiarySystemBackground)))
                        .overlay(Capsule().stroke(Color.primary.opacity(0.06), lineWidth: 1))
                    }

                    Spacer(minLength: 8)

                    // Delta + pillola "Δ con ultimo esame"
                    VStack(alignment: .trailing, spacing: 8) {
                        let up = deltaAvg >= 0
                        Text(String(format: "%@%.2f", up ? "+" : "", deltaAvg))
                            .foregroundStyle(up ? Color.green : Color.red)
                            .monospacedDigit()
                            .font(.system(size: 40, weight: .bold, design: .rounded))
                            // Arrow to the left, without influencing baseline/alignment
                            .overlay(alignment: .leading) {
                                Image(systemName: up ? "arrow.up.right" : "arrow.down.right")
                                    .foregroundStyle(up ? Color.green : Color.red)
                                    .offset(x: -22, y: 2)
                            }
                        // Status pill (without icon)
                        let d = deltaAvg
                        let statusText: String = d > 0.005 ? "In miglioramento" : (d < -0.005 ? "In peggioramento" : "Andamento stabile")
                        let tint: Color = d > 0 ? .green : (d < 0 ? .red : .secondary)
                        Text(statusText)
                            .font(.caption)
                            .foregroundStyle(tint)
                            .padding(.vertical, 6)
                            .padding(.horizontal, 10)
                            .background(Capsule().fill(tint.opacity(tint == .secondary ? 0.12 : 0.16)))
                            .overlay(Capsule().stroke((tint == .secondary ? Color.primary.opacity(0.06) : tint.opacity(0.25)), lineWidth: 1))
                    }
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color.cardBG))
                .padding(.horizontal)


                // Estremi data
                // (removed)

                // CHART
                if exams.isEmpty {
                    emptyChart
                        .padding(.horizontal)
                } else {
                    chartView(accent: accent)
                }

                // STAT GRID
                if !exams.isEmpty {
                    HStack(spacing: 12) {
                        stat("Sostenuti", "\(exams.count)")
                        stat("Migliore", best.map { "\($0.grade)/30" } ?? "—", tint: .green)
                        stat("Peggiore", worst.map { "\($0.grade)/30" } ?? "—", tint: .red)
                        stat("Lodi", "\(lodiCount)", tint: .orange, infoAction: { showLodiInfo = true })
                    }
                    .padding(.horizontal)
                }

                // Ultimi esami – card con fondo e separatori
                if !exams.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Ultimi esami").font(.headline)
                            Spacer()
                            Menu {
                                Button("Data crescente", action: { sortAscending = true })
                                Button("Data decrescente", action: { sortAscending = false })
                            } label: {
                                Label(sortAscending ? "Data ↑" : "Data ↓", systemImage: "arrow.up.arrow.down")
                                    .font(.caption)
                            }
                        }
                        let slice = Array(exams.suffix(10))
                        let display = sortAscending ? slice : slice.reversed()
                        VStack(spacing: 0) {
                            ForEach(Array(display.enumerated()), id: \.element.id) { index, e in
                                HStack(alignment: .firstTextBaseline, spacing: 12) {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(prettifyTitle(e.title))
                                            .font(.subheadline.weight(.semibold))
                                            .lineLimit(2)
                                        Text(dateMedium(e.date))
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text("\(e.grade)/30")
                                        .font(.subheadline.weight(.semibold))
                                        .padding(.vertical, 6)
                                        .padding(.horizontal, 10)
                                        .background(Capsule().fill(Color.labaAccent.opacity(0.15)))
                                        .overlay(Capsule().stroke(Color.labaAccent.opacity(0.25), lineWidth: 1))
                                }
                                .padding(.vertical, 8)
                                if index != display.count - 1 { Divider() }
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(Color(uiColor: scheme == .dark ? .secondarySystemBackground : .systemBackground))
                        )
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.08), lineWidth: 0.8))
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 24)
                }
                // Footer: link alla sezione Esami (testo centrato a sé stante)
                if !exams.isEmpty {
                    NavigationLink {
                        ExamsView().environmentObject(vm)
                    } label: {
                        HStack(spacing: 6) {
                            Text("Per la lista completa vai alla sezione")
                                .font(.footnote)
                            Text("Esami")
                                .font(.footnote.weight(.semibold))
                            Image(systemName: "chevron.right")
                                .font(.footnote.weight(.bold))
                        }
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal)
                    .padding(.bottom, 24)
                }
            }
        }
        .scrollBounceBehavior(.basedOnSize, axes: .vertical)
        .scrollDisabled(isTracking)
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("Andamento voti")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showKPIInfo = true
                } label: {
                    Image(systemName: "info.circle")
                }
            }
        }
        .sheet(isPresented: $showKPIInfo) {
            let prev = avgPoints.count >= 2 ? avgPoints[avgPoints.count-2].avg : (avgPoints.last?.avg ?? 0)
            let curr = avgPoints.last?.avg ?? 0
            let delta = curr - prev
            let status = delta > 0.005 ? "Andamento positivo" : (delta < -0.005 ? "Andamento negativo" : "Andamento stabile")
            let maxH = CGFloat(UIScreen.main.bounds.height) * 0.9
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text(status)
                        .font(.headline)
                        .foregroundStyle(delta > 0 ? Color.green : (delta < 0 ? Color.red : .secondary))
                    Divider()
                    Text("Cos'è questo numero").font(.subheadline.weight(.semibold))
                    Text("Indica **di quanto è cambiata la tua media** con l'**ultimo esame**.")
                    Text("• Se è **positivo** (es. +0,13) l'ultimo esame ha **alzato** la media.\n• Se è **negativo** (es. −0,13) l'ultimo esame l'ha **abbassata**.\n• Se è **≈ 0** la media è **rimasta stabile**.")
                    Text("Esempio").font(.subheadline.weight(.semibold)).padding(.top, 4)
                    Text("Prima dell'ultimo esame: \(String(format: "%.2f", prev))\nDopo l'ultimo esame: \(String(format: "%.2f", curr))\n**Δ = \(delta >= 0 ? "+" : "")\(String(format: "%.2f", delta))**")
                        .monospacedDigit()
                }
                .padding(16)
                .background(GeometryReader { proxy in
                    Color.clear.preference(key: SheetHeightKey.self, value: proxy.size.height)
                })
            }
            .onPreferenceChange(SheetHeightKey.self) { h in
                kpiSheetDetent = min(h + 32, maxH)
            }
            .presentationDetents([.height(kpiSheetDetent), .large])
            .presentationDragIndicator(.visible)
            .presentationContentInteraction(.scrolls)
            .interactiveDismissDisabled(false)
        }
        .sheet(isPresented: $showLodiInfo) {
            let total = totalEligibleExams // totale massimo esami considerati (no idoneità/tesi/attività integrative)
            let needed = max(1, (total / 2) + 1)
            let have = lodiCount
            let missing = max(0, needed - have)
            let maxH = CGFloat(UIScreen.main.bounds.height) * 0.9
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Lodi e menzione accademica").font(.headline)
                    Divider()
                    Text("Hai **\(have)** lodi su **\(total)** esami considerati.")
                    Text("Per ambire alla *menzione accademica* servono **almeno \(needed) lodi** (metà degli esami + 1).")
                    ProgressView(value: Double(min(have, needed)), total: Double(needed)).tint(.orange)
                    HStack(spacing: 6) {
                        ForEach(0..<needed, id: \.self) { i in
                            Circle()
                                .fill(i < have ? Color.orange : Color.secondary.opacity(0.2))
                                .frame(width: 6, height: 6)
                        }
                        Spacer()
                        if missing > 0 {
                            Text("Ti mancano **\(missing)** lodi").foregroundStyle(.secondary)
                        } else {
                            Text("Obiettivo raggiunto: puoi ambire alla menzione accademica!").foregroundStyle(.green)
                        }
                    }
                    .font(.caption)
                    Text("Nota").font(.subheadline.weight(.semibold)).padding(.top, 4)
                    Text("La menzione **non è automatica**: oltre alle lodi, servono altri requisiti (tesi **sperimentale e ben documentata**, valutazioni eccellenti) e la **decisione unanime** della commissione di laurea.")
                }
                .padding(16)
                .background(GeometryReader { proxy in
                    Color.clear.preference(key: SheetHeightKey.self, value: proxy.size.height)
                })
            }
            .onPreferenceChange(SheetHeightKey.self) { h in
                lodiSheetDetent = min(h + 32, maxH)
            }
            .presentationDetents([.height(lodiSheetDetent), .large])
            .presentationDragIndicator(.visible)
            .presentationContentInteraction(.scrolls)
            .interactiveDismissDisabled(false)
        }
    }

// MARK: - Chart (più largo, più basso, tracking via long‑press)
@ViewBuilder private func chartView(accent: Color) -> some View {
    let count = exams.count
    VStack(alignment: .leading, spacing: 8) {
        hybridChart(accent: accent, points: avgPoints, count: count)
    }
    .padding(.vertical, 12)
    .frame(maxWidth: .infinity)
    .background(RoundedRectangle(cornerRadius: 16).fill(Color.cardBG))
    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.primary.opacity(0.06), lineWidth: 1))
    .padding(.horizontal) // stessa larghezza delle card sotto
    .id(chartKey)
}

@ViewBuilder private func hybridChart(accent: Color, points: [AvgPoint], count: Int) -> some View {
    GeometryReader { geo in
        let domainMin: Double = 18
        let domainMax: Double = 30
        let span = domainMax - domainMin
        let insetLeft: CGFloat = 44   // più respiro per asse Y e label
        let insetRight: CGFloat = 16  // margine destro più ampio
        let insetTop: CGFloat = 12    // respiro in alto
        let insetBottom: CGFloat = 14 // respiro in basso
        let n = min(points.count, exams.count)

        ZStack {
            // CANVAS: area + linea media + regole + Y axis
            Canvas { ctx, size in
                guard n > 0 else { return }
                let innerW = max(0, size.width - insetLeft - insetRight)
                let stepX = n > 1 ? (innerW / CGFloat(n - 1)) : 0

                func mapY(_ value: Double) -> CGFloat {
                    let h = size.height
                    let plotH = h - insetTop - insetBottom
                    let t = (value - domainMin) / span
                    return insetTop + (1 - CGFloat(t)) * plotH
                }
                func mapX(_ i: Int) -> CGFloat {
                    guard n > 1 else { return insetLeft + innerW / 2 }
                    return insetLeft + CGFloat(i) * stepX
                }

                // Regole orizzontali (solo griglia; le etichette Y sono renderizzate fuori dalla mask)
                let ticks: [Double] = [30, 27, 24, 18]
                for t in ticks {
                    let y = mapY(t)
                    var rule = Path()
                    rule.move(to: CGPoint(x: insetLeft, y: y))
                    rule.addLine(to: CGPoint(x: size.width - insetRight, y: y))
                    ctx.stroke(rule, with: .color(.secondary), style: StrokeStyle(lineWidth: 1, dash: [4,4]))
                }

                // Linea media + area
                var line = Path()
                var area = Path()
                line.move(to: CGPoint(x: mapX(0), y: mapY(points[0].avg)))
                for i in 1..<n {
                    line.addLine(to: CGPoint(x: mapX(i), y: mapY(points[i].avg)))
                }
                area.addPath(line)
                area.addLine(to: CGPoint(x: insetLeft + innerW, y: size.height - insetBottom))
                area.addLine(to: CGPoint(x: insetLeft, y: size.height - insetBottom))
                area.closeSubpath()

                ctx.fill(
                    area,
                    with: .linearGradient(
                        Gradient(colors: [accent.opacity(0.18), .clear]),
                        startPoint: CGPoint(x: 0, y: 0),
                        endPoint: CGPoint(x: 0, y: size.height)
                    )
                )
                ctx.stroke(line, with: .color(accent), lineWidth: 2.5)

                // Evidenzia selezione (regola verticale + punto sulla **media** + riga orizzontale + tick in basso)
                if let sel = selectedIndex, (0..<n).contains(sel) {
                    let px = mapX(sel)
                    let py = mapY(points[min(sel, n - 1)].avg) // allinea il punto alla linea della media

                    // Regola verticale
                    var vRule = Path()
                    vRule.move(to: CGPoint(x: px, y: insetTop))
                    vRule.addLine(to: CGPoint(x: px, y: size.height - insetBottom))
                    ctx.stroke(vRule, with: .color(.secondary), style: StrokeStyle(lineWidth: 1, dash: [3,3]))

                    // Riga orizzontale in corrispondenza della media selezionata
                    var hRule = Path()
                    hRule.move(to: CGPoint(x: insetLeft, y: py))
                    hRule.addLine(to: CGPoint(x: size.width - insetRight, y: py))
                    ctx.stroke(hRule, with: .color(.secondary), style: StrokeStyle(lineWidth: 1, dash: [3,3]))

                    // Tick in basso
                    var tick = Path()
                    tick.move(to: CGPoint(x: px, y: size.height - insetBottom))
                    tick.addLine(to: CGPoint(x: px, y: size.height - insetBottom - 6))
                    ctx.stroke(tick, with: .color(.secondary), lineWidth: 1)

                    // Punto evidenziato sulla linea della media
                    let big = Path(ellipseIn: CGRect(x: px - 5.5, y: py - 5.5, width: 11, height: 11))
                    ctx.stroke(big, with: .color(accent), lineWidth: 2)
                }
            }
            .mask(RoundedRectangle(cornerRadius: 16))
            // Etichette asse Y fuori dal Canvas (non clippate dalla mask)
            let yTicks = [30.0, 27.0, 24.0, 18.0]
            ForEach(yTicks, id: \.self) { t in
                let plotH = geo.size.height - insetTop - insetBottom
                let y = insetTop + (1 - CGFloat((t - domainMin) / span)) * plotH
                Text(String(format: "%.0f", t))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .position(x: 18, y: y)
                    .allowsHitTesting(false)
                    .zIndex(2)
            }
            Color.clear.frame(height: 0).allowsHitTesting(false)
            // SWIFTUI OVERLAY: callout "classica" sopra il punto
            if let sel = selectedIndex, n > 0 {
                let innerW = max(0, geo.size.width - insetLeft - insetRight)
                let step = n > 1 ? (innerW / CGFloat(n - 1)) : 0
                let px = insetLeft + CGFloat(max(0, min(n - 1, sel))) * step
                let ay: Double = points[min(sel, n - 1)].avg
                let plotH = geo.size.height - insetTop - insetBottom
                let py = insetTop + (1 - CGFloat((ay - domainMin) / span)) * plotH
                let maxW = min(260, geo.size.width - 24) // un po' più larga se serve
                let half = maxW / 2
                let cx = min(max(px, half + 12), geo.size.width - (half + 12))
                callout(for: sel)
                    .frame(maxWidth: maxW)
                    .fixedSize(horizontal: false, vertical: true)
                    .position(x: cx, y: max(12, py - 18))
                    .zIndex(5)
                    .allowsHitTesting(false)
            }
        }
        // GESTURE: long‑press (short) → then drag; scroll stays active when not tracking
        .contentShape(Rectangle())
        .onLongPressGesture(minimumDuration: 0.15, maximumDistance: 20, perform: {}, onPressingChanged: { pressing in
            isTracking = pressing
            if !pressing { selectedIndex = nil }
        })
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    guard isTracking else { return }
                    let innerW = max(0, geo.size.width - insetLeft - insetRight)
                    guard n > 0, innerW > 0 else { selectedIndex = 0; return }
                    let relX = max(0, min(innerW, value.location.x - insetLeft))
                    let denom = max(n - 1, 1)
                    let idx = Int(round(relX / (innerW / CGFloat(denom))))
                    selectedIndex = max(0, min(n - 1, idx))
                }
                .onEnded { _ in
                    isTracking = false
                    selectedIndex = nil
                }
        )
    }
    .frame(height: 180)
}

@ViewBuilder private func gradesChart(accent: Color, count: Int) -> some View { EmptyView() }

    @ViewBuilder private var emptyChart: some View {
        if #available(iOS 17.0, *) {
            ContentUnavailableView("Nessun voto disponibile", systemImage: "chart.line.uptrend.xyaxis", description: Text("Quando avrai esami con voto registrato, vedrai qui l'andamento."))
                .frame(height: 180)
        } else {
            VStack(spacing: 8) {
                Image(systemName: "chart.line.uptrend.xyaxis").font(.largeTitle).foregroundStyle(.secondary)
                Text("Nessun voto disponibile").font(.headline)
                Text("Quando avrai esami con voto registrato, vedrai qui l'andamento.").font(.footnote).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 24)
        }
    }

    // MARK: - Callout
    @ViewBuilder private func callout(for idx: Int) -> some View {
        let e = exams[min(idx, exams.count-1)]
        VStack(alignment: .leading, spacing: 4) {
            Text(prettifyTitle(e.title)).font(.caption.weight(.semibold)).lineLimit(2)
            Text("\(dateMedium(e.date)) – \(e.grade)/30").font(.caption2).foregroundStyle(.secondary)
            if idx < avgPoints.count {
                Text("Media: \(String(format: "%.2f", avgPoints[idx].avg))").font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding(8)
        .background(RoundedRectangle(cornerRadius: 8).fill(.background).shadow(radius: 3))
    }

    // Helpers
    private func parseVote(_ voto: String?) -> Int? {
        guard var s = voto?.lowercased() else { return nil }
        if s.contains("idoneo") || s.contains("idonea") || s.contains("idoneità") { return nil }
        if s.contains("lode") { return 30 }
        let digits = s.compactMap { $0.isNumber ? $0 : nil }
        if let n = Int(String(digits)), (18...30).contains(n) { return n }
        s = s.replacingOccurrences(of: " ", with: "")
        if let first = s.split(separator: "/").first, let n = Int(first), (18...30).contains(n) { return n }
        return nil
    }

    private func dateShort(_ d: Date) -> String { let f = DateFormatter(); f.dateStyle = .short; f.timeStyle = .none; return f.string(from: d) }
    private func dateMedium(_ d: Date) -> String { let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .none; f.locale = Locale(identifier: "it_IT"); return f.string(from: d) }

    @ViewBuilder private func pill(_ title: String, _ value: String) -> some View {
        let norm = title.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        if norm.contains("mancanti") {
            // estrai numero dalla stringa (es. "0", "\(count)")
            let digits = value.filter { $0.isNumber }
            let n = Int(digits) ?? 0
            mancantiPill(count: n)
        } else {
            HStack(spacing: 6) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.caption.weight(.semibold))
            }
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(Capsule().fill(Color.cardBG))
        }
    }

    // Pillola "Mancanti" con fallback a "Completati"
    @ViewBuilder private func mancantiPill(count: Int) -> some View {
        if count == 0 {
            HStack(spacing: 6) {
                Image(systemName: "checkmark.seal")
                    .imageScale(.small)
                    .foregroundStyle(.secondary)
                Text("Completati")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(Capsule().fill(Color(uiColor: .tertiarySystemBackground)))
            .overlay(Capsule().stroke(Color.primary.opacity(0.06), lineWidth: 1))
        } else {
            HStack(spacing: 4) {
                Text("Mancanti").font(.caption).foregroundStyle(.secondary)
                Text("\(count)").font(.caption.weight(.semibold))
            }
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(Capsule().fill(Color(uiColor: .tertiarySystemBackground)))
            .overlay(Capsule().stroke(Color.primary.opacity(0.06), lineWidth: 1))
        }
    }

    @ViewBuilder private func mancantiPill<S: StringProtocol>(countString: S) -> some View {
        let n = Int(countString) ?? 0
        mancantiPill(count: n)
    }

    @ViewBuilder private func stat(_ title: String, _ value: String, tint: Color? = nil, infoAction: (() -> Void)? = nil) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.callout.weight(.semibold))
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color(uiColor: scheme == .dark ? .secondarySystemBackground : .systemBackground))
                if let t = tint {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(t.opacity(scheme == .dark ? 0.16 : 0.08))
                }
            }
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(
                    (tint?.opacity(scheme == .dark ? 0.35 : 0.25)) ?? Color.primary.opacity(0.12),
                    lineWidth: 1
                )
        )
        .overlay(alignment: .topTrailing) {
            if let infoAction {
                Button(action: infoAction) {
                    Image(systemName: "info.circle").font(.caption).foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .padding(6)
            }
        }
    }

    private var csvString: String {
        var rows: [String] = ["index,date,grade,avg"]
        let avgs = avgPoints
        for i in 0..<exams.count {
            let e = exams[i]
            let a = i < avgs.count ? avgs[i].avg : Double(e.grade)
            rows.append("\(i),\(dateShort(e.date)),\(e.grade),\(String(format: "%.2f", a))")
        }
        return rows.joined(separator: "\n")
    }
}

// MARK: - Root

struct ContentView: View {
    @StateObject private var vm = SessionVM()
    @State private var selectedTab = 0
    @State private var isBooting = true
    @State private var isRefreshing: Bool = false
    @StateObject private var inbox = NotificationInboxStore()
    @StateObject private var calendarStore = LessonCalendarStore()
    @Environment(\.scenePhase) private var scenePhase

    @AppStorage("laba.theme") private var themePreference: String = "system"
    @Environment(\.colorScheme) private var colorScheme
    private let pendingPushStorageKey = "laba.pendingPush.userInfo"
    // Silent refresh diagnostic state
    @State private var silentRefreshFailCount = 0
    @State private var lastRefreshAttemptPrefix: String? = nil
    @State private var refreshBackoffUntil: Date? = nil
    @State private var reloadBump: Int = 0
    // Prevent concurrent reloads of datasets
    @State private var isReloadingDatasets: Bool = false
    // Debounce for dataset reloads
    @State private var lastDataLoadAt: Date? = nil

    // MARK: - Watch snapshot helpers

    // Estrae il campo "messaggio" (o equivalenti)
    private func notificationMessage<T>(_ n: T) -> String? {
        let prefer = ["messaggio", "message", "body", "text", "descrizione", "description"]
        let mirror = Mirror(reflecting: n)
        // livello 1
        for child in mirror.children {
            guard let label = child.label?.lowercased() else { continue }
            if prefer.contains(label), let s = child.value as? String {
                let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                if !t.isEmpty { return t }
            }
        }
        // livello 2 (es. payload/dto annidati)
        for child in mirror.children {
            let subMirror = Mirror(reflecting: child.value)
            for sub in subMirror.children {
                guard let label = sub.label?.lowercased() else { continue }
                if prefer.contains(label), let s = sub.value as? String {
                    let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { return t }
                }
            }
        }
        return nil
    }

    // Riformatta il messaggio per la preview in Home
    private func reformatMessaggioHome(_ s: String) -> String {
        let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let norm = trimmed.folding(options: String.CompareOptions.diacriticInsensitive, locale: Locale.current).lowercased()
        if norm.contains("dispensa") {
            // Esempio origine: "Dispensa di STORIA DELL'ARTE CONTEMPORANEA inserita"
            if let rx = try? NSRegularExpression(pattern: "(?i)dispensa\\s+di\\s+(.+?)\\s+inserita"),
               let m = rx.firstMatch(in: trimmed, range: NSRange(trimmed.startIndex..., in: trimmed)),
               let r1 = Range(m.range(at: 1), in: trimmed) {
                let materia = String(trimmed[r1]).trimmingCharacters(in: .whitespacesAndNewlines)
                return "Inserita dispensa di \(materia)"
            }
            return "Nuova dispensa inserita"
        }
        if norm.contains("programma") { return "Nuovo programma caricato" }
        return trimmed
    }
    private func isAttivitaIntegrativa(_ e: Esame) -> Bool { e.corso.lowercased().contains("attivit") }
    private func isTesiFinale(_ e: Esame) -> Bool { e.corso.lowercased().contains("tesi") }
    private func isCompleted(_ e: Esame) -> Bool { !(e.voto ?? "").isEmpty || (e.sostenutoIl != nil) }

    private func computeCFAEarned() -> Int {
        // 1) Esami (escludi Attività e Tesi)
        let examsEarned = vm.esami.reduce(0) { acc, e in
            guard !isAttivitaIntegrativa(e), !isTesiFinale(e) else { return acc }
            guard isCompleted(e), let c = Int(e.cfa ?? "") else { return acc }
            return acc + c
        }
        // 2) Attività integrative → max 10 CFA totali
        let attivita = vm.esami.filter { isAttivitaIntegrativa($0) }
        let declaredActivitiesCFA = attivita.compactMap { Int($0.cfa ?? "") }.reduce(0, +)
        let anyActivityCompleted = attivita.contains { isCompleted($0) }
        let activitiesEarned = anyActivityCompleted ? min(10, declaredActivitiesCFA) : 0
        // 3) Tesi finale
        let thesis = vm.esami.filter { isTesiFinale($0) }
        let thesisCFA = thesis.compactMap { Int($0.cfa ?? "") }.first ?? 0
        let thesisCompleted = thesis.contains { isCompleted($0) }
        let thesisEarned = thesisCompleted ? thesisCFA : 0
        return examsEarned + activitiesEarned + thesisEarned
    }

    private func examsPayload() -> [[String: String]] {
        vm.esami.map { e in
            let title = e.corso
            let gradeRaw = (e.voto ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return [
                "title": title,
                "grade": gradeRaw.isEmpty ? (isCompleted(e) ? "—" : "") : gradeRaw
            ]
        }
    }

    // Helper: coalesce dataset reloads (esami/corsi/seminari) — NO debounce
    private func performDataLoadIfNeeded(reason: String) async {
        // Gate contro doppioni (niente debounce)
        if isReloadingDatasets {
            print("[Reload] coalesced (already in progress, reason=\(reason))")
            return
        }
        guard vm.tokenIsUsableNow else {
            print("[Reload] skipped (token not usable yet, reason=\(reason))")
            return
        }

        isReloadingDatasets = true
        defer { isReloadingDatasets = false }

        print("[Reload] start (reason=\(reason)) → PARALLEL: esami + corsi + seminari (await all)")

        // Carica tutto in parallelo e aspetta tutto (comportamento istantaneo di prima)
        await withTaskGroup(of: Void.self) { group in
            group.addTask { await vm.loadEsami() }
            group.addTask { await vm.loadCorsi() }
            group.addTask { await vm.loadSeminari() }
            await group.waitForAll()
        }

        print("[Reload] done (reason=\(reason))")
    }

    var body: some View {
        ZStack {
            Group {
                if vm.isLoggedIn && vm.tokenIsUsableNow {
                    TabView(selection: $selectedTab) {
                        HomeView()
                            .task { await performDataLoadIfNeeded(reason: "home-appear") }
                            .tabItem { Label("Home", systemImage: "house.fill") }
                            .tag(0)
                            .environmentObject(vm)
                            .environmentObject(calendarStore)
                        ExamsView()
                            .task { await performDataLoadIfNeeded(reason: "exams-appear") }
                            .tabItem { Label("Esami", systemImage: "list.bullet.rectangle.fill") }
                            .badge(vm.bookableExamsCount > 0 ? "!" : nil)
                            .tag(1)
                            .environmentObject(vm)
                        CorsiView()
                            .task { await performDataLoadIfNeeded(reason: "corsi-appear") }
                            .tabItem { Label("Corsi", systemImage: "graduationcap.fill") }
                            .tag(2)
                            .environmentObject(vm)
                        SeminariView()
                            .task { await performDataLoadIfNeeded(reason: "seminari-appear") }
                            .tabItem { Label("Seminari", systemImage: "calendar.badge.clock") }
                            .badge(vm.bookableSeminarsCount)
                            .tag(3)
                            .environmentObject(vm)
                        ProfiloView()
                            .task { await performDataLoadIfNeeded(reason: "profilo-appear") }
                            .tabItem { Label("Profilo", systemImage: "person.crop.circle.fill") }
                            .tag(4)
                            .environmentObject(vm)
                            .environmentObject(inbox)
                    }
                    .tint(Color.labaAccent)
                    .accentColor(Color.labaAccent)
                } else {
                    LoginView().environmentObject(vm)
                }
            }

            // Overlay: priorità al refresh token rispetto alla splash
            if isRefreshing {
                RefreshTokenScreen()
                    .environmentObject(vm)
                    .transition(.opacity)
                    .zIndex(2)
            } else if isBooting {
                AppLoadingView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            // Se al cold start il token è assente o in scadenza immediata,
            // mostra direttamente la schermata di Refresh invece dello splash.
            let needAuthNow = vm.accessToken.isEmpty || ((vm.tokenSecondsRemaining ?? 0) < 15)
            print("[Auth] Cold start: needAuthNow=\(needAuthNow) prefix=\(vm.tokenPrefix) remaining=\(String(describing: vm.tokenSecondsRemaining))")
            if needAuthNow {
                await MainActor.run { isRefreshing = true }
            }

            await vm.restoreSessionStrong(force: needAuthNow)
            print("[Auth] Cold start restore done. prefix=\(vm.tokenPrefix) remaining=\(String(describing: vm.tokenSecondsRemaining))")
            await vm.forceLogoutIfExpired()

            // Track last restore attempt time for diagnostics
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastRestoreAt")

            // Dopo un (ri)login/refresh, ricarica i dati che non richiedono altri stati
            if vm.tokenIsUsableNow {
                await vm.loadNotifications()
                NotificationCenter.default.post(name: .shouldReloadAfterAuth, object: nil)
                print("[Auth] Cold start data load → esami/corsi/seminari")
                await performDataLoadIfNeeded(reason: "cold-start")
            }

            // Calendario lezioni: bundle → cache → sync remoto (npoint)
            calendarStore.loadFromBundle()
            calendarStore.loadCacheIfAvailable()
            let baseStr = (Bundle.main.object(forInfoDictionaryKey: "LABA_CALENDAR_BASE_URL") as? String) ??
                          "https://api.npoint.io/7ad5addbea4721f9483c"
            if let url = URL(string: baseStr) {
                _ = await calendarStore.syncFromURL(url, force: true)
            }

            if needAuthNow {
                await MainActor.run { isRefreshing = false }
            }
            withAnimation(.easeOut(duration: 0.25)) {
                isBooting = false
            }
            consumePendingPush()
        }
        .onReceive(NotificationCenter.default.publisher(for: .labaDidReceiveRemoteNotification)) { note in
            if let ui = note.userInfo {
                DispatchQueue.main.async {
                    inbox.add(from: ui)
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .shouldReloadAfterAuth)) { _ in
            // Bump a state counter to trigger a .task(id:) on the main actor.
            reloadBump &+= 1
        }
        
        .onReceive(NotificationCenter.default.publisher(for: .labaFCMTokenReady)) { _ in
            applyFCMTopicsIfReady(using: vm)
        }
        
        .task(id: reloadBump) {
            // Triggered after auth or explicit reloads
            await performDataLoadIfNeeded(reason: "reload-bump")
        }
        .task(id: selectedTab) {
            // Coalesced reload when the user switches tab (guarantees data after cold start)
            await performDataLoadIfNeeded(reason: "tab-change")
        }
        // Programma un refresh silenzioso poco prima della scadenza del token corrente, con backoff e diagnostica
        .task(id: vm.accessToken) {
            guard vm.canAttemptSilentRefresh else { return }
            // Evita di rieseguire per lo stesso token in loop
            let currentPrefix = vm.tokenPrefix
            lastRefreshAttemptPrefix = currentPrefix

            // Se ho un backoff attivo, aspetta che scada
            if let until = refreshBackoffUntil, until > Date() {
                let wait = until.timeIntervalSinceNow
                try? await Task.sleep(nanoseconds: UInt64(max(0, wait)) * 1_000_000_000)
            }

            guard let secs = vm.tokenSecondsRemaining, secs > 20 else { return }
            let lead = 300 // 5 minuti di anticipo: riduce i casi-limite al riavvio
            let wait = max(secs - lead, 1)
            try? await Task.sleep(nanoseconds: UInt64(wait) * 1_000_000_000)

            // Se nel frattempo il token è cambiato/già rinnovato, esci
            if vm.tokenPrefix != currentPrefix { return }
            // Record attempt metadata for diagnostics
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastAttemptAt")
            UserDefaults.standard.set(currentPrefix, forKey: "laba.auth.lastAttemptPrefix")

            await MainActor.run { isRefreshing = true }
            let before = vm.tokenPrefix
            await vm.restoreSessionStrong() // silent login tramite Keychain, se disponibile
            let after = vm.tokenPrefix
            await MainActor.run { isRefreshing = false }

            if after == before || (vm.tokenSecondsRemaining ?? 0) <= 15 {
                // Silent refresh NON riuscito: incrementa conteggio e applica backoff
                silentRefreshFailCount += 1
                let backoffSeconds = min(300, 30 * silentRefreshFailCount) // 30s, 60s, 90s… max 5min
                refreshBackoffUntil = Date().addingTimeInterval(TimeInterval(backoffSeconds))
                // Persist diagnostics so the UI can show them
                UserDefaults.standard.set(silentRefreshFailCount, forKey: "laba.auth.failCount")
                UserDefaults.standard.set(refreshBackoffUntil?.timeIntervalSince1970 ?? 0, forKey: "laba.auth.backoffUntil")
                print("[Auth] Silent refresh failed (attempt #\(silentRefreshFailCount)). Backing off \(backoffSeconds)s. Prefix=\(before)")
                // Se fallisce ripetutamente, passa a login interattivo
                if silentRefreshFailCount >= 2 {
                    print("[Auth] Escalate to interactive login after repeated failures")
                    await MainActor.run { isRefreshing = false }
                }
            } else {
                // Riuscito: reset contatori
                silentRefreshFailCount = 0
                refreshBackoffUntil = nil
                // Persist success diagnostics
                UserDefaults.standard.set(0, forKey: "laba.auth.failCount")
                UserDefaults.standard.removeObject(forKey: "laba.auth.backoffUntil")
                UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastSuccessAt")
                UserDefaults.standard.set(vm.tokenPrefix, forKey: "laba.auth.lastSuccessPrefix")
                print("[Auth] Silent refresh OK. New prefix=\(after)")
            }
            await vm.forceLogoutIfExpired()
        }
        // Nuovo trigger: quando torni in primo piano, se il token manca o è agli sgoccioli, rinnova in modo visibile
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                Task {
                    print("[Auth] Foreground active: prefix=\(vm.tokenPrefix) remaining=\(String(describing: vm.tokenSecondsRemaining))")
                    let remaining = vm.tokenSecondsRemaining ?? -1
                    if vm.accessToken.isEmpty || remaining < 15 {
                        print("[Auth] Foreground restore trigger (needAuthNow=true)")
                        await MainActor.run { isRefreshing = true }
                        await vm.restoreSessionStrong(force: true)
                        // Track foreground restore time
                        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastRestoreAt")
                        print("[Auth] Foreground restore done. Prefix=\(vm.tokenPrefix) exp=\(String(describing: vm.tokenExpiryDate)) remaining=\(String(describing: vm.tokenSecondsRemaining))")
                        await MainActor.run { isRefreshing = false }
                    }
                    await vm.forceLogoutIfExpired()
                    if vm.tokenIsUsableNow {
                        NotificationCenter.default.post(name: .shouldReloadAfterAuth, object: nil)
                        await vm.loadNotifications()
                        print("[Auth] Foreground data load → esami/corsi/seminari")
                        await performDataLoadIfNeeded(reason: "foreground")
                    }
                    // Aggiorna calendario da npoint quando rientri in primo piano
                    let baseStr = (Bundle.main.object(forInfoDictionaryKey: "LABA_CALENDAR_BASE_URL") as? String) ??
                                  "https://api.npoint.io/7ad5addbea4721f9483c"
                    if let url = URL(string: baseStr) {
                        _ = await calendarStore.syncFromURL(url, force: false)
                    }
                }
            }
        }
        .onChange(of: vm.accessToken) { _, _ in
            print("[Auth] accessToken changed → prefix=\(vm.tokenPrefix)")
            // Persist success diagnostics when token changes for any reason
            UserDefaults.standard.set(0, forKey: "laba.auth.failCount")
            UserDefaults.standard.removeObject(forKey: "laba.auth.backoffUntil")
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "laba.auth.lastSuccessAt")
            UserDefaults.standard.set(vm.tokenPrefix, forKey: "laba.auth.lastSuccessPrefix")
            // Garantisci che il Keychain sia sempre popolato dopo un login riuscito
            if KeychainHelper.loadCredentials() == nil {
                let ud = UserDefaults.standard
                if let u = ud.string(forKey: "laba.username"),
                   let p = ud.string(forKey: "laba.password"),
                   !u.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                   !p.isEmpty {
                    KeychainHelper.saveCredentials(usernameBase: u, password: p)
                    print("[Auth] Keychain repopulated from Defaults")
                }
            }
            // Il token è cambiato (login/refresh): reset diagnostica, riallinea e ricarica dati essenziali
            silentRefreshFailCount = 0
            refreshBackoffUntil = nil
            lastRefreshAttemptPrefix = nil
            NotificationCenter.default.post(name: .authTokenDidChange, object: nil)
            if vm.tokenIsUsableNow {
                NotificationCenter.default.post(name: .shouldReloadAfterAuth, object: nil)
                Task { await vm.loadNotifications() }
            }
        }
    
        .onChange(of: vm.pianoStudi) { _, _ in
            applyFCMTopicsIfReady(using: vm)
        }
        .onChange(of: vm.currentYear) { _, _ in
            applyFCMTopicsIfReady(using: vm)
        }
        .onChange(of: vm.status) { _, _ in
            applyFCMTopicsIfReady(using: vm)
        }
        .preferredColorScheme(preferredScheme(from: themePreference))
    }

    private func consumePendingPush() {
        guard let data = UserDefaults.standard.data(forKey: pendingPushStorageKey) else { return }
        // Rimuovi subito per evitare doppioni
        UserDefaults.standard.removeObject(forKey: pendingPushStorageKey)
        if let obj = try? JSONSerialization.jsonObject(with: data, options: []),
           let dict = obj as? [AnyHashable: Any] {
            DispatchQueue.main.async {
                inbox.add(from: dict)
            }
        }
    }
}



struct ContentView_Previews: PreviewProvider { static var previews: some View { ContentView() } }


// MARK: - PerTeSection (native List)
fileprivate struct PerTeSection: View {
    @EnvironmentObject var vm: SessionVM
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            List {
                Section(header:
                            HStack(spacing: 4) {
                    Image(systemName: "sparkles")
                    Text("Per te")
                }
                ) {
                    NavigationLink {
                        CalcolaMediaView().environmentObject(vm)
                    } label: {
                        Label("Voto di laurea", systemImage: "graduationcap.fill")
                    }
                    .disabled(false)
                    NavigationLink {
                        MediaSimulatorView().environmentObject(vm)
                    } label: {
                        Label("Simula la tua media", systemImage: "function")
                    }
                    Label("Strumentazione", systemImage: "camera.on.rectangle.fill")
                        .disabled(true)
                    Label("Aule", systemImage: "inset.filled.rectangle.and.person.filled")
                        .disabled(true)
                }
            }
            .listStyle(.insetGrouped)
            .scrollDisabled(true)
            .frame(height: 250)
        }
        .frame(maxWidth: .infinity)
        .background(Color.clear)
    }
}

struct ProgrammiView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var isLoading = false
    @State private var errorMessage: String? = nil
    @State private var docs: [LogosDoc] = []
    @State private var query: String = ""

    // MARK: - Models
    struct LogosDocumentsResponse: Decodable {
        struct Payload: Decodable {
            let pianoStudi: String?
            let documents: [LogosDoc]
        }
        let success: Bool
        let errors: [String]?
        let payload: Payload?
    }
    struct LogosDoc: Identifiable, Decodable, Hashable {
        let pianoStudiOid: String?
        let ordine: Int?
        let corso: String
        let descrizione: String?
        let tipo: String?
        let url: String?
        let allegatoOid: String
        var id: String { allegatoOid }
    }

    // MARK: - Helpers (Programmi only)
    private func isProgramDoc(_ d: LogosDoc) -> Bool {
        let hay = [d.tipo ?? "", d.descrizione ?? "", d.url ?? ""]
            .joined(separator: " ")
            .folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
        // match sia "program" che "programma"
        return hay.contains("programma") || hay.contains("program")
    }
    private var programDocs: [LogosDoc] { docs.filter { isProgramDoc($0) } }

    // MARK: - Filter & Group
    private var filtered: [LogosDoc] {
        let base = programDocs
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return base }
        let ql = q.lowercased()
        return base.filter { d in
            prettifyTitle(d.corso).lowercased().contains(ql)
            || (d.descrizione ?? "").lowercased().contains(ql)
            || (d.tipo ?? "").lowercased().contains(ql)
        }
    }
    private var grouped: [(course: String, items: [LogosDoc])] {
        let dict = Dictionary(grouping: filtered, by: { $0.corso })
        let keys = dict.keys.sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        return keys.map { k in
            let items = (dict[k] ?? []).sorted { a, b in
                let ao = a.ordine ?? 0, bo = b.ordine ?? 0
                if ao != bo { return ao < bo }
                let ad = (a.descrizione ?? ""), bd = (b.descrizione ?? "")
                return ad.localizedStandardCompare(bd) == .orderedAscending
            }
            return (k, items)
        }
    }

    // Lista piatta ordinata per materia (e poi per ordine)
    private var flatDocs: [LogosDoc] {
        programDocs.sorted { a, b in
            let ca = prettifyTitle(a.corso)
            let cb = prettifyTitle(b.corso)
            if ca != cb { return ca.localizedCaseInsensitiveCompare(cb) == .orderedAscending }
            let ao = a.ordine ?? 0
            let bo = b.ordine ?? 0
            return ao < bo
        }
    }

    // MARK: - Networking
    private func loadDocuments() async {
        await MainActor.run { isLoading = true; errorMessage = nil }
        guard let url = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Documents") else {
            await MainActor.run { errorMessage = "URL non valido"; isLoading = false }
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue("Bearer \(vm.accessToken)", forHTTPHeaderField: "Authorization")

        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                throw NSError(domain: "MaterialiView", code: http.statusCode)
            }
            let decoded = try JSONDecoder().decode(LogosDocumentsResponse.self, from: data)
            await MainActor.run {
                docs = decoded.payload?.documents ?? []
                isLoading = false
            }
        } catch {
            await MainActor.run { errorMessage = error.localizedDescription; isLoading = false }
        }
    }

    // MARK: - UI
    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Caricamento…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let err = errorMessage {
                    ContentUnavailableView("Impossibile caricare",
                                           systemImage: "doc.text.magnifyingglass",
                                           description: Text(err))
                } else if grouped.isEmpty {
                    ContentUnavailableView("Nessun programma",
                                           systemImage: "doc.text.magnifyingglass",
                                           description: Text("Quando disponibili, appariranno qui."))
                } else {
                    List {
                        Section {
                            VStack(spacing: 8) {
                                Image(systemName: "doc.text.fill")
                                    .font(.largeTitle)
                                    .foregroundStyle(.secondary)
                                Text("Programmi didattici")
                                    .font(.headline)
                                Text("Qui trovi i programmi dei corsi: obiettivi, contenuti, modalità d’esame e bibliografia. I documenti sono aggiornati dai docenti/Segreteria.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 6)
                        }
                        ForEach(flatDocs, id: \.id) { d in
                            NavigationLink {
                                MaterialiDocumentViewer(
                                    allegatoOid: d.allegatoOid,
                                    title: prettifyTitle(d.corso)
                                )
                            } label: {
                                Text(prettifyTitle(d.corso))
                                    .font(.body.weight(.semibold))
                                    .lineLimit(2)
                                    .padding(.vertical, 2)
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Programmi")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query,
                        placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Cerca programmi")
            .task { await loadDocuments() }
            .refreshable { await loadDocuments() }
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}

// Backwards-compat: old entry point now forwards to Programmi
struct MaterialiView: View {
    var body: some View { ProgrammiView() }
}

struct DispenseView: View {
    @EnvironmentObject var vm: SessionVM
    @State private var isLoading = false
    @State private var errorMessage: String? = nil
    @State private var docs: [ProgrammiView.LogosDoc] = []
    @State private var query: String = ""

    // MARK: - Helpers (Dispense only)
    private func isDispensaDoc(_ d: ProgrammiView.LogosDoc) -> Bool {
        let hay = [d.tipo ?? "", d.descrizione ?? "", d.url ?? ""]
            .joined(separator: " ")
            .folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
        // intercetta “dispensa/dispense/dispens” e possibili termini inglesi
        return hay.contains("dispens") || hay.contains("handout")
    }
    private var dispensaDocs: [ProgrammiView.LogosDoc] { docs.filter { isDispensaDoc($0) } }

    // MARK: - Filter & Group
    private var filtered: [ProgrammiView.LogosDoc] {
        let base = dispensaDocs
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return base }
        let ql = q.lowercased()
        return base.filter { d in
            prettifyTitle(d.corso).lowercased().contains(ql)
            || (d.descrizione ?? "").lowercased().contains(ql)
            || (d.tipo ?? "").lowercased().contains(ql)
        }
    }
    private var grouped: [(course: String, items: [ProgrammiView.LogosDoc])] {
        let dict = Dictionary(grouping: filtered, by: { $0.corso })
        let keys = dict.keys.sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
        return keys.map { k in
            let items = (dict[k] ?? []).sorted { a, b in
                let ao = a.ordine ?? 0, bo = b.ordine ?? 0
                if ao != bo { return ao < bo }
                let ad = (a.descrizione ?? ""), bd = (b.descrizione ?? "")
                return ad.localizedStandardCompare(bd) == .orderedAscending
            }
            return (k, items)
        }
    }
    
    // Normalizza il nome materia eliminando suffissi tipo "(GRAPHIC DESIGN)"
    private func materiaName(_ raw: String) -> String {
        var s = prettifyTitle(raw)
        // Rimuovi parentesi finali se SHOUTCASE o ridondanti rispetto al piano di studi
        if let r = s.range(of: "\\s*\\(([^)]+)\\)\\s*$", options: .regularExpression) {
            let innerWithParens = String(s[r]).trimmingCharacters(in: .whitespacesAndNewlines)
            let inner = String(innerWithParens.dropFirst().dropLast())
            let norm = inner.folding(options: .diacriticInsensitive, locale: .current)
            let letters = norm.filter { $0.isLetter }
            let isShout = !letters.isEmpty && letters.uppercased() == letters
            let piano = (vm.pianoStudi ?? "").folding(options: .diacriticInsensitive, locale: .current).lowercased()
            let innerLower = norm.lowercased()
            if isShout || (!piano.isEmpty && (piano.contains(innerLower) || innerLower.contains(piano))) {
                s.removeSubrange(r)
                s = s.trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        return s
    }

    // MARK: - Networking
    private func loadDocuments() async {
        await MainActor.run { isLoading = true; errorMessage = nil }
        guard let url = URL(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Documents") else {
            await MainActor.run { errorMessage = "URL non valido"; isLoading = false }
            return
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue("Bearer \(vm.accessToken)", forHTTPHeaderField: "Authorization")

        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                throw NSError(domain: "DispenseView", code: http.statusCode)
            }
            let decoded = try JSONDecoder().decode(ProgrammiView.LogosDocumentsResponse.self, from: data)
            await MainActor.run {
                docs = decoded.payload?.documents ?? []
                isLoading = false
            }
        } catch {
            await MainActor.run { errorMessage = error.localizedDescription; isLoading = false }
        }
    }

    // MARK: - UI
    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Caricamento…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let err = errorMessage {
                    ContentUnavailableView("Impossibile caricare",
                                           systemImage: "doc.text.magnifyingglass",
                                           description: Text(err))
                } else if grouped.isEmpty {
                    ContentUnavailableView("Nessuna dispensa",
                                           systemImage: "doc.text.magnifyingglass",
                                           description: Text("Quando disponibili, appariranno qui."))
                } else {
                    List {
                        Section {
                            VStack(spacing: 8) {
                                Image(systemName: "doc.on.doc.fill")
                                    .font(.largeTitle)
                                    .foregroundStyle(.secondary)
                                Text("Dispense e materiali")
                                    .font(.headline)
                                Text("Materiali caricati e condivisi dai docenti come PDF, slide o riferimenti didattici.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                HStack(alignment: .top, spacing: 8) {
                                    Image(systemName: "exclamationmark.triangle.fill").font(.footnote)
                                        .foregroundStyle(.orange)
                                    Text("Alcuni corsi usano piattaforme esterne, chiedi sempre conferma al docente (es. Google Drive, Classroom)")
                                        .font(.caption)
                                    .foregroundStyle(.orange, .secondary)                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 6)
                        }
                        ForEach(grouped, id: \.course) { group in
                            Section(header: Text(prettifyTitle(group.course))) {
                                ForEach(group.items, id: \.id) { d in
                                    NavigationLink {
                                        MaterialiDocumentViewer(
                                            allegatoOid: d.allegatoOid,
                                            title: (d.descrizione?.isEmpty == false ? d.descrizione! : (d.tipo ?? "Dispensa"))
                                        )
                                    } label: {
                                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                                            Text((d.descrizione?.isEmpty == false ? d.descrizione! : (d.tipo ?? "Dispensa")).capitalized)
                                                .font(.body.weight(.semibold))
                                                .lineLimit(2)
                                            Spacer(minLength: 6)
                                        }
                                        .padding(.vertical, 2)
                                    }
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Dispense e materiali")
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $query,
                        placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Cerca dispense")
            .task { await loadDocuments() }
            .refreshable { await loadDocuments() }
            .background(Color(uiColor: .systemGroupedBackground))
        }
    }
}

struct MaterialiDocumentViewer: View {
    @EnvironmentObject var vm: SessionVM
    let allegatoOid: String
    let title: String
    let directURL: URL? // if provided, bypass GetDocument?id= and fetch directly

    init(allegatoOid: String, title: String, directURL: URL? = nil) {
        self.allegatoOid = allegatoOid
        self.title = title
        self.directURL = directURL
    }

    @State private var isLoading = false
    @State private var errorMessage: String? = nil
    @State private var pdfData: Data? = nil
    @State private var tempFileURL: URL? = nil

    private func sanitizedFilename(_ s: String) -> String {
        let invalid = CharacterSet(charactersIn: "\\/:*?\"<>|\n").union(.illegalCharacters)
        let name = s.components(separatedBy: invalid).joined(separator: " ")
        return name.isEmpty ? "documento" : name
    }

    private func fetchFile() async {
        await MainActor.run { isLoading = true; errorMessage = nil }

        do {
            let data: Data
            if let direct = directURL {
                // Fetch from absolute URL (already authenticated if server allows; else still try with Bearer)
                var req = URLRequest(url: direct)
                req.httpMethod = "GET"
                req.setValue("application/json", forHTTPHeaderField: "Accept")
                req.setValue("Bearer \(vm.accessToken)", forHTTPHeaderField: "Authorization")
                let (d, resp) = try await URLSession.shared.data(for: req)
                if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    throw NSError(domain: "MaterialiDocumentViewer", code: http.statusCode)
                }
                data = d
            } else {
                // Standard flow via GetDocument?id=
                var comps = URLComponents(string: "https://logosuni.laba.biz/logosuni.servicesv2/api/Documents/GetDocument")!
                comps.queryItems = [URLQueryItem(name: "id", value: allegatoOid)]
                var req = URLRequest(url: comps.url!)
                req.httpMethod = "GET"
                req.setValue("application/json", forHTTPHeaderField: "Accept")
                req.setValue("Bearer \(vm.accessToken)", forHTTPHeaderField: "Authorization")
                let (d, resp) = try await URLSession.shared.data(for: req)
                if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    throw NSError(domain: "MaterialiDocumentViewer", code: http.statusCode)
                }
                data = d
            }

            let fileName = sanitizedFilename(title) + ".pdf"
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("LABA_\(allegatoOid)_\(fileName)")
            try? data.write(to: url, options: [.atomic])

            await MainActor.run {
                pdfData = data
                tempFileURL = url
                isLoading = false
            }
        } catch {
            await MainActor.run { errorMessage = error.localizedDescription; isLoading = false }
        }
    }

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Carico documento…")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let err = errorMessage {
                ContentUnavailableView("Errore", systemImage: "xmark.octagon", description: Text(err))
            } else if let data = pdfData {
                PDFKitRepresentedView(data: data)
                    .ignoresSafeArea(edges: .bottom)
            } else {
                ProgressView("Carico documento…")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if let url = tempFileURL {
                    ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                }
            }
        }
        .task(id: allegatoOid + (directURL?.absoluteString ?? "")) { if pdfData == nil { await fetchFile() } }
    }
}


struct PDFKitRepresentedView: UIViewRepresentable {
    let data: Data
    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.autoScales = true
        v.displayMode = .singlePageContinuous
        v.displayDirection = .vertical
        v.backgroundColor = UIColor.systemBackground
        v.document = PDFDocument(data: data)
        return v
    }
    func updateUIView(_ uiView: PDFView, context: Context) {
        uiView.document = PDFDocument(data: data)
    }
}
