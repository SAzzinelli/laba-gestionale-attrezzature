import SwiftUI

/// Splash / Loading del token per LABA Bearer
struct RefreshTokenScreen: View {
    @State private var appear = false
    @EnvironmentObject var vm: SessionVM

    var body: some View {
        ZStack {
            // Sfondo di sistema, per coerenza con il resto dell'app
            Color(uiColor: .systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 16) {
                Image("logoLABA")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .foregroundStyle(Color.labaAccent)
                    .padding(.bottom, 6)

                Text("Aggiornamento accesso")
                    .font(.headline)

                Text("Sto rinnovando in sicurezza il token di sessione…")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)

                ProgressView()
                    .scaleEffect(1.1)
                    .padding(.top, 4)

                VStack(spacing: 2) {
                    if let rem = vm.tokenSecondsRemaining {
                        Text("Scadenza attuale tra \(max(rem, 0))s")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    Text("Token: \(vm.tokenPrefix)")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
                .padding(.top, 2)
            }
            .padding(.horizontal, 24)
            .scaleEffect(appear ? 1 : 0.85)
            .opacity(appear ? 1 : 0)
            .onAppear {
                withAnimation(.easeOut(duration: 0.4)) {
                    appear = true
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Aggiornamento accesso in corso")
    }
}

#Preview {
    RefreshTokenScreen()
        .environmentObject(SessionVM())
}
